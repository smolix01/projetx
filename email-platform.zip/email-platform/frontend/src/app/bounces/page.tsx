'use client';

import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { bouncesApi } from '@/services/api';
import Layout from '@/components/Layout';
import { AlertCircle, RefreshCw, Trash2, Search, Shield } from 'lucide-react';
import toast from 'react-hot-toast';

interface Bounce {
  id: string;
  email_address: string;
  bounce_type: string;
  bounce_reason: string;
  bounce_category: string;
  is_processed: boolean;
  created_at: string;
}

interface BounceStats {
  total_bounces: number;
  hard_bounces: number;
  soft_bounces: number;
  processed: number;
  pending: number;
  by_category: Record<string, number>;
}

interface SuppressedEmail {
  id: string;
  email_address: string;
  reason: string;
  created_at: string;
}

export default function BouncesPage() {
  const { isAuthenticated } = useAuth();
  const [bounces, setBounces] = useState<Bounce[]>([]);
  const [stats, setStats] = useState<BounceStats | null>(null);
  const [suppressed, setSuppressed] = useState<SuppressedEmail[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [activeTab, setActiveTab] = useState<'bounces' | 'suppressed'>('bounces');

  useEffect(() => {
    if (isAuthenticated) {
      fetchData();
    }
  }, [isAuthenticated]);

  const fetchData = async () => {
    try {
      const [bouncesRes, statsRes, suppressedRes] = await Promise.all([
        bouncesApi.getBounces(),
        bouncesApi.getStats(),
        bouncesApi.getSuppressionList(),
      ]);
      setBounces(bouncesRes.data.items);
      setStats(statsRes.data);
      setSuppressed(suppressedRes.data.items);
    } catch (error) {
      toast.error('Failed to fetch bounce data');
    } finally {
      setLoading(false);
    }
  };

  const handleProcessBounces = async () => {
    try {
      await bouncesApi.processBounces(100);
      toast.success('Bounces processed successfully');
      fetchData();
    } catch (error) {
      toast.error('Failed to process bounces');
    }
  };

  const handleRemoveSuppression = async (email: string) => {
    if (!confirm(`Remove ${email} from suppression list?`)) return;
    try {
      await bouncesApi.removeFromSuppression(email);
      toast.success('Email removed from suppression list');
      fetchData();
    } catch (error) {
      toast.error('Failed to remove from suppression');
    }
  };

  const filteredBounces = bounces.filter(
    (b) =>
      b.email_address.toLowerCase().includes(filter.toLowerCase()) ||
      b.bounce_reason?.toLowerCase().includes(filter.toLowerCase())
  );

  const filteredSuppressed = suppressed.filter((s) =>
    s.email_address.toLowerCase().includes(filter.toLowerCase())
  );

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-secondary-900">Bounce Management</h1>
            <p className="text-secondary-500">Manage bounced emails and suppression list</p>
          </div>
          <button onClick={handleProcessBounces} className="btn-primary">
            <RefreshCw className="h-4 w-4 mr-2" />
            Process Bounces
          </button>
        </div>

        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="card p-4">
              <p className="text-sm text-secondary-500">Total Bounces</p>
              <p className="text-2xl font-bold text-secondary-900">{stats.total_bounces}</p>
            </div>
            <div className="card p-4">
              <p className="text-sm text-secondary-500">Hard Bounces</p>
              <p className="text-2xl font-bold text-danger-600">{stats.hard_bounces}</p>
            </div>
            <div className="card p-4">
              <p className="text-sm text-secondary-500">Soft Bounces</p>
              <p className="text-2xl font-bold text-warning-600">{stats.soft_bounces}</p>
            </div>
            <div className="card p-4">
              <p className="text-sm text-secondary-500">Pending</p>
              <p className="text-2xl font-bold text-primary-600">{stats.pending}</p>
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="border-b border-secondary-200">
          <nav className="flex space-x-8">
            <button
              onClick={() => setActiveTab('bounces')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'bounces'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-secondary-500 hover:text-secondary-700'
              }`}
            >
              Bounces
            </button>
            <button
              onClick={() => setActiveTab('suppressed')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'suppressed'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-secondary-500 hover:text-secondary-700'
              }`}
            >
              Suppression List
            </button>
          </nav>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-secondary-400" />
          <input
            type="text"
            placeholder={activeTab === 'bounces' ? 'Search bounces...' : 'Search suppressed emails...'}
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="form-input pl-10"
          />
        </div>

        {/* Bounces Tab */}
        {activeTab === 'bounces' && (
          <div className="card">
            <div className="overflow-x-auto">
              <table className="table">
                <thead>
                  <tr>
                    <th>Email</th>
                    <th>Type</th>
                    <th>Category</th>
                    <th>Reason</th>
                    <th>Status</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-secondary-200">
                  {filteredBounces.map((bounce) => (
                    <tr key={bounce.id}>
                      <td>{bounce.email_address}</td>
                      <td>
                        <span
                          className={`badge ${
                            bounce.bounce_type === 'hard' ? 'badge-danger' : 'badge-warning'
                          }`}
                        >
                          {bounce.bounce_type}
                        </span>
                      </td>
                      <td>{bounce.bounce_category || 'Unknown'}</td>
                      <td className="max-w-xs truncate">{bounce.bounce_reason}</td>
                      <td>
                        <span className={`badge ${bounce.is_processed ? 'badge-success' : 'badge-warning'}`}>
                          {bounce.is_processed ? 'Processed' : 'Pending'}
                        </span>
                      </td>
                      <td>{new Date(bounce.created_at).toLocaleDateString()}</td>
                    </tr>
                  ))}
                  {filteredBounces.length === 0 && (
                    <tr>
                      <td colSpan={6} className="text-center text-secondary-500 py-8">
                        No bounces found
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Suppressed Tab */}
        {activeTab === 'suppressed' && (
          <div className="card">
            <div className="overflow-x-auto">
              <table className="table">
                <thead>
                  <tr>
                    <th>Email</th>
                    <th>Reason</th>
                    <th>Added</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-secondary-200">
                  {filteredSuppressed.map((item) => (
                    <tr key={item.id}>
                      <td>{item.email_address}</td>
                      <td>
                        <span className="badge badge-danger">{item.reason}</span>
                      </td>
                      <td>{new Date(item.created_at).toLocaleDateString()}</td>
                      <td>
                        <button
                          onClick={() => handleRemoveSuppression(item.email_address)}
                          className="p-2 text-danger-600 hover:bg-danger-50 rounded-lg"
                          title="Remove from suppression"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {filteredSuppressed.length === 0 && (
                    <tr>
                      <td colSpan={4} className="text-center text-secondary-500 py-8">
                        No suppressed emails
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
