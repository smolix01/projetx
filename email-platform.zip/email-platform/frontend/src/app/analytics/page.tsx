'use client';

import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { analyticsApi } from '@/services/api';
import Layout from '@/components/Layout';
import { BarChart3, TrendingUp, TrendingDown, Globe, Monitor, Clock } from 'lucide-react';
import toast from 'react-hot-toast';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

const COLORS = ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6'];

export default function AnalyticsPage() {
  const { isAuthenticated } = useAuth();
  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [chartsData, setChartsData] = useState<any>(null);
  const [topCampaigns, setTopCampaigns] = useState<any[]>([]);
  const [geographicData, setGeographicData] = useState<any[]>([]);
  const [deviceData, setDeviceData] = useState<any>(null);

  useEffect(() => {
    if (isAuthenticated) {
      fetchData();
    }
  }, [isAuthenticated]);

  const fetchData = async () => {
    try {
      const [dashboardRes, chartsRes, campaignsRes, geoRes, deviceRes] = await Promise.all([
        analyticsApi.getDashboard(),
        analyticsApi.getEngagement(30),
        analyticsApi.getTopCampaigns(5),
        analyticsApi.getGeographic(),
        analyticsApi.getDevices(),
      ]);
      setDashboardData(dashboardRes.data);
      setChartsData(chartsRes.data);
      setTopCampaigns(campaignsRes.data);
      setGeographicData(geoRes.data);
      setDeviceData(deviceRes.data);
    } catch (error) {
      toast.error('Failed to fetch analytics data');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-secondary-900">Analytics</h1>
          <p className="text-secondary-500">Detailed insights into your email performance</p>
        </div>

        {/* Overview Stats */}
        {dashboardData && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="card p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-secondary-500">Today's Emails</p>
                  <p className="text-3xl font-bold text-secondary-900">
                    {dashboardData.overview.today.sent.toLocaleString()}
                  </p>
                </div>
                <div className="p-3 bg-primary-50 rounded-lg">
                  <BarChart3 className="h-6 w-6 text-primary-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <TrendingUp className="h-4 w-4 text-success-600 mr-1" />
                <span className="text-sm text-success-600">+12%</span>
                <span className="text-sm text-secondary-500 ml-2">vs yesterday</span>
              </div>
            </div>

            <div className="card p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-secondary-500">Today's Opens</p>
                  <p className="text-3xl font-bold text-secondary-900">
                    {dashboardData.overview.today.opens.toLocaleString()}
                  </p>
                </div>
                <div className="p-3 bg-success-50 rounded-lg">
                  <TrendingUp className="h-6 w-6 text-success-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <TrendingUp className="h-4 w-4 text-success-600 mr-1" />
                <span className="text-sm text-success-600">+8%</span>
                <span className="text-sm text-secondary-500 ml-2">vs yesterday</span>
              </div>
            </div>

            <div className="card p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-secondary-500">Today's Clicks</p>
                  <p className="text-3xl font-bold text-secondary-900">
                    {dashboardData.overview.today.clicks.toLocaleString()}
                  </p>
                </div>
                <div className="p-3 bg-warning-50 rounded-lg">
                  <TrendingDown className="h-6 w-6 text-warning-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <TrendingDown className="h-4 w-4 text-danger-600 mr-1" />
                <span className="text-sm text-danger-600">-3%</span>
                <span className="text-sm text-secondary-500 ml-2">vs yesterday</span>
              </div>
            </div>
          </div>
        )}

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Engagement Chart */}
          <div className="card">
            <div className="card-header">
              <h3 className="text-lg font-semibold text-secondary-900">Engagement (30 Days)</h3>
            </div>
            <div className="card-body">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartsData || []}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis
                      dataKey="date"
                      tickFormatter={(date) => new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="opens" fill="#3b82f6" name="Opens" />
                    <Bar dataKey="clicks" fill="#22c55e" name="Clicks" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Geographic Distribution */}
          <div className="card">
            <div className="card-header flex items-center">
              <Globe className="h-5 w-5 mr-2 text-primary-600" />
              <h3 className="text-lg font-semibold text-secondary-900">Top Countries</h3>
            </div>
            <div className="card-body">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={geographicData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ country, count }) => `${country}: ${count}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="count"
                      nameKey="country"
                    >
                      {geographicData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>

        {/* Device Stats */}
        {deviceData && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="card">
              <div className="card-header flex items-center">
                <Monitor className="h-5 w-5 mr-2 text-primary-600" />
                <h3 className="text-lg font-semibold text-secondary-900">Devices</h3>
              </div>
              <div className="card-body">
                <div className="space-y-3">
                  {Object.entries(deviceData.devices).map(([device, count]: [string, any]) => (
                    <div key={device} className="flex items-center justify-between">
                      <span className="text-secondary-600 capitalize">{device}</span>
                      <span className="font-medium">{count}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="card">
              <div className="card-header">
                <h3 className="text-lg font-semibold text-secondary-900">Browsers</h3>
              </div>
              <div className="card-body">
                <div className="space-y-3">
                  {Object.entries(deviceData.browsers).map(([browser, count]: [string, any]) => (
                    <div key={browser} className="flex items-center justify-between">
                      <span className="text-secondary-600">{browser}</span>
                      <span className="font-medium">{count}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="card">
              <div className="card-header flex items-center">
                <Clock className="h-5 w-5 mr-2 text-primary-600" />
                <h3 className="text-lg font-semibold text-secondary-900">Operating Systems</h3>
              </div>
              <div className="card-body">
                <div className="space-y-3">
                  {Object.entries(deviceData.operating_systems).map(([os, count]: [string, any]) => (
                    <div key={os} className="flex items-center justify-between">
                      <span className="text-secondary-600">{os}</span>
                      <span className="font-medium">{count}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Top Campaigns */}
        <div className="card">
          <div className="card-header">
            <h3 className="text-lg font-semibold text-secondary-900">Top Performing Campaigns</h3>
          </div>
          <div className="card-body">
            <div className="overflow-x-auto">
              <table className="table">
                <thead>
                  <tr>
                    <th>Campaign</th>
                    <th>Subject</th>
                    <th>Sent</th>
                    <th>Open Rate</th>
                    <th>Click Rate</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-secondary-200">
                  {topCampaigns.map((campaign) => (
                    <tr key={campaign.id}>
                      <td className="font-medium text-secondary-900">{campaign.name}</td>
                      <td className="max-w-xs truncate">{campaign.subject}</td>
                      <td>{campaign.sent.toLocaleString()}</td>
                      <td>
                        <span className="text-success-600 font-medium">
                          {campaign.open_rate.toFixed(1)}%
                        </span>
                      </td>
                      <td>
                        <span className="text-primary-600 font-medium">
                          {campaign.click_rate.toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  ))}
                  {topCampaigns.length === 0 && (
                    <tr>
                      <td colSpan={5} className="text-center text-secondary-500 py-8">
                        No campaigns yet
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
