'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { campaignsApi, listsApi } from '@/services/api';
import Layout from '@/components/Layout';
import { ArrowLeft, Send, TestTube } from 'lucide-react';
import toast from 'react-hot-toast';

interface EmailList {
  id: string;
  name: string;
  total_contacts: number;
}

export default function NewCampaign() {
  const router = useRouter();
  const { isAuthenticated } = useAuth();
  const [lists, setLists] = useState<EmailList[]>([]);
  const [loading, setLoading] = useState(false);
  const [testEmails, setTestEmails] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    subject: '',
    from_name: '',
    from_email: '',
    reply_to: '',
    html_content: '',
    text_content: '',
    email_list_id: '',
    track_opens: true,
    track_clicks: true,
  });

  useEffect(() => {
    if (isAuthenticated) {
      fetchLists();
    }
  }, [isAuthenticated]);

  const fetchLists = async () => {
    try {
      const response = await listsApi.getLists();
      setLists(response.data.items);
    } catch (error) {
      toast.error('Failed to fetch email lists');
    }
  };

  const handleSubmit = async (e: React.FormEvent, sendTest = false) => {
    e.preventDefault();
    setLoading(true);

    try {
      const campaignRes = await campaignsApi.createCampaign(formData);
      const campaignId = campaignRes.data.id;

      if (sendTest) {
        const emails = testEmails.split(',').map((e) => e.trim()).filter(Boolean);
        if (emails.length === 0) {
          toast.error('Please enter at least one test email');
          setLoading(false);
          return;
        }
        await campaignsApi.testCampaign(campaignId, emails);
        toast.success('Test emails sent successfully');
      } else {
        await campaignsApi.sendCampaign(campaignId);
        toast.success('Campaign created and sending started');
        router.push('/campaigns');
      }
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Failed to create campaign');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <button
            onClick={() => router.push('/campaigns')}
            className="p-2 text-secondary-600 hover:bg-secondary-100 rounded-lg"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-secondary-900">Create Campaign</h1>
            <p className="text-secondary-500">Create and send a new email campaign</p>
          </div>
        </div>

        <form className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              <div className="card">
                <div className="card-header">
                  <h3 className="text-lg font-semibold text-secondary-900">Campaign Details</h3>
                </div>
                <div className="card-body space-y-4">
                  <div>
                    <label className="form-label">Campaign Name *</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="form-input"
                      placeholder="e.g., Monthly Newsletter"
                    />
                  </div>
                  <div>
                    <label className="form-label">Subject Line *</label>
                    <input
                      type="text"
                      required
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      className="form-input"
                      placeholder="e.g., Check out our latest updates!"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="form-label">From Name *</label>
                      <input
                        type="text"
                        required
                        value={formData.from_name}
                        onChange={(e) => setFormData({ ...formData, from_name: e.target.value })}
                        className="form-input"
                        placeholder="Your Company"
                      />
                    </div>
                    <div>
                      <label className="form-label">From Email *</label>
                      <input
                        type="email"
                        required
                        value={formData.from_email}
                        onChange={(e) => setFormData({ ...formData, from_email: e.target.value })}
                        className="form-input"
                        placeholder="noreply@example.com"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="form-label">Reply-To Email</label>
                    <input
                      type="email"
                      value={formData.reply_to}
                      onChange={(e) => setFormData({ ...formData, reply_to: e.target.value })}
                      className="form-input"
                      placeholder="support@example.com"
                    />
                  </div>
                </div>
              </div>

              <div className="card">
                <div className="card-header">
                  <h3 className="text-lg font-semibold text-secondary-900">Email Content</h3>
                </div>
                <div className="card-body space-y-4">
                  <div>
                    <label className="form-label">HTML Content</label>
                    <textarea
                      value={formData.html_content}
                      onChange={(e) => setFormData({ ...formData, html_content: e.target.value })}
                      className="form-input"
                      rows={12}
                      placeholder="<html>...</html>"
                    />
                  </div>
                  <div>
                    <label className="form-label">Plain Text Content</label>
                    <textarea
                      value={formData.text_content}
                      onChange={(e) => setFormData({ ...formData, text_content: e.target.value })}
                      className="form-input"
                      rows={6}
                      placeholder="Plain text version of your email..."
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <div className="card">
                <div className="card-header">
                  <h3 className="text-lg font-semibold text-secondary-900">Recipients</h3>
                </div>
                <div className="card-body space-y-4">
                  <div>
                    <label className="form-label">Email List *</label>
                    <select
                      required
                      value={formData.email_list_id}
                      onChange={(e) => setFormData({ ...formData, email_list_id: e.target.value })}
                      className="form-input"
                    >
                      <option value="">Select a list</option>
                      {lists.map((list) => (
                        <option key={list.id} value={list.id}>
                          {list.name} ({list.total_contacts} contacts)
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="card">
                <div className="card-header">
                  <h3 className="text-lg font-semibold text-secondary-900">Tracking</h3>
                </div>
                <div className="card-body space-y-4">
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="track_opens"
                      checked={formData.track_opens}
                      onChange={(e) => setFormData({ ...formData, track_opens: e.target.checked })}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-secondary-300 rounded"
                    />
                    <label htmlFor="track_opens" className="ml-2 text-sm text-secondary-700">
                      Track email opens
                    </label>
                  </div>
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="track_clicks"
                      checked={formData.track_clicks}
                      onChange={(e) => setFormData({ ...formData, track_clicks: e.target.checked })}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-secondary-300 rounded"
                    />
                    <label htmlFor="track_clicks" className="ml-2 text-sm text-secondary-700">
                      Track link clicks
                    </label>
                  </div>
                </div>
              </div>

              <div className="card">
                <div className="card-header">
                  <h3 className="text-lg font-semibold text-secondary-900">Test & Send</h3>
                </div>
                <div className="card-body space-y-4">
                  <div>
                    <label className="form-label">Test Emails (comma-separated)</label>
                    <input
                      type="text"
                      value={testEmails}
                      onChange={(e) => setTestEmails(e.target.value)}
                      className="form-input"
                      placeholder="test@example.com, another@example.com"
                    />
                  </div>
                  <button
                    onClick={(e) => handleSubmit(e, true)}
                    disabled={loading || !testEmails}
                    className="w-full btn-secondary"
                  >
                    <TestTube className="h-4 w-4 mr-2" />
                    Send Test
                  </button>
                  <button
                    onClick={(e) => handleSubmit(e, false)}
                    disabled={loading}
                    className="w-full btn-primary"
                  >
                    <Send className="h-4 w-4 mr-2" />
                    {loading ? 'Creating...' : 'Send Campaign'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </Layout>
  );
}
