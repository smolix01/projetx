'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { campaignsApi } from '@/services/api';
import Layout from '@/components/Layout';
import { Plus, Search, Filter, MoreVertical, Play, Pause, Square } from 'lucide-react';
import toast from 'react-hot-toast';

interface Campaign {
  id: string;
  name: string;
  subject: string;
  status: string;
  total_recipients: number;
  sent_count: number;
  opened_count: number;
  clicked_count: number;
  created_at: string;
}

export default function Campaigns() {
  const router = useRouter();
  const { isAuthenticated } = useAuth();
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  useEffect(() => {
    if (isAuthenticated) {
      fetchCampaigns();
    }
  }, [isAuthenticated, statusFilter]);

  const fetchCampaigns = async () => {
    try {
      const response = await campaignsApi.getCampaigns({
        status: statusFilter || undefined,
        page: 1,
        per_page: 50,
      });
      setCampaigns(response.data.items);
    } catch (error) {
      toast.error('Failed to fetch campaigns');
    } finally {
      setLoading(false);
    }
  };

  const handleSend = async (id: string) => {
    try {
      await campaignsApi.sendCampaign(id);
      toast.success('Campaign started successfully');
      fetchCampaigns();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Failed to start campaign');
    }
  };

  const handlePause = async (id: string) => {
    try {
      await campaignsApi.pauseCampaign(id);
      toast.success('Campaign paused');
      fetchCampaigns();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Failed to pause campaign');
    }
  };

  const handleCancel = async (id: string) => {
    try {
      await campaignsApi.cancelCampaign(id);
      toast.success('Campaign cancelled');
      fetchCampaigns();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Failed to cancel campaign');
    }
  };

  const filteredCampaigns = campaigns.filter((campaign) =>
    campaign.name.toLowerCase().includes(filter.toLowerCase()) ||
    campaign.subject.toLowerCase().includes(filter.toLowerCase())
  );

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <h1 className="text-2xl font-bold text-secondary-900">Campaigns</h1>
          <button
            onClick={() => router.push('/campaigns/new')}
            className="btn-primary"
          >
            <Plus className="h-4 w-4 mr-2" />
            New Campaign
          </button>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-secondary-400" />
            <input
              type="text"
              placeholder="Search campaigns..."
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="form-input pl-10"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="h-5 w-5 text-secondary-400" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="form-input"
            >
              <option value="">All Status</option>
              <option value="draft">Draft</option>
              <option value="scheduled">Scheduled</option>
              <option value="sending">Sending</option>
              <option value="sent">Sent</option>
              <option value="paused">Paused</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
        </div>

        {/* Campaigns Table */}
        <div className="card">
          <div className="overflow-x-auto">
            <table className="table">
              <thead>
                <tr>
                  <th>Campaign</th>
                  <th>Status</th>
                  <th>Recipients</th>
                  <th>Sent</th>
                  <th>Opens</th>
                  <th>Clicks</th>
                  <th>Created</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-secondary-200">
                {filteredCampaigns.map((campaign) => (
                  <tr key={campaign.id} className="hover:bg-secondary-50">
                    <td>
                      <div>
                        <p className="font-medium text-secondary-900">{campaign.name}</p>
                        <p className="text-sm text-secondary-500">{campaign.subject}</p>
                      </div>
                    </td>
                    <td>
                      <StatusBadge status={campaign.status} />
                    </td>
                    <td>{campaign.total_recipients.toLocaleString()}</td>
                    <td>{campaign.sent_count.toLocaleString()}</td>
                    <td>{campaign.opened_count.toLocaleString()}</td>
                    <td>{campaign.clicked_count.toLocaleString()}</td>
                    <td>{new Date(campaign.created_at).toLocaleDateString()}</td>
                    <td>
                      <div className="flex items-center space-x-2">
                        {campaign.status === 'draft' && (
                          <button
                            onClick={() => handleSend(campaign.id)}
                            className="p-2 text-success-600 hover:bg-success-50 rounded-lg"
                            title="Send"
                          >
                            <Play className="h-4 w-4" />
                          </button>
                        )}
                        {campaign.status === 'sending' && (
                          <button
                            onClick={() => handlePause(campaign.id)}
                            className="p-2 text-warning-600 hover:bg-warning-50 rounded-lg"
                            title="Pause"
                          >
                            <Pause className="h-4 w-4" />
                          </button>
                        )}
                        {(campaign.status === 'draft' || campaign.status === 'scheduled' || campaign.status === 'paused') && (
                          <button
                            onClick={() => handleCancel(campaign.id)}
                            className="p-2 text-danger-600 hover:bg-danger-50 rounded-lg"
                            title="Cancel"
                          >
                            <Square className="h-4 w-4" />
                          </button>
                        )}
                        <button
                          onClick={() => router.push(`/campaigns/${campaign.id}`)}
                          className="p-2 text-secondary-600 hover:bg-secondary-100 rounded-lg"
                          title="View"
                        >
                          <MoreVertical className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filteredCampaigns.length === 0 && (
                  <tr>
                    <td colSpan={8} className="text-center py-12 text-secondary-500">
                      No campaigns found. Create your first campaign to get started.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </Layout>
  );
}

function StatusBadge({ status }: { status: string }) {
  const statusClasses: Record<string, string> = {
    draft: 'badge-secondary',
    scheduled: 'badge-info',
    sending: 'badge-warning',
    sent: 'badge-success',
    paused: 'badge-warning',
    cancelled: 'badge-danger',
  };

  return (
    <span className={`badge ${statusClasses[status] || 'badge-secondary'}`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}
