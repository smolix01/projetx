'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { listsApi } from '@/services/api';
import Layout from '@/components/Layout';
import { ArrowLeft, Plus, Search, Trash2, Upload, User } from 'lucide-react';
import toast from 'react-hot-toast';

interface Contact {
  id: string;
  email: string;
  name: string;
  status: string;
  created_at: string;
}

interface EmailList {
  id: string;
  name: string;
  description: string;
  total_contacts: number;
  active_contacts: number;
  bounced_contacts: number;
  unsubscribed_contacts: number;
}

export default function ListDetail({ params }: { params: { id: string } }) {
  const router = useRouter();
  const { isAuthenticated } = useAuth();
  const [list, setList] = useState<EmailList | null>(null);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newContact, setNewContact] = useState({ email: '', name: '' });

  useEffect(() => {
    if (isAuthenticated) {
      fetchData();
    }
  }, [isAuthenticated]);

  const fetchData = async () => {
    try {
      const [listRes, contactsRes] = await Promise.all([
        listsApi.getList(params.id),
        listsApi.getContacts(params.id),
      ]);
      setList(listRes.data);
      setContacts(contactsRes.data.items);
    } catch (error) {
      toast.error('Failed to fetch list data');
    } finally {
      setLoading(false);
    }
  };

  const handleAddContact = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await listsApi.addContact(params.id, newContact);
      toast.success('Contact added successfully');
      setShowAddModal(false);
      setNewContact({ email: '', name: '' });
      fetchData();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Failed to add contact');
    }
  };

  const handleDeleteContact = async (contactId: string) => {
    if (!confirm('Are you sure you want to delete this contact?')) return;
    try {
      await listsApi.deleteContact(params.id, contactId);
      toast.success('Contact deleted');
      fetchData();
    } catch (error) {
      toast.error('Failed to delete contact');
    }
  };

  const handleImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      await listsApi.importContacts(params.id, file);
      toast.success('Contacts imported successfully');
      fetchData();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Failed to import contacts');
    }
  };

  const filteredContacts = contacts.filter(
    (c) =>
      c.email.toLowerCase().includes(filter.toLowerCase()) ||
      c.name?.toLowerCase().includes(filter.toLowerCase())
  );

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </Layout>
    );
  }

  if (!list) {
    return (
      <Layout>
        <div className="text-center py-12">
          <p className="text-secondary-500">List not found</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <button
            onClick={() => router.push('/lists')}
            className="p-2 text-secondary-600 hover:bg-secondary-100 rounded-lg"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-secondary-900">{list.name}</h1>
            <p className="text-secondary-500">{list.description}</p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="card p-4">
            <p className="text-sm text-secondary-500">Total Contacts</p>
            <p className="text-2xl font-bold text-secondary-900">{list.total_contacts}</p>
          </div>
          <div className="card p-4">
            <p className="text-sm text-secondary-500">Active</p>
            <p className="text-2xl font-bold text-success-600">{list.active_contacts}</p>
          </div>
          <div className="card p-4">
            <p className="text-sm text-secondary-500">Bounced</p>
            <p className="text-2xl font-bold text-danger-600">{list.bounced_contacts}</p>
          </div>
          <div className="card p-4">
            <p className="text-sm text-secondary-500">Unsubscribed</p>
            <p className="text-2xl font-bold text-secondary-600">{list.unsubscribed_contacts}</p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-secondary-400" />
            <input
              type="text"
              placeholder="Search contacts..."
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="form-input pl-10"
            />
          </div>
          <div className="flex space-x-2">
            <button onClick={() => setShowAddModal(true)} className="btn-primary">
              <Plus className="h-4 w-4 mr-2" />
              Add Contact
            </button>
            <label className="btn-secondary cursor-pointer">
              <Upload className="h-4 w-4 mr-2" />
              Import CSV
              <input type="file" accept=".csv" className="hidden" onChange={handleImport} />
            </label>
          </div>
        </div>

        {/* Contacts Table */}
        <div className="card">
          <div className="overflow-x-auto">
            <table className="table">
              <thead>
                <tr>
                  <th>Contact</th>
                  <th>Status</th>
                  <th>Added</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-secondary-200">
                {filteredContacts.map((contact) => (
                  <tr key={contact.id}>
                    <td>
                      <div className="flex items-center">
                        <div className="p-2 bg-secondary-100 rounded-full">
                          <User className="h-4 w-4 text-secondary-600" />
                        </div>
                        <div className="ml-3">
                          <p className="font-medium text-secondary-900">{contact.name || 'Unnamed'}</p>
                          <p className="text-sm text-secondary-500">{contact.email}</p>
                        </div>
                      </div>
                    </td>
                    <td>
                      <StatusBadge status={contact.status} />
                    </td>
                    <td>{new Date(contact.created_at).toLocaleDateString()}</td>
                    <td>
                      <button
                        onClick={() => handleDeleteContact(contact.id)}
                        className="p-2 text-danger-600 hover:bg-danger-50 rounded-lg"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
                {filteredContacts.length === 0 && (
                  <tr>
                    <td colSpan={4} className="text-center text-secondary-500 py-8">
                      No contacts found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Add Contact Modal */}
        {showAddModal && (
          <div className="fixed inset-0 bg-secondary-900/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
              <h2 className="text-xl font-bold text-secondary-900 mb-4">Add Contact</h2>
              <form onSubmit={handleAddContact}>
                <div className="space-y-4">
                  <div>
                    <label className="form-label">Email *</label>
                    <input
                      type="email"
                      required
                      value={newContact.email}
                      onChange={(e) => setNewContact({ ...newContact, email: e.target.value })}
                      className="form-input"
                      placeholder="contact@example.com"
                    />
                  </div>
                  <div>
                    <label className="form-label">Name</label>
                    <input
                      type="text"
                      value={newContact.name}
                      onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                      className="form-input"
                      placeholder="Contact Name"
                    />
                  </div>
                </div>
                <div className="mt-6 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="btn-secondary"
                  >
                    Cancel
                  </button>
                  <button type="submit" className="btn-primary">
                    Add Contact
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}

function StatusBadge({ status }: { status: string }) {
  const statusClasses: Record<string, string> = {
    active: 'badge-success',
    bounced: 'badge-danger',
    unsubscribed: 'badge-secondary',
    complained: 'badge-warning',
  };

  return (
    <span className={`badge ${statusClasses[status] || 'badge-secondary'}`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}
