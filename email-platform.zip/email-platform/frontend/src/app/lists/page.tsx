'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { listsApi } from '@/services/api';
import Layout from '@/components/Layout';
import { Plus, Search, Users, Upload, MoreVertical, Trash2, Edit } from 'lucide-react';
import toast from 'react-hot-toast';

interface EmailList {
  id: string;
  name: string;
  description: string;
  total_contacts: number;
  active_contacts: number;
  bounced_contacts: number;
  unsubscribed_contacts: number;
  created_at: string;
}

export default function EmailLists() {
  const router = useRouter();
  const { isAuthenticated } = useAuth();
  const [lists, setLists] = useState<EmailList[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newListName, setNewListName] = useState('');
  const [newListDescription, setNewListDescription] = useState('');

  useEffect(() => {
    if (isAuthenticated) {
      fetchLists();
    }
  }, [isAuthenticated]);

  const fetchLists = async () => {
    try {
      const response = await listsApi.getLists({ page: 1, per_page: 50 });
      setLists(response.data.items);
    } catch (error) {
      toast.error('Failed to fetch lists');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateList = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await listsApi.createList({
        name: newListName,
        description: newListDescription,
      });
      toast.success('List created successfully');
      setShowCreateModal(false);
      setNewListName('');
      setNewListDescription('');
      fetchLists();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Failed to create list');
    }
  };

  const handleDeleteList = async (id: string) => {
    if (!confirm('Are you sure you want to delete this list?')) return;
    try {
      await listsApi.deleteList(id);
      toast.success('List deleted successfully');
      fetchLists();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Failed to delete list');
    }
  };

  const handleImport = async (listId: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      await listsApi.importContacts(listId, file);
      toast.success('Contacts imported successfully');
      fetchLists();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Failed to import contacts');
    }
  };

  const filteredLists = lists.filter(
    (list) =>
      list.name.toLowerCase().includes(filter.toLowerCase()) ||
      list.description?.toLowerCase().includes(filter.toLowerCase())
  );

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <h1 className="text-2xl font-bold text-secondary-900">Email Lists</h1>
          <button
            onClick={() => setShowCreateModal(true)}
            className="btn-primary"
          >
            <Plus className="h-4 w-4 mr-2" />
            New List
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-secondary-400" />
          <input
            type="text"
            placeholder="Search lists..."
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="form-input pl-10"
          />
        </div>

        {/* Lists Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredLists.map((list) => (
            <div key={list.id} className="card hover:shadow-md transition-shadow">
              <div className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-center">
                    <div className="p-3 bg-primary-50 rounded-lg">
                      <Users className="h-6 w-6 text-primary-600" />
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-semibold text-secondary-900">{list.name}</h3>
                      <p className="text-sm text-secondary-500">
                        {list.total_contacts.toLocaleString()} contacts
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => router.push(`/lists/${list.id}`)}
                      className="p-2 text-secondary-600 hover:bg-secondary-100 rounded-lg"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteList(list.id)}
                      className="p-2 text-danger-600 hover:bg-danger-50 rounded-lg"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                {list.description && (
                  <p className="mt-4 text-sm text-secondary-600">{list.description}</p>
                )}

                <div className="mt-4 grid grid-cols-3 gap-4 text-center">
                  <div>
                    <p className="text-lg font-semibold text-success-600">{list.active_contacts}</p>
                    <p className="text-xs text-secondary-500">Active</p>
                  </div>
                  <div>
                    <p className="text-lg font-semibold text-danger-600">{list.bounced_contacts}</p>
                    <p className="text-xs text-secondary-500">Bounced</p>
                  </div>
                  <div>
                    <p className="text-lg font-semibold text-secondary-600">{list.unsubscribed_contacts}</p>
                    <p className="text-xs text-secondary-500">Unsubscribed</p>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-secondary-200 flex items-center justify-between">
                  <button
                    onClick={() => router.push(`/lists/${list.id}`)}
                    className="text-primary-600 hover:text-primary-700 text-sm font-medium"
                  >
                    Manage Contacts
                  </button>
                  <label className="cursor-pointer">
                    <input
                      type="file"
                      accept=".csv"
                      className="hidden"
                      onChange={(e) => handleImport(list.id, e)}
                    />
                    <span className="flex items-center text-sm text-secondary-600 hover:text-secondary-900">
                      <Upload className="h-4 w-4 mr-1" />
                      Import
                    </span>
                  </label>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredLists.length === 0 && (
          <div className="text-center py-12">
            <Users className="h-12 w-12 text-secondary-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-secondary-900">No lists found</h3>
            <p className="text-secondary-500">Create your first email list to get started.</p>
          </div>
        )}

        {/* Create Modal */}
        {showCreateModal && (
          <div className="fixed inset-0 bg-secondary-900/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
              <h2 className="text-xl font-bold text-secondary-900 mb-4">Create New List</h2>
              <form onSubmit={handleCreateList}>
                <div className="space-y-4">
                  <div>
                    <label className="form-label">List Name *</label>
                    <input
                      type="text"
                      required
                      value={newListName}
                      onChange={(e) => setNewListName(e.target.value)}
                      className="form-input"
                      placeholder="e.g., Newsletter Subscribers"
                    />
                  </div>
                  <div>
                    <label className="form-label">Description</label>
                    <textarea
                      value={newListDescription}
                      onChange={(e) => setNewListDescription(e.target.value)}
                      className="form-input"
                      rows={3}
                      placeholder="Optional description..."
                    />
                  </div>
                </div>
                <div className="mt-6 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowCreateModal(false)}
                    className="btn-secondary"
                  >
                    Cancel
                  </button>
                  <button type="submit" className="btn-primary">
                    Create List
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
