'use client';

import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { smtpApi } from '@/services/api';
import Layout from '@/components/Layout';
import { Plus, Server, CheckCircle, XCircle, Copy, RefreshCw, Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';

interface SMTPDomain {
  id: string;
  domain: string;
  is_verified: boolean;
  spf_record: string;
  dkim_record: string;
  dmarc_record: string;
  created_at: string;
}

interface SMTPAccount {
  id: string;
  username: string;
  name: string;
  is_active: boolean;
  hourly_limit: number;
  daily_limit: number;
  monthly_limit: number;
  emails_sent_day: number;
  created_at: string;
}

export default function SMTPPage() {
  const { isAuthenticated } = useAuth();
  const [domains, setDomains] = useState<SMTPDomain[]>([]);
  const [accounts, setAccounts] = useState<SMTPAccount[]>([]);
  const [settings, setSettings] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showDomainModal, setShowDomainModal] = useState(false);
  const [showAccountModal, setShowAccountModal] = useState(false);
  const [newDomain, setNewDomain] = useState('');
  const [selectedDomain, setSelectedDomain] = useState('');
  const [accountName, setAccountName] = useState('');

  useEffect(() => {
    if (isAuthenticated) {
      fetchData();
    }
  }, [isAuthenticated]);

  const fetchData = async () => {
    try {
      const [domainsRes, accountsRes, settingsRes] = await Promise.all([
        smtpApi.getDomains(),
        smtpApi.getAccounts(),
        smtpApi.getSettings(),
      ]);
      setDomains(domainsRes.data.items);
      setAccounts(accountsRes.data.items);
      setSettings(settingsRes.data);
    } catch (error) {
      toast.error('Failed to fetch SMTP data');
    } finally {
      setLoading(false);
    }
  };

  const handleAddDomain = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await smtpApi.createDomain({ domain: newDomain });
      toast.success('Domain added successfully');
      setShowDomainModal(false);
      setNewDomain('');
      fetchData();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Failed to add domain');
    }
  };

  const handleVerifyDomain = async (id: string) => {
    try {
      const response = await smtpApi.verifyDomain(id);
      if (response.data.is_verified) {
        toast.success('Domain verified successfully');
      } else {
        toast.error('Domain verification failed. Check DNS records.');
      }
      fetchData();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Verification failed');
    }
  };

  const handleCreateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await smtpApi.createAccount({
        name: accountName,
        domain_id: selectedDomain || undefined,
      });
      toast.success('Account created successfully');
      toast.info(`Username: ${response.data.username}`);
      setShowAccountModal(false);
      setAccountName('');
      setSelectedDomain('');
      fetchData();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Failed to create account');
    }
  };

  const handleRegeneratePassword = async (id: string) => {
    try {
      const response = await smtpApi.regeneratePassword(id);
      toast.success('Password regenerated');
      toast.info(`New password: ${response.data.password}`, { duration: 10000 });
    } catch (error: any) {
      toast.error('Failed to regenerate password');
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-secondary-900">SMTP Management</h1>
          <p className="text-secondary-500">Manage your SMTP domains and accounts</p>
        </div>

        {/* SMTP Settings Card */}
        {settings && (
          <div className="card">
            <div className="card-header">
              <h3 className="text-lg font-semibold text-secondary-900">SMTP Settings</h3>
            </div>
            <div className="card-body">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-secondary-500">Host</p>
                  <p className="font-medium text-secondary-900">{settings.host}</p>
                </div>
                <div>
                  <p className="text-sm text-secondary-500">Ports</p>
                  <p className="font-medium text-secondary-900">
                    {Object.entries(settings.ports).map(([k, v]) => `${k}: ${v}`).join(', ')}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-secondary-500">Encryption</p>
                  <p className="font-medium text-secondary-900">{settings.encryption.join(', ')}</p>
                </div>
                <div>
                  <p className="text-sm text-secondary-500">Authentication</p>
                  <p className="font-medium text-secondary-900">{settings.authentication}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Domains Section */}
        <div className="card">
          <div className="card-header flex items-center justify-between">
            <h3 className="text-lg font-semibold text-secondary-900">Domains</h3>
            <button onClick={() => setShowDomainModal(true)} className="btn-primary text-sm">
              <Plus className="h-4 w-4 mr-1" />
              Add Domain
            </button>
          </div>
          <div className="card-body">
            <div className="space-y-4">
              {domains.map((domain) => (
                <div key={domain.id} className="border border-secondary-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <Server className="h-5 w-5 text-primary-600 mr-2" />
                      <span className="font-medium text-secondary-900">{domain.domain}</span>
                      {domain.is_verified ? (
                        <CheckCircle className="h-4 w-4 text-success-600 ml-2" />
                      ) : (
                        <XCircle className="h-4 w-4 text-danger-600 ml-2" />
                      )}
                    </div>
                    <div className="flex items-center space-x-2">
                      {!domain.is_verified && (
                        <button
                          onClick={() => handleVerifyDomain(domain.id)}
                          className="btn-secondary text-sm"
                        >
                          Verify
                        </button>
                      )}
                      <button
                        onClick={() => smtpApi.deleteDomain(domain.id)}
                        className="p-2 text-danger-600 hover:bg-danger-50 rounded-lg"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  {!domain.is_verified && (
                    <div className="bg-secondary-50 rounded-lg p-4 space-y-2">
                      <p className="text-sm font-medium text-secondary-700">Required DNS Records:</p>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <code className="text-xs bg-white px-2 py-1 rounded">SPF: {domain.spf_record}</code>
                          <button
                            onClick={() => copyToClipboard(domain.spf_record)}
                            className="text-secondary-400 hover:text-secondary-600"
                          >
                            <Copy className="h-4 w-4" />
                          </button>
                        </div>
                        {domain.dkim_record && (
                          <div className="flex items-center justify-between">
                            <code className="text-xs bg-white px-2 py-1 rounded">DKIM: {domain.dkim_record}</code>
                            <button
                              onClick={() => copyToClipboard(domain.dkim_record)}
                              className="text-secondary-400 hover:text-secondary-600"
                            >
                              <Copy className="h-4 w-4" />
                            </button>
                          </div>
                        )}
                        <div className="flex items-center justify-between">
                          <code className="text-xs bg-white px-2 py-1 rounded">DMARC: {domain.dmarc_record}</code>
                          <button
                            onClick={() => copyToClipboard(domain.dmarc_record)}
                            className="text-secondary-400 hover:text-secondary-600"
                          >
                            <Copy className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
              {domains.length === 0 && (
                <p className="text-center text-secondary-500 py-8">No domains added yet</p>
              )}
            </div>
          </div>
        </div>

        {/* Accounts Section */}
        <div className="card">
          <div className="card-header flex items-center justify-between">
            <h3 className="text-lg font-semibold text-secondary-900">SMTP Accounts</h3>
            <button onClick={() => setShowAccountModal(true)} className="btn-primary text-sm">
              <Plus className="h-4 w-4 mr-1" />
              Create Account
            </button>
          </div>
          <div className="card-body">
            <div className="overflow-x-auto">
              <table className="table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Status</th>
                    <th>Daily Usage</th>
                    <th>Created</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-secondary-200">
                  {accounts.map((account) => (
                    <tr key={account.id}>
                      <td>{account.name || 'Unnamed'}</td>
                      <td>
                        <code className="text-sm bg-secondary-100 px-2 py-1 rounded">{account.username}</code>
                      </td>
                      <td>
                        <span className={`badge ${account.is_active ? 'badge-success' : 'badge-danger'}`}>
                          {account.is_active ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td>
                        {account.emails_sent_day} / {account.daily_limit}
                      </td>
                      <td>{new Date(account.created_at).toLocaleDateString()}</td>
                      <td>
                        <button
                          onClick={() => handleRegeneratePassword(account.id)}
                          className="p-2 text-primary-600 hover:bg-primary-50 rounded-lg"
                          title="Regenerate Password"
                        >
                          <RefreshCw className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {accounts.length === 0 && (
                    <tr>
                      <td colSpan={6} className="text-center text-secondary-500 py-8">
                        No accounts created yet
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Domain Modal */}
        {showDomainModal && (
          <div className="fixed inset-0 bg-secondary-900/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
              <h2 className="text-xl font-bold text-secondary-900 mb-4">Add Domain</h2>
              <form onSubmit={handleAddDomain}>
                <div className="space-y-4">
                  <div>
                    <label className="form-label">Domain Name *</label>
                    <input
                      type="text"
                      required
                      value={newDomain}
                      onChange={(e) => setNewDomain(e.target.value)}
                      className="form-input"
                      placeholder="example.com"
                    />
                  </div>
                </div>
                <div className="mt-6 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowDomainModal(false)}
                    className="btn-secondary"
                  >
                    Cancel
                  </button>
                  <button type="submit" className="btn-primary">
                    Add Domain
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Account Modal */}
        {showAccountModal && (
          <div className="fixed inset-0 bg-secondary-900/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
              <h2 className="text-xl font-bold text-secondary-900 mb-4">Create SMTP Account</h2>
              <form onSubmit={handleCreateAccount}>
                <div className="space-y-4">
                  <div>
                    <label className="form-label">Account Name</label>
                    <input
                      type="text"
                      value={accountName}
                      onChange={(e) => setAccountName(e.target.value)}
                      className="form-input"
                      placeholder="e.g., Marketing Team"
                    />
                  </div>
                  <div>
                    <label className="form-label">Domain (Optional)</label>
                    <select
                      value={selectedDomain}
                      onChange={(e) => setSelectedDomain(e.target.value)}
                      className="form-input"
                    >
                      <option value="">No specific domain</option>
                      {domains.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.domain}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="mt-6 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowAccountModal(false)}
                    className="btn-secondary"
                  >
                    Cancel
                  </button>
                  <button type="submit" className="btn-primary">
                    Create Account
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
