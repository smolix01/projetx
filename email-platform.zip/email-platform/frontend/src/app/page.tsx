'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { dashboardApi } from '@/services/api';
import Layout from '@/components/Layout';
import {
  Mail,
  Users,
  Send,
  AlertCircle,
  TrendingUp,
  TrendingDown,
  Activity,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from 'recharts';

interface DashboardStats {
  overview: {
    today: { sent: number; opens: number; clicks: number; bounces: number };
    week: { sent: number; opens: number; clicks: number };
    month: { sent: number; opens: number; clicks: number };
    totals: { contacts: number; active_campaigns: number };
  };
  emails: {
    total_emails: number;
    sent: number;
    delivered: number;
    opened: number;
    clicked: number;
    bounced: number;
    open_rate: number;
    click_rate: number;
    bounce_rate: number;
  };
  recent_campaigns: any[];
}

export default function Dashboard() {
  const router = useRouter();
  const { isAuthenticated, isLoading } = useAuth();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [charts, setCharts] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/login');
    }
  }, [isAuthenticated, isLoading, router]);

  useEffect(() => {
    if (isAuthenticated) {
      fetchDashboardData();
    }
  }, [isAuthenticated]);

  const fetchDashboardData = async () => {
    try {
      const [statsRes, chartsRes] = await Promise.all([
        dashboardApi.getStats(),
        dashboardApi.getCharts(),
      ]);
      setStats(statsRes.data);
      setCharts(chartsRes.data);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (isLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-secondary-900">Dashboard</h1>
          <div className="flex space-x-3">
            <button
              onClick={() => router.push('/campaigns/new')}
              className="btn-primary"
            >
              <Send className="h-4 w-4 mr-2" />
              New Campaign
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title="Today's Sent"
            value={stats?.overview.today.sent || 0}
            icon={Mail}
            trend={+12}
            color="primary"
          />
          <StatCard
            title="Total Contacts"
            value={stats?.overview.totals.contacts || 0}
            icon={Users}
            trend={+5}
            color="success"
          />
          <StatCard
            title="Open Rate"
            value={`${(stats?.emails.open_rate || 0).toFixed(1)}%`}
            icon={Activity}
            trend={-2}
            color="warning"
          />
          <StatCard
            title="Bounce Rate"
            value={`${(stats?.emails.bounce_rate || 0).toFixed(1)}%`}
            icon={AlertCircle}
            trend={-8}
            color="danger"
          />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Email Volume Chart */}
          <div className="card">
            <div className="card-header">
              <h3 className="text-lg font-semibold text-secondary-900">Email Volume (30 Days)</h3>
            </div>
            <div className="card-body">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={charts?.email_volume || []}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" tickFormatter={(date) => new Date(date).toLocaleDateString()} />
                    <YAxis />
                    <Tooltip />
                    <Line
                      type="monotone"
                      dataKey="count"
                      stroke="#3b82f6"
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Engagement Chart */}
          <div className="card">
            <div className="card-header">
              <h3 className="text-lg font-semibold text-secondary-900">Engagement (30 Days)</h3>
            </div>
            <div className="card-body">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={charts?.engagement || []}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" tickFormatter={(date) => new Date(date).toLocaleDateString()} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="opens" fill="#3b82f6" />
                    <Bar dataKey="clicks" fill="#22c55e" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Campaigns */}
        <div className="card">
          <div className="card-header flex items-center justify-between">
            <h3 className="text-lg font-semibold text-secondary-900">Recent Campaigns</h3>
            <button
              onClick={() => router.push('/campaigns')}
              className="text-primary-600 hover:text-primary-700 text-sm font-medium"
            >
              View All
            </button>
          </div>
          <div className="card-body">
            <div className="overflow-x-auto">
              <table className="table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Status</th>
                    <th>Recipients</th>
                    <th>Sent</th>
                    <th>Open Rate</th>
                    <th>Click Rate</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-secondary-200">
                  {stats?.recent_campaigns?.map((campaign) => (
                    <tr
                      key={campaign.id}
                      className="hover:bg-secondary-50 cursor-pointer"
                      onClick={() => router.push(`/campaigns/${campaign.id}`)}
                    >
                      <td className="font-medium text-secondary-900">{campaign.name}</td>
                      <td>
                        <StatusBadge status={campaign.status} />
                      </td>
                      <td>{campaign.total_recipients.toLocaleString()}</td>
                      <td>{campaign.sent_count.toLocaleString()}</td>
                      <td>
                        {campaign.sent_count > 0
                          ? ((campaign.opened_count / campaign.sent_count) * 100).toFixed(1)
                          : 0}
                        %
                      </td>
                      <td>
                        {campaign.sent_count > 0
                          ? ((campaign.clicked_count / campaign.sent_count) * 100).toFixed(1)
                          : 0}
                        %
                      </td>
                    </tr>
                  ))}
                  {!stats?.recent_campaigns?.length && (
                    <tr>
                      <td colSpan={6} className="text-center py-8 text-secondary-500">
                        No campaigns yet. Create your first campaign to get started.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

function StatCard({
  title,
  value,
  icon: Icon,
  trend,
  color,
}: {
  title: string;
  value: string | number;
  icon: any;
  trend: number;
  color: 'primary' | 'success' | 'warning' | 'danger';
}) {
  const colorClasses = {
    primary: 'bg-primary-50 text-primary-600',
    success: 'bg-success-50 text-success-600',
    warning: 'bg-warning-50 text-warning-600',
    danger: 'bg-danger-50 text-danger-600',
  };

  return (
    <div className="card p-6">
      <div className="flex items-center">
        <div className={`p-3 rounded-lg ${colorClasses[color]}`}>
          <Icon className="h-6 w-6" />
        </div>
        <div className="ml-4">
          <p className="text-sm font-medium text-secondary-500">{title}</p>
          <p className="text-2xl font-bold text-secondary-900">{value}</p>
        </div>
      </div>
      <div className="mt-4 flex items-center">
        {trend > 0 ? (
          <TrendingUp className="h-4 w-4 text-success-600 mr-1" />
        ) : (
          <TrendingDown className="h-4 w-4 text-danger-600 mr-1" />
        )}
        <span className={`text-sm font-medium ${trend > 0 ? 'text-success-600' : 'text-danger-600'}`}>
          {Math.abs(trend)}%
        </span>
        <span className="text-sm text-secondary-500 ml-2">vs last period</span>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const statusClasses: Record<string, string> = {
    draft: 'badge-secondary',
    scheduled: 'badge-info',
    sending: 'badge-warning',
    sent: 'badge-success',
    paused: 'badge-warning',
    cancelled: 'badge-danger',
  };

  return (
    <span className={`badge ${statusClasses[status] || 'badge-secondary'}`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}
