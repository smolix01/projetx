'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { emailsApi } from '@/services/api';
import Layout from '@/components/Layout';
import { ArrowLeft, Send } from 'lucide-react';
import toast from 'react-hot-toast';

export default function SendEmail() {
  const router = useRouter();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    to: '',
    to_name: '',
    subject: '',
    html: '',
    text: '',
    from_email: user?.email || '',
    from_name: user?.first_name || '',
    reply_to: '',
    track_opens: true,
    track_clicks: true,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await emailsApi.sendEmail(formData);
      toast.success('Email sent successfully');
      router.push('/emails');
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Failed to send email');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <button
            onClick={() => router.push('/emails')}
            className="p-2 text-secondary-600 hover:bg-secondary-100 rounded-lg"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-secondary-900">Send Email</h1>
            <p className="text-secondary-500">Send a single email</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="card max-w-3xl">
          <div className="card-header">
            <h3 className="text-lg font-semibold text-secondary-900">Email Details</h3>
          </div>
          <div className="card-body space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="form-label">To Email *</label>
                <input
                  type="email"
                  required
                  value={formData.to}
                  onChange={(e) => setFormData({ ...formData, to: e.target.value })}
                  className="form-input"
                  placeholder="recipient@example.com"
                />
              </div>
              <div>
                <label className="form-label">To Name</label>
                <input
                  type="text"
                  value={formData.to_name}
                  onChange={(e) => setFormData({ ...formData, to_name: e.target.value })}
                  className="form-input"
                  placeholder="Recipient Name"
                />
              </div>
            </div>

            <div>
              <label className="form-label">Subject *</label>
              <input
                type="text"
                required
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                className="form-input"
                placeholder="Email subject"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="form-label">From Name</label>
                <input
                  type="text"
                  value={formData.from_name}
                  onChange={(e) => setFormData({ ...formData, from_name: e.target.value })}
                  className="form-input"
                  placeholder="Your Name"
                />
              </div>
              <div>
                <label className="form-label">From Email</label>
                <input
                  type="email"
                  value={formData.from_email}
                  onChange={(e) => setFormData({ ...formData, from_email: e.target.value })}
                  className="form-input"
                  placeholder="you@example.com"
                />
              </div>
            </div>

            <div>
              <label className="form-label">Reply-To</label>
              <input
                type="email"
                value={formData.reply_to}
                onChange={(e) => setFormData({ ...formData, reply_to: e.target.value })}
                className="form-input"
                placeholder="reply@example.com"
              />
            </div>

            <div>
              <label className="form-label">HTML Content</label>
              <textarea
                value={formData.html}
                onChange={(e) => setFormData({ ...formData, html: e.target.value })}
                className="form-input"
                rows={8}
                placeholder="<html>...</html>"
              />
            </div>

            <div>
              <label className="form-label">Plain Text Content</label>
              <textarea
                value={formData.text}
                onChange={(e) => setFormData({ ...formData, text: e.target.value })}
                className="form-input"
                rows={4}
                placeholder="Plain text version..."
              />
            </div>

            <div className="flex items-center space-x-6">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="track_opens"
                  checked={formData.track_opens}
                  onChange={(e) => setFormData({ ...formData, track_opens: e.target.checked })}
                  className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-secondary-300 rounded"
                />
                <label htmlFor="track_opens" className="ml-2 text-sm text-secondary-700">
                  Track opens
                </label>
              </div>
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="track_clicks"
                  checked={formData.track_clicks}
                  onChange={(e) => setFormData({ ...formData, track_clicks: e.target.checked })}
                  className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-secondary-300 rounded"
                />
                <label htmlFor="track_clicks" className="ml-2 text-sm text-secondary-700">
                  Track clicks
                </label>
              </div>
            </div>

            <div className="flex justify-end space-x-3 pt-4">
              <button
                type="button"
                onClick={() => router.push('/emails')}
                className="btn-secondary"
              >
                Cancel
              </button>
              <button type="submit" disabled={loading} className="btn-primary">
                <Send className="h-4 w-4 mr-2" />
                {loading ? 'Sending...' : 'Send Email'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </Layout>
  );
}
