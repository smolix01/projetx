'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { emailsApi } from '@/services/api';
import Layout from '@/components/Layout';
import { Mail, Send, RefreshCw, Eye, MousePointer, AlertCircle, CheckCircle } from 'lucide-react';
import toast from 'react-hot-toast';

interface Email {
  id: string;
  to_email: string;
  to_name: string;
  subject: string;
  status: string;
  created_at: string;
  sent_at: string;
}

interface EmailStats {
  total_emails: number;
  sent: number;
  delivered: number;
  opened: number;
  clicked: number;
  bounced: number;
  failed: number;
  open_rate: number;
  click_rate: number;
  bounce_rate: number;
}

export default function EmailsPage() {
  const router = useRouter();
  const { isAuthenticated } = useAuth();
  const [emails, setEmails] = useState<Email[]>([]);
  const [stats, setStats] = useState<EmailStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');

  useEffect(() => {
    if (isAuthenticated) {
      fetchData();
    }
  }, [isAuthenticated, statusFilter]);

  const fetchData = async () => {
    try {
      const [emailsRes, statsRes] = await Promise.all([
        emailsApi.getEmails({ status: statusFilter || undefined, page: 1, per_page: 50 }),
        emailsApi.getEmailStats(),
      ]);
      setEmails(emailsRes.data.items);
      setStats(statsRes.data);
    } catch (error) {
      toast.error('Failed to fetch emails');
    } finally {
      setLoading(false);
    }
  };

  const handleRetry = async (id: string) => {
    try {
      await emailsApi.retryEmail(id);
      toast.success('Email queued for retry');
      fetchData();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Failed to retry email');
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'sent':
      case 'delivered':
        return <CheckCircle className="h-4 w-4 text-success-600" />;
      case 'opened':
        return <Eye className="h-4 w-4 text-primary-600" />;
      case 'clicked':
        return <MousePointer className="h-4 w-4 text-primary-600" />;
      case 'bounced':
        return <AlertCircle className="h-4 w-4 text-danger-600" />;
      case 'failed':
        return <AlertCircle className="h-4 w-4 text-danger-600" />;
      default:
        return <Mail className="h-4 w-4 text-secondary-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const statusClasses: Record<string, string> = {
      queued: 'badge-secondary',
      sending: 'badge-warning',
      sent: 'badge-success',
      delivered: 'badge-success',
      opened: 'badge-primary',
      clicked: 'badge-primary',
      bounced: 'badge-danger',
      failed: 'badge-danger',
      retrying: 'badge-warning',
    };

    return (
      <span className={`badge ${statusClasses[status] || 'badge-secondary'}`}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-secondary-900">Emails</h1>
            <p className="text-secondary-500">View and manage sent emails</p>
          </div>
          <button onClick={() => router.push('/emails/send')} className="btn-primary">
            <Send className="h-4 w-4 mr-2" />
            Send Email
          </button>
        </div>

        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="card p-4">
              <div className="flex items-center">
                <Mail className="h-8 w-8 text-primary-600 mr-3" />
                <div>
                  <p className="text-sm text-secondary-500">Total Sent</p>
                  <p className="text-2xl font-bold text-secondary-900">{stats.sent.toLocaleString()}</p>
                </div>
              </div>
            </div>
            <div className="card p-4">
              <div className="flex items-center">
                <Eye className="h-8 w-8 text-primary-600 mr-3" />
                <div>
                  <p className="text-sm text-secondary-500">Open Rate</p>
                  <p className="text-2xl font-bold text-secondary-900">{stats.open_rate.toFixed(1)}%</p>
                </div>
              </div>
            </div>
            <div className="card p-4">
              <div className="flex items-center">
                <MousePointer className="h-8 w-8 text-primary-600 mr-3" />
                <div>
                  <p className="text-sm text-secondary-500">Click Rate</p>
                  <p className="text-2xl font-bold text-secondary-900">{stats.click_rate.toFixed(1)}%</p>
                </div>
              </div>
            </div>
            <div className="card p-4">
              <div className="flex items-center">
                <AlertCircle className="h-8 w-8 text-danger-600 mr-3" />
                <div>
                  <p className="text-sm text-secondary-500">Bounce Rate</p>
                  <p className="text-2xl font-bold text-secondary-900">{stats.bounce_rate.toFixed(1)}%</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Filter */}
        <div className="flex items-center space-x-4">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="form-input w-auto"
          >
            <option value="">All Status</option>
            <option value="queued">Queued</option>
            <option value="sending">Sending</option>
            <option value="sent">Sent</option>
            <option value="delivered">Delivered</option>
            <option value="opened">Opened</option>
            <option value="clicked">Clicked</option>
            <option value="bounced">Bounced</option>
            <option value="failed">Failed</option>
          </select>
        </div>

        {/* Emails Table */}
        <div className="card">
          <div className="overflow-x-auto">
            <table className="table">
              <thead>
                <tr>
                  <th>Recipient</th>
                  <th>Subject</th>
                  <th>Status</th>
                  <th>Created</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-secondary-200">
                {emails.map((email) => (
                  <tr key={email.id}>
                    <td>
                      <div>
                        <p className="font-medium text-secondary-900">{email.to_email}</p>
                        {email.to_name && <p className="text-sm text-secondary-500">{email.to_name}</p>}
                      </div>
                    </td>
                    <td className="max-w-xs truncate">{email.subject}</td>
                    <td>
                      <div className="flex items-center space-x-2">
                        {getStatusIcon(email.status)}
                        {getStatusBadge(email.status)}
                      </div>
                    </td>
                    <td>{new Date(email.created_at).toLocaleDateString()}</td>
                    <td>
                      {email.status === 'failed' && (
                        <button
                          onClick={() => handleRetry(email.id)}
                          className="p-2 text-primary-600 hover:bg-primary-50 rounded-lg"
                          title="Retry"
                        >
                          <RefreshCw className="h-4 w-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
                {emails.length === 0 && (
                  <tr>
                    <td colSpan={5} className="text-center text-secondary-500 py-8">
                      No emails found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </Layout>
  );
}
