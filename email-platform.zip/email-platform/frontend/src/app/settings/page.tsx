'use client';

import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { userApi } from '@/services/api';
import Layout from '@/components/Layout';
import { User, Key, Bell, Shield, Copy } from 'lucide-react';
import toast from 'react-hot-toast';

export default function SettingsPage() {
  const { user, refreshUser } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  const [apiKey, setApiKey] = useState('');

  useEffect(() => {
    if (user) {
      setFormData({
        ...formData,
        first_name: user.first_name || '',
        last_name: user.last_name || '',
        email: user.email || '',
      });
      setApiKey(user.api_key || '');
    }
  }, [user]);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await userApi.updateMe({
        first_name: formData.first_name,
        last_name: formData.last_name,
      });
      toast.success('Profile updated successfully');
      refreshUser();
    } catch (error) {
      toast.error('Failed to update profile');
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.newPassword !== formData.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    try {
      await userApi.updateMe({
        password: formData.newPassword,
      });
      toast.success('Password changed successfully');
      setFormData({
        ...formData,
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
      });
    } catch (error) {
      toast.error('Failed to change password');
    }
  };

  const handleRegenerateApiKey = async () => {
    if (!confirm('Are you sure? This will invalidate your current API key.')) return;
    try {
      const response = await userApi.regenerateApiKey();
      setApiKey(response.data.api_key);
      toast.success('API key regenerated');
      refreshUser();
    } catch (error) {
      toast.error('Failed to regenerate API key');
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-secondary-900">Settings</h1>
          <p className="text-secondary-500">Manage your account settings</p>
        </div>

        {/* Tabs */}
        <div className="border-b border-secondary-200">
          <nav className="flex space-x-8">
            <button
              onClick={() => setActiveTab('profile')}
              className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center ${
                activeTab === 'profile'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-secondary-500 hover:text-secondary-700'
              }`}
            >
              <User className="h-4 w-4 mr-2" />
              Profile
            </button>
            <button
              onClick={() => setActiveTab('security')}
              className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center ${
                activeTab === 'security'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-secondary-500 hover:text-secondary-700'
              }`}
            >
              <Shield className="h-4 w-4 mr-2" />
              Security
            </button>
            <button
              onClick={() => setActiveTab('api')}
              className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center ${
                activeTab === 'api'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-secondary-500 hover:text-secondary-700'
              }`}
            >
              <Key className="h-4 w-4 mr-2" />
              API
            </button>
          </nav>
        </div>

        {/* Profile Tab */}
        {activeTab === 'profile' && (
          <div className="card max-w-2xl">
            <div className="card-header">
              <h3 className="text-lg font-semibold text-secondary-900">Profile Information</h3>
            </div>
            <div className="card-body">
              <form onSubmit={handleUpdateProfile} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="form-label">First Name</label>
                    <input
                      type="text"
                      value={formData.first_name}
                      onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
                      className="form-input"
                    />
                  </div>
                  <div>
                    <label className="form-label">Last Name</label>
                    <input
                      type="text"
                      value={formData.last_name}
                      onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
                      className="form-input"
                    />
                  </div>
                </div>
                <div>
                  <label className="form-label">Email</label>
                  <input
                    type="email"
                    value={formData.email}
                    disabled
                    className="form-input bg-secondary-50"
                  />
                  <p className="text-xs text-secondary-500 mt-1">Email cannot be changed</p>
                </div>
                <div className="flex justify-end">
                  <button type="submit" className="btn-primary">
                    Save Changes
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Security Tab */}
        {activeTab === 'security' && (
          <div className="card max-w-2xl">
            <div className="card-header">
              <h3 className="text-lg font-semibold text-secondary-900">Change Password</h3>
            </div>
            <div className="card-body">
              <form onSubmit={handleChangePassword} className="space-y-4">
                <div>
                  <label className="form-label">Current Password</label>
                  <input
                    type="password"
                    value={formData.currentPassword}
                    onChange={(e) => setFormData({ ...formData, currentPassword: e.target.value })}
                    className="form-input"
                  />
                </div>
                <div>
                  <label className="form-label">New Password</label>
                  <input
                    type="password"
                    value={formData.newPassword}
                    onChange={(e) => setFormData({ ...formData, newPassword: e.target.value })}
                    className="form-input"
                  />
                </div>
                <div>
                  <label className="form-label">Confirm New Password</label>
                  <input
                    type="password"
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                    className="form-input"
                  />
                </div>
                <div className="flex justify-end">
                  <button type="submit" className="btn-primary">
                    Change Password
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* API Tab */}
        {activeTab === 'api' && (
          <div className="card max-w-2xl">
            <div className="card-header">
              <h3 className="text-lg font-semibold text-secondary-900">API Key</h3>
            </div>
            <div className="card-body space-y-4">
              <p className="text-secondary-600">
                Use this API key to authenticate your requests to the Email Delivery Platform API.
                Keep it secure and never share it publicly.
              </p>
              <div className="bg-secondary-50 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <code className="text-sm break-all">{apiKey}</code>
                  <button
                    onClick={() => copyToClipboard(apiKey)}
                    className="ml-4 p-2 text-secondary-400 hover:text-secondary-600"
                  >
                    <Copy className="h-4 w-4" />
                  </button>
                </div>
              </div>
              <div className="flex justify-end">
                <button onClick={handleRegenerateApiKey} className="btn-secondary">
                  <Key className="h-4 w-4 mr-2" />
                  Regenerate API Key
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
