import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';

// Create axios instance
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authApi = {
  login: (email: string, password: string) =>
    api.post('/auth/login', { email, password }),
  register: (data: { email: string; password: string; first_name?: string; last_name?: string }) =>
    api.post('/auth/register', data),
  refresh: () =>
    api.post('/auth/refresh'),
  regenerateApiKey: () =>
    api.post('/auth/api-key/regenerate'),
};

// Dashboard API
export const dashboardApi = {
  getStats: () =>
    api.get('/dashboard/stats'),
  getCharts: () =>
    api.get('/dashboard/charts'),
};

// Email Lists API
export const listsApi = {
  getLists: (params?: { page?: number; per_page?: number }) =>
    api.get('/lists', { params }),
  createList: (data: { name: string; description?: string }) =>
    api.post('/lists', data),
  updateList: (id: string, data: any) =>
    api.put(`/lists/${id}`, data),
  deleteList: (id: string) =>
    api.delete(`/lists/${id}`),
  getContacts: (listId: string, params?: { status?: string; page?: number; per_page?: number }) =>
    api.get(`/lists/${listId}/contacts`, { params }),
  addContact: (listId: string, data: any) =>
    api.post(`/lists/${listId}/contacts`, data),
  updateContact: (listId: string, contactId: string, data: any) =>
    api.put(`/lists/${listId}/contacts/${contactId}`, data),
  deleteContact: (listId: string, contactId: string) =>
    api.delete(`/lists/${listId}/contacts/${contactId}`),
  importContacts: (listId: string, file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post(`/lists/${listId}/contacts/import`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
};

// Campaigns API
export const campaignsApi = {
  getCampaigns: (params?: { status?: string; page?: number; per_page?: number }) =>
    api.get('/campaigns', { params }),
  createCampaign: (data: any) =>
    api.post('/campaigns', data),
  getCampaign: (id: string) =>
    api.get(`/campaigns/${id}`),
  updateCampaign: (id: string, data: any) =>
    api.put(`/campaigns/${id}`, data),
  deleteCampaign: (id: string) =>
    api.delete(`/campaigns/${id}`),
  sendCampaign: (id: string) =>
    api.post(`/campaigns/${id}/send`),
  testCampaign: (id: string, testEmails: string[]) =>
    api.post(`/campaigns/${id}/test`, { test_emails: testEmails }),
  pauseCampaign: (id: string) =>
    api.post(`/campaigns/${id}/pause`),
  resumeCampaign: (id: string) =>
    api.post(`/campaigns/${id}/resume`),
  cancelCampaign: (id: string) =>
    api.post(`/campaigns/${id}/cancel`),
  getStats: (id: string) =>
    api.get(`/campaigns/${id}/stats`),
};

// Emails API
export const emailsApi = {
  getEmails: (params?: { status?: string; campaign_id?: string; page?: number; per_page?: number }) =>
    api.get('/emails', { params }),
  getEmailStats: () =>
    api.get('/emails/stats'),
  sendEmail: (data: any) =>
    api.post('/emails/send', data),
  sendBulk: (data: any) =>
    api.post('/emails/send-bulk', data),
  getEmail: (id: string) =>
    api.get(`/emails/${id}`),
  retryEmail: (id: string) =>
    api.post(`/emails/${id}/retry`),
};

// SMTP API
export const smtpApi = {
  getDomains: (params?: { page?: number; per_page?: number }) =>
    api.get('/smtp/domains', { params }),
  createDomain: (data: { domain: string }) =>
    api.post('/smtp/domains', data),
  getDomain: (id: string) =>
    api.get(`/smtp/domains/${id}`),
  updateDomain: (id: string, data: any) =>
    api.put(`/smtp/domains/${id}`, data),
  deleteDomain: (id: string) =>
    api.delete(`/smtp/domains/${id}`),
  verifyDomain: (id: string) =>
    api.post(`/smtp/domains/${id}/verify`),
  getAccounts: (params?: { page?: number; per_page?: number }) =>
    api.get('/smtp/accounts', { params }),
  createAccount: (data: any) =>
    api.post('/smtp/accounts', data),
  getAccount: (id: string) =>
    api.get(`/smtp/accounts/${id}`),
  updateAccount: (id: string, data: any) =>
    api.put(`/smtp/accounts/${id}`, data),
  deleteAccount: (id: string) =>
    api.delete(`/smtp/accounts/${id}`),
  regeneratePassword: (id: string) =>
    api.post(`/smtp/accounts/${id}/regenerate-password`),
  getAccountUsage: (id: string) =>
    api.get(`/smtp/accounts/${id}/usage`),
  getSettings: () =>
    api.get('/smtp/settings'),
};

// Bounces API
export const bouncesApi = {
  getBounces: (params?: { bounce_type?: string; is_processed?: boolean; page?: number; per_page?: number }) =>
    api.get('/bounces', { params }),
  getStats: () =>
    api.get('/bounces/stats'),
  processBounces: (limit?: number) =>
    api.post('/bounces/process', null, { params: { limit } }),
  getSuppressionList: (params?: { page?: number; per_page?: number }) =>
    api.get('/bounces/suppression-list', { params }),
  removeFromSuppression: (email: string) =>
    api.delete(`/bounces/suppression-list/${email}`),
};

// Analytics API
export const analyticsApi = {
  getDashboard: () =>
    api.get('/analytics/dashboard'),
  getEmailVolume: (days?: number) =>
    api.get('/analytics/email-volume', { params: { days } }),
  getEngagement: (days?: number) =>
    api.get('/analytics/engagement', { params: { days } }),
  getTopCampaigns: (limit?: number) =>
    api.get('/analytics/top-campaigns', { params: { limit } }),
  getGeographic: () =>
    api.get('/analytics/geographic'),
  getDevices: () =>
    api.get('/analytics/devices'),
  getHourlyActivity: () =>
    api.get('/analytics/hourly-activity'),
  getBounceAnalytics: () =>
    api.get('/analytics/bounce-analytics'),
  generateReport: (startDate?: string, endDate?: string) =>
    api.get('/analytics/report', { params: { start_date: startDate, end_date: endDate } }),
};

// User API
export const userApi = {
  getMe: () =>
    api.get('/users/me'),
  updateMe: (data: any) =>
    api.put('/users/me', data),
  getApiKey: () =>
    api.get('/users/me/api-key'),
  regenerateApiKey: () =>
    api.post('/users/me/api-key/regenerate'),
};

export default api;
