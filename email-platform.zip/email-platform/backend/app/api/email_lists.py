"""
Email Lists API Routes
"""
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional
from app.database import get_db
from app.services.auth_service import AuthService, security
from app.services.list_service import ListService
from app.schemas.email_list import (
    EmailListCreate, EmailListResponse, EmailListUpdate,
    ContactCreate, ContactResponse, ContactUpdate,
    ContactImportResponse
)

router = APIRouter()


async def get_current_user(credentials=Depends(security), db=Depends(get_db)):
    """Get current authenticated user"""
    auth_service = AuthService(db)
    payload = auth_service.decode_token(credentials.credentials)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = await auth_service.get_user_by_id(payload["sub"])
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


@router.get("", response_model=dict)
async def get_lists(page: int = 1, per_page: int = 50,
                   user=Depends(get_current_user), db=Depends(get_db)):
    """Get all email lists"""
    list_service = ListService(db)
    return await list_service.get_lists(user.id, page, per_page)


@router.post("", response_model=EmailListResponse, status_code=status.HTTP_201_CREATED)
async def create_list(list_data: EmailListCreate,
                     user=Depends(get_current_user), db=Depends(get_db)):
    """Create a new email list"""
    list_service = ListService(db)
    return await list_service.create_list(user.id, list_data)


@router.get("/{list_id}", response_model=EmailListResponse)
async def get_list(list_id: str, user=Depends(get_current_user), db=Depends(get_db)):
    """Get email list by ID"""
    list_service = ListService(db)
    email_list = await list_service.get_list(list_id, user.id)
    if not email_list:
        raise HTTPException(status_code=404, detail="List not found")
    return email_list


@router.put("/{list_id}", response_model=EmailListResponse)
async def update_list(list_id: str, list_data: EmailListUpdate,
                     user=Depends(get_current_user), db=Depends(get_db)):
    """Update email list"""
    list_service = ListService(db)
    email_list = await list_service.update_list(list_id, user.id, list_data)
    if not email_list:
        raise HTTPException(status_code=404, detail="List not found")
    return email_list


@router.delete("/{list_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_list(list_id: str, user=Depends(get_current_user), db=Depends(get_db)):
    """Delete email list"""
    list_service = ListService(db)
    success = await list_service.delete_list(list_id, user.id)
    if not success:
        raise HTTPException(status_code=404, detail="List not found")
    return None


# Contact routes
@router.get("/{list_id}/contacts", response_model=dict)
async def get_contacts(list_id: str, status: Optional[str] = None,
                      page: int = 1, per_page: int = 50,
                      user=Depends(get_current_user), db=Depends(get_db)):
    """Get contacts in a list"""
    list_service = ListService(db)
    return await list_service.get_contacts(list_id, user.id, status, page, per_page)


@router.post("/{list_id}/contacts", response_model=ContactResponse, status_code=status.HTTP_201_CREATED)
async def add_contact(list_id: str, contact_data: ContactCreate,
                     user=Depends(get_current_user), db=Depends(get_db)):
    """Add a contact to a list"""
    list_service = ListService(db)
    try:
        return await list_service.add_contact(list_id, user.id, contact_data)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/{list_id}/contacts/import", response_model=ContactImportResponse)
async def import_contacts(list_id: str, file: UploadFile = File(...),
                         user=Depends(get_current_user), db=Depends(get_db)):
    """Import contacts from CSV file"""
    list_service = ListService(db)
    
    # Read file content
    content = await file.read()
    try:
        csv_content = content.decode('utf-8')
    except UnicodeDecodeError:
        csv_content = content.decode('latin-1')
    
    # Default mapping
    mapping = {"email": "email", "name": "name"}
    
    try:
        result = await list_service.import_contacts_csv(list_id, user.id, csv_content, mapping)
        return ContactImportResponse(**result)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/{list_id}/contacts/{contact_id}", response_model=ContactResponse)
async def get_contact(list_id: str, contact_id: str,
                     user=Depends(get_current_user), db=Depends(get_db)):
    """Get contact by ID"""
    list_service = ListService(db)
    contact = await list_service.get_contact(contact_id, user.id)
    if not contact or contact.email_list_id != list_id:
        raise HTTPException(status_code=404, detail="Contact not found")
    return contact


@router.put("/{list_id}/contacts/{contact_id}", response_model=ContactResponse)
async def update_contact(list_id: str, contact_id: str,
                        contact_data: ContactUpdate,
                        user=Depends(get_current_user), db=Depends(get_db)):
    """Update contact"""
    list_service = ListService(db)
    contact = await list_service.get_contact(contact_id, user.id)
    if not contact or contact.email_list_id != list_id:
        raise HTTPException(status_code=404, detail="Contact not found")
    
    updated = await list_service.update_contact(contact_id, user.id, contact_data.dict(exclude_unset=True))
    return updated


@router.delete("/{list_id}/contacts/{contact_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_contact(list_id: str, contact_id: str,
                        user=Depends(get_current_user), db=Depends(get_db)):
    """Delete contact"""
    list_service = ListService(db)
    contact = await list_service.get_contact(contact_id, user.id)
    if not contact or contact.email_list_id != list_id:
        raise HTTPException(status_code=404, detail="Contact not found")
    
    success = await list_service.delete_contact(contact_id, user.id)
    if not success:
        raise HTTPException(status_code=400, detail="Failed to delete contact")
    return None
