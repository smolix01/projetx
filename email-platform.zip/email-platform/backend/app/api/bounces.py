"""
Bounces API Routes
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional
from app.database import get_db
from app.services.auth_service import AuthService, security
from app.services.bounce_service import BounceService
from app.schemas.bounce import BounceResponse, BounceStats

router = APIRouter()


async def get_current_user(credentials=Depends(security), db=Depends(get_db)):
    """Get current authenticated user"""
    auth_service = AuthService(db)
    payload = auth_service.decode_token(credentials.credentials)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = await auth_service.get_user_by_id(payload["sub"])
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


@router.get("", response_model=dict)
async def get_bounces(bounce_type: Optional[str] = None,
                     is_processed: Optional[bool] = None,
                     page: int = 1, per_page: int = 50,
                     user=Depends(get_current_user), db=Depends(get_db)):
    """Get bounces with filtering"""
    bounce_service = BounceService(db)
    return await bounce_service.get_bounces(user.id, bounce_type, is_processed, page, per_page)


@router.get("/stats", response_model=BounceStats)
async def get_bounce_stats(user=Depends(get_current_user), db=Depends(get_db)):
    """Get bounce statistics"""
    bounce_service = BounceService(db)
    return await bounce_service.get_bounce_stats(user.id)


@router.post("/process")
async def process_bounces(limit: int = 100,
                         user=Depends(get_current_user), db=Depends(get_db)):
    """Process pending bounces"""
    bounce_service = BounceService(db)
    result = await bounce_service.process_pending_bounces(limit)
    return result


@router.get("/suppression-list", response_model=dict)
async def get_suppression_list(page: int = 1, per_page: int = 50,
                              user=Depends(get_current_user), db=Depends(get_db)):
    """Get suppression list"""
    bounce_service = BounceService(db)
    return await bounce_service.get_suppression_list(user.id, page, per_page)


@router.delete("/suppression-list/{email_address}")
async def remove_from_suppression(email_address: str,
                                 user=Depends(get_current_user), db=Depends(get_db)):
    """Remove email from suppression list"""
    bounce_service = BounceService(db)
    success = await bounce_service.remove_from_suppression(email_address)
    if not success:
        raise HTTPException(status_code=404, detail="Email not found in suppression list")
    return {"message": "Email removed from suppression list"}
