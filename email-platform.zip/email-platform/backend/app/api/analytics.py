"""
Analytics API Routes
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timedelta
from typing import Optional
from app.database import get_db
from app.services.auth_service import AuthService, security
from app.services.analytics_service import AnalyticsService

router = APIRouter()


async def get_current_user(credentials=Depends(security), db=Depends(get_db)):
    """Get current authenticated user"""
    auth_service = AuthService(db)
    payload = auth_service.decode_token(credentials.credentials)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = await auth_service.get_user_by_id(payload["sub"])
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


@router.get("/dashboard")
async def get_dashboard_analytics(user=Depends(get_current_user), db=Depends(get_db)):
    """Get dashboard analytics"""
    analytics_service = AnalyticsService(db)
    return await analytics_service.get_dashboard_stats(user.id)


@router.get("/email-volume")
async def get_email_volume(days: int = 30,
                          user=Depends(get_current_user), db=Depends(get_db)):
    """Get email volume chart data"""
    analytics_service = AnalyticsService(db)
    return await analytics_service.get_email_volume_chart(user.id, days)


@router.get("/engagement")
async def get_engagement(days: int = 30,
                        user=Depends(get_current_user), db=Depends(get_db)):
    """Get engagement chart data"""
    analytics_service = AnalyticsService(db)
    return await analytics_service.get_engagement_chart(user.id, days)


@router.get("/top-campaigns")
async def get_top_campaigns(limit: int = 5,
                           user=Depends(get_current_user), db=Depends(get_db)):
    """Get top performing campaigns"""
    analytics_service = AnalyticsService(db)
    return await analytics_service.get_top_performing_campaigns(user.id, limit)


@router.get("/geographic")
async def get_geographic_stats(user=Depends(get_current_user), db=Depends(get_db)):
    """Get geographic distribution"""
    analytics_service = AnalyticsService(db)
    return await analytics_service.get_geographic_stats(user.id)


@router.get("/devices")
async def get_device_stats(user=Depends(get_current_user), db=Depends(get_db)):
    """Get device statistics"""
    analytics_service = AnalyticsService(db)
    return await analytics_service.get_device_stats(user.id)


@router.get("/hourly-activity")
async def get_hourly_activity(user=Depends(get_current_user), db=Depends(get_db)):
    """Get hourly activity pattern"""
    analytics_service = AnalyticsService(db)
    return await analytics_service.get_hourly_activity(user.id)


@router.get("/bounce-analytics")
async def get_bounce_analytics(user=Depends(get_current_user), db=Depends(get_db)):
    """Get bounce analytics"""
    analytics_service = AnalyticsService(db)
    return await analytics_service.get_bounce_analytics(user.id)


@router.get("/report")
async def generate_report(
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    user=Depends(get_current_user), db=Depends(get_db)
):
    """Generate comprehensive report"""
    analytics_service = AnalyticsService(db)
    
    if not end_date:
        end_date = datetime.utcnow()
    if not start_date:
        start_date = end_date - timedelta(days=30)
    
    return await analytics_service.generate_report(user.id, start_date, end_date)
