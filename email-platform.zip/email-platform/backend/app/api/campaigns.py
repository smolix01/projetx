"""
Campaigns API Routes
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional, List
from app.database import get_db
from app.services.auth_service import AuthService, security
from app.services.campaign_service import CampaignService
from app.schemas.campaign import (
    CampaignCreate, CampaignResponse, CampaignUpdate,
    CampaignStats, CampaignSendRequest
)
from pydantic import BaseModel, EmailStr

router = APIRouter()


async def get_current_user(credentials=Depends(security), db=Depends(get_db)):
    """Get current authenticated user"""
    auth_service = AuthService(db)
    payload = auth_service.decode_token(credentials.credentials)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = await auth_service.get_user_by_id(payload["sub"])
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


class CampaignTestRequest(BaseModel):
    test_emails: List[EmailStr]


@router.get("", response_model=dict)
async def get_campaigns(status: Optional[str] = None, page: int = 1, per_page: int = 50,
                       user=Depends(get_current_user), db=Depends(get_db)):
    """Get all campaigns"""
    campaign_service = CampaignService(db)
    return await campaign_service.get_campaigns(user.id, status, page, per_page)


@router.post("", response_model=CampaignResponse, status_code=status.HTTP_201_CREATED)
async def create_campaign(campaign_data: CampaignCreate,
                         user=Depends(get_current_user), db=Depends(get_db)):
    """Create a new campaign"""
    campaign_service = CampaignService(db)
    return await campaign_service.create_campaign(user.id, campaign_data)


@router.get("/{campaign_id}", response_model=CampaignResponse)
async def get_campaign(campaign_id: str, user=Depends(get_current_user), db=Depends(get_db)):
    """Get campaign by ID"""
    campaign_service = CampaignService(db)
    campaign = await campaign_service.get_campaign(campaign_id, user.id)
    if not campaign:
        raise HTTPException(status_code=404, detail="Campaign not found")
    return campaign


@router.put("/{campaign_id}", response_model=CampaignResponse)
async def update_campaign(campaign_id: str, campaign_data: CampaignUpdate,
                         user=Depends(get_current_user), db=Depends(get_db)):
    """Update campaign"""
    campaign_service = CampaignService(db)
    try:
        campaign = await campaign_service.update_campaign(campaign_id, user.id, campaign_data)
        if not campaign:
            raise HTTPException(status_code=404, detail="Campaign not found")
        return campaign
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.delete("/{campaign_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_campaign(campaign_id: str, user=Depends(get_current_user), db=Depends(get_db)):
    """Delete campaign"""
    campaign_service = CampaignService(db)
    try:
        success = await campaign_service.delete_campaign(campaign_id, user.id)
        if not success:
            raise HTTPException(status_code=404, detail="Campaign not found")
        return None
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/{campaign_id}/send")
async def send_campaign(campaign_id: str,
                       user=Depends(get_current_user), db=Depends(get_db)):
    """Start sending a campaign"""
    campaign_service = CampaignService(db)
    try:
        result = await campaign_service.send_campaign(campaign_id, user.id)
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/{campaign_id}/test")
async def test_campaign(campaign_id: str, test_data: CampaignTestRequest,
                       user=Depends(get_current_user), db=Depends(get_db)):
    """Send test emails for a campaign"""
    campaign_service = CampaignService(db)
    try:
        result = await campaign_service.send_campaign(
            campaign_id, user.id,
            test_mode=True,
            test_emails=test_data.test_emails
        )
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/{campaign_id}/pause", response_model=CampaignResponse)
async def pause_campaign(campaign_id: str, user=Depends(get_current_user), db=Depends(get_db)):
    """Pause a sending campaign"""
    campaign_service = CampaignService(db)
    try:
        campaign = await campaign_service.pause_campaign(campaign_id, user.id)
        return campaign
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/{campaign_id}/resume", response_model=CampaignResponse)
async def resume_campaign(campaign_id: str, user=Depends(get_current_user), db=Depends(get_db)):
    """Resume a paused campaign"""
    campaign_service = CampaignService(db)
    try:
        campaign = await campaign_service.resume_campaign(campaign_id, user.id)
        return campaign
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/{campaign_id}/cancel", response_model=CampaignResponse)
async def cancel_campaign(campaign_id: str, user=Depends(get_current_user), db=Depends(get_db)):
    """Cancel a campaign"""
    campaign_service = CampaignService(db)
    try:
        campaign = await campaign_service.cancel_campaign(campaign_id, user.id)
        return campaign
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/{campaign_id}/stats", response_model=dict)
async def get_campaign_stats(campaign_id: str, user=Depends(get_current_user), db=Depends(get_db)):
    """Get campaign statistics"""
    campaign_service = CampaignService(db)
    try:
        stats = await campaign_service.get_campaign_stats(campaign_id, user.id)
        return stats
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
