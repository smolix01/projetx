"""
Users API Routes
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_db
from app.services.auth_service import AuthService, security
from app.schemas.user import UserResponse, UserUpdate

router = APIRouter()


async def get_current_user(credentials=Depends(security), db=Depends(get_db)):
    """Get current authenticated user"""
    auth_service = AuthService(db)
    payload = auth_service.decode_token(credentials.credentials)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = await auth_service.get_user_by_id(payload["sub"])
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


@router.get("/me", response_model=UserResponse)
async def get_current_user_info(user=Depends(get_current_user)):
    """Get current user info"""
    return user


@router.put("/me", response_model=UserResponse)
async def update_current_user(user_data: UserUpdate,
                             user=Depends(get_current_user), db=Depends(get_db)):
    """Update current user"""
    auth_service = AuthService(db)
    
    # Update user fields
    for key, value in user_data.dict(exclude_unset=True).items():
        if key == "password" and value:
            value = auth_service.get_password_hash(value)
        setattr(user, key, value)
    
    await db.commit()
    await db.refresh(user)
    
    return user


@router.get("/me/api-key")
async def get_api_key(user=Depends(get_current_user)):
    """Get current user's API key"""
    return {"api_key": user.api_key}


@router.post("/me/api-key/regenerate")
async def regenerate_api_key(user=Depends(get_current_user), db=Depends(get_db)):
    """Regenerate API key"""
    auth_service = AuthService(db)
    result = await auth_service.regenerate_api_key(user.id)
    return result
