"""
API Routes
"""
from fastapi import APIRouter
from app.api import auth, users, email_lists, campaigns, emails, smtp, bounces, tracking, analytics, dashboard

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["Authentication"])
api_router.include_router(users.router, prefix="/users", tags=["Users"])
api_router.include_router(email_lists.router, prefix="/lists", tags=["Email Lists"])
api_router.include_router(campaigns.router, prefix="/campaigns", tags=["Campaigns"])
api_router.include_router(emails.router, prefix="/emails", tags=["Emails"])
api_router.include_router(smtp.router, prefix="/smtp", tags=["SMTP"])
api_router.include_router(bounces.router, prefix="/bounces", tags=["Bounces"])
api_router.include_router(tracking.router, prefix="/tracking", tags=["Tracking"])
api_router.include_router(analytics.router, prefix="/analytics", tags=["Analytics"])
api_router.include_router(dashboard.router, prefix="/dashboard", tags=["Dashboard"])
