"""
Emails API Routes
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional, List
from app.database import get_db
from app.services.auth_service import AuthService, security
from app.services.email_service import EmailService
from app.schemas.email import (
    EmailResponse, SendEmailRequest, BulkEmailRequest,
    BulkEmailResponse, EmailStats
)

router = APIRouter()


async def get_current_user(credentials=Depends(security), db=Depends(get_db)):
    """Get current authenticated user"""
    auth_service = AuthService(db)
    payload = auth_service.decode_token(credentials.credentials)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = await auth_service.get_user_by_id(payload["sub"])
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


@router.get("", response_model=dict)
async def get_emails(status: Optional[str] = None, campaign_id: Optional[str] = None,
                    page: int = 1, per_page: int = 50,
                    user=Depends(get_current_user), db=Depends(get_db)):
    """Get all emails"""
    email_service = EmailService(db)
    return await email_service.get_emails(user.id, status, campaign_id, page, per_page)


@router.get("/stats", response_model=EmailStats)
async def get_email_stats(user=Depends(get_current_user), db=Depends(get_db)):
    """Get email statistics"""
    email_service = EmailService(db)
    return await email_service.get_email_stats(user.id)


@router.post("/send", response_model=EmailResponse)
async def send_email(email_data: SendEmailRequest,
                    user=Depends(get_current_user), db=Depends(get_db)):
    """Send a single email"""
    email_service = EmailService(db)
    
    # Use user's email as from if not specified
    from_email = email_data.from_email or user.email
    from_name = email_data.from_name or user.first_name or user.email
    
    email = await email_service.create_email(
        user_id=user.id,
        to_email=email_data.to,
        to_name=email_data.to_name,
        from_email=from_email,
        from_name=from_name,
        subject=email_data.subject,
        html_content=email_data.html,
        text_content=email_data.text,
        reply_to=email_data.reply_to,
        track_opens=email_data.track_opens,
        track_clicks=email_data.track_clicks,
        tags=email_data.tags,
        headers=email_data.headers,
    )
    
    # Queue for sending
    await email_service.queue_email(email.id)
    
    return email


@router.post("/send-bulk", response_model=BulkEmailResponse)
async def send_bulk_emails(bulk_data: BulkEmailRequest,
                          user=Depends(get_current_user), db=Depends(get_db)):
    """Send bulk emails"""
    email_service = EmailService(db)
    
    # Convert SendEmailRequest to dict
    emails_data = []
    for req in bulk_data.recipients:
        emails_data.append({
            'to': req.to,
            'to_name': req.to_name,
            'from_email': req.from_email or user.email,
            'from_name': req.from_name or user.first_name or user.email,
            'subject': req.subject,
            'html': req.html,
            'text': req.text,
            'reply_to': req.reply_to,
            'track_opens': req.track_opens,
            'track_clicks': req.track_clicks,
            'tags': req.tags,
            'headers': req.headers,
        })
    
    result = await email_service.send_bulk_emails(
        user.id, emails_data, bulk_data.batch_size
    )
    
    return BulkEmailResponse(**result)


@router.get("/{email_id}", response_model=EmailResponse)
async def get_email(email_id: str, user=Depends(get_current_user), db=Depends(get_db)):
    """Get email by ID"""
    email_service = EmailService(db)
    email = await email_service.get_email(email_id)
    if not email or email.user_id != user.id:
        raise HTTPException(status_code=404, detail="Email not found")
    return email


@router.post("/{email_id}/retry")
async def retry_email(email_id: str, user=Depends(get_current_user), db=Depends(get_db)):
    """Retry a failed email"""
    email_service = EmailService(db)
    email = await email_service.get_email(email_id)
    if not email or email.user_id != user.id:
        raise HTTPException(status_code=404, detail="Email not found")
    
    if email.status not in ["failed", "retrying"]:
        raise HTTPException(status_code=400, detail="Email is not in a retryable state")
    
    # Reset and queue
    email.status = "queued"
    email.retry_count = 0
    email.error_message = None
    await db.commit()
    
    await email_service.queue_email(email.id)
    
    return {"message": "Email queued for retry"}
