"""
Tracking API Routes
"""
from fastapi import APIRouter, Depends, HTTPException, status, Request, Response
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional
from app.database import get_db
from app.services.auth_service import AuthService, security
from app.services.tracking_service import TrackingService
from app.schemas.tracking import TrackingStats

router = APIRouter()


async def get_current_user(credentials=Depends(security), db=Depends(get_db)):
    """Get current authenticated user"""
    auth_service = AuthService(db)
    payload = auth_service.decode_token(credentials.credentials)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = await auth_service.get_user_by_id(payload["sub"])
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


@router.get("/stats", response_model=TrackingStats)
async def get_tracking_stats(campaign_id: Optional[str] = None,
                            email_id: Optional[str] = None,
                            user=Depends(get_current_user), db=Depends(get_db)):
    """Get tracking statistics"""
    tracking_service = TrackingService(db)
    return await tracking_service.get_tracking_stats(user.id, campaign_id, email_id)


@router.get("/links/{link_id}")
async def get_link_stats(link_id: str,
                        user=Depends(get_current_user), db=Depends(get_db)):
    """Get statistics for a specific link"""
    tracking_service = TrackingService(db)
    try:
        return await tracking_service.get_link_stats(link_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


# Public tracking endpoints (no auth required)
@router.get("/pixel/{pixel_id}")
async def track_open(pixel_id: str, request: Request, db=Depends(get_db)):
    """Track email open via tracking pixel"""
    tracking_service = TrackingService(db)
    
    # Get client info
    ip_address = request.client.host
    user_agent = request.headers.get("user-agent")
    
    # Track the open
    await tracking_service.track_open(pixel_id, ip_address, user_agent)
    
    # Return 1x1 transparent GIF
    pixel_data = await tracking_service.get_pixel_image()
    return Response(content=pixel_data, media_type="image/gif")


@router.get("/click/{link_id}")
async def track_click(link_id: str, request: Request, db=Depends(get_db)):
    """Track link click and redirect"""
    tracking_service = TrackingService(db)
    
    # Get client info
    ip_address = request.client.host
    user_agent = request.headers.get("user-agent")
    
    # Track the click and get original URL
    original_url = await tracking_service.track_click(link_id, ip_address, user_agent)
    
    if not original_url:
        raise HTTPException(status_code=404, detail="Link not found")
    
    # Redirect to original URL
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url=original_url)
