"""
Dashboard API Routes - Combined stats for dashboard
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_db
from app.services.auth_service import AuthService, security
from app.services.analytics_service import AnalyticsService
from app.services.email_service import EmailService
from app.services.campaign_service import CampaignService
from app.services.smtp_service import SMTPService
from app.services.bounce_service import BounceService

router = APIRouter()


async def get_current_user(credentials=Depends(security), db=Depends(get_db)):
    """Get current authenticated user"""
    auth_service = AuthService(db)
    payload = auth_service.decode_token(credentials.credentials)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = await auth_service.get_user_by_id(payload["sub"])
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


@router.get("/stats")
async def get_dashboard_stats(user=Depends(get_current_user), db=Depends(get_db)):
    """Get all dashboard statistics in one call"""
    analytics_service = AnalyticsService(db)
    email_service = EmailService(db)
    campaign_service = CampaignService(db)
    smtp_service = SMTPService(db)
    bounce_service = BounceService(db)
    
    # Get all stats
    dashboard_stats = await analytics_service.get_dashboard_stats(user.id)
    email_stats = await email_service.get_email_stats(user.id)
    bounce_stats = await bounce_service.get_bounce_stats(user.id)
    
    # Get recent campaigns
    campaigns = await campaign_service.get_campaigns(user.id, page=1, per_page=5)
    
    # Get SMTP accounts
    smtp_accounts = await smtp_service.get_accounts(user.id, page=1, per_page=5)
    
    return {
        "overview": dashboard_stats,
        "emails": email_stats,
        "bounces": bounce_stats,
        "recent_campaigns": campaigns["items"],
        "smtp_accounts": smtp_accounts["items"],
        "user": {
            "id": user.id,
            "email": user.email,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "daily_email_limit": user.daily_email_limit,
            "monthly_email_limit": user.monthly_email_limit,
        }
    }


@router.get("/charts")
async def get_dashboard_charts(user=Depends(get_current_user), db=Depends(get_db)):
    """Get dashboard chart data"""
    analytics_service = AnalyticsService(db)
    
    return {
        "email_volume": await analytics_service.get_email_volume_chart(user.id, 30),
        "engagement": await analytics_service.get_engagement_chart(user.id, 30),
        "geographic": await analytics_service.get_geographic_stats(user.id),
        "devices": await analytics_service.get_device_stats(user.id),
        "hourly_activity": await analytics_service.get_hourly_activity(user.id),
    }
