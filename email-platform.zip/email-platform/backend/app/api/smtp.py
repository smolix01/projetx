"""
SMTP API Routes
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional
from app.database import get_db
from app.services.auth_service import AuthService, security
from app.services.smtp_service import SMTPService
from app.schemas.smtp import (
    SMTPAccountCreate, SMTPAccountResponse, SMTPAccountUpdate,
    SMTPDomainCreate, SMTPDomainResponse, SMTPDomainUpdate,
    SMTPSettingsResponse
)

router = APIRouter()


async def get_current_user(credentials=Depends(security), db=Depends(get_db)):
    """Get current authenticated user"""
    auth_service = AuthService(db)
    payload = auth_service.decode_token(credentials.credentials)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = await auth_service.get_user_by_id(payload["sub"])
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


# Domain routes
@router.get("/domains", response_model=dict)
async def get_domains(page: int = 1, per_page: int = 50,
                     user=Depends(get_current_user), db=Depends(get_db)):
    """Get all SMTP domains"""
    smtp_service = SMTPService(db)
    return await smtp_service.get_domains(user.id, page, per_page)


@router.post("/domains", response_model=SMTPDomainResponse, status_code=status.HTTP_201_CREATED)
async def create_domain(domain_data: SMTPDomainCreate,
                       user=Depends(get_current_user), db=Depends(get_db)):
    """Create a new SMTP domain"""
    smtp_service = SMTPService(db)
    try:
        return await smtp_service.create_domain(user.id, domain_data)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/domains/{domain_id}", response_model=SMTPDomainResponse)
async def get_domain(domain_id: str, user=Depends(get_current_user), db=Depends(get_db)):
    """Get SMTP domain by ID"""
    smtp_service = SMTPService(db)
    domain = await smtp_service.get_domain(domain_id, user.id)
    if not domain:
        raise HTTPException(status_code=404, detail="Domain not found")
    return domain


@router.put("/domains/{domain_id}", response_model=SMTPDomainResponse)
async def update_domain(domain_id: str, domain_data: SMTPDomainUpdate,
                       user=Depends(get_current_user), db=Depends(get_db)):
    """Update SMTP domain"""
    smtp_service = SMTPService(db)
    domain = await smtp_service.update_domain(domain_id, user.id, domain_data)
    if not domain:
        raise HTTPException(status_code=404, detail="Domain not found")
    return domain


@router.delete("/domains/{domain_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_domain(domain_id: str, user=Depends(get_current_user), db=Depends(get_db)):
    """Delete SMTP domain"""
    smtp_service = SMTPService(db)
    success = await smtp_service.delete_domain(domain_id, user.id)
    if not success:
        raise HTTPException(status_code=404, detail="Domain not found")
    return None


@router.post("/domains/{domain_id}/verify")
async def verify_domain(domain_id: str, user=Depends(get_current_user), db=Depends(get_db)):
    """Verify domain DNS records"""
    smtp_service = SMTPService(db)
    try:
        result = await smtp_service.verify_domain(domain_id, user.id)
        return result
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


# Account routes
@router.get("/accounts", response_model=dict)
async def get_accounts(page: int = 1, per_page: int = 50,
                      user=Depends(get_current_user), db=Depends(get_db)):
    """Get all SMTP accounts"""
    smtp_service = SMTPService(db)
    return await smtp_service.get_accounts(user.id, page, per_page)


@router.post("/accounts", response_model=SMTPAccountResponse, status_code=status.HTTP_201_CREATED)
async def create_account(account_data: SMTPAccountCreate,
                        user=Depends(get_current_user), db=Depends(get_db)):
    """Create a new SMTP account"""
    smtp_service = SMTPService(db)
    return await smtp_service.create_account(user.id, account_data)


@router.get("/accounts/{account_id}", response_model=SMTPAccountResponse)
async def get_account(account_id: str, user=Depends(get_current_user), db=Depends(get_db)):
    """Get SMTP account by ID"""
    smtp_service = SMTPService(db)
    account = await smtp_service.get_account(account_id, user.id)
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")
    return account


@router.put("/accounts/{account_id}", response_model=SMTPAccountResponse)
async def update_account(account_id: str, account_data: SMTPAccountUpdate,
                        user=Depends(get_current_user), db=Depends(get_db)):
    """Update SMTP account"""
    smtp_service = SMTPService(db)
    account = await smtp_service.update_account(account_id, user.id, account_data)
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")
    return account


@router.delete("/accounts/{account_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_account(account_id: str, user=Depends(get_current_user), db=Depends(get_db)):
    """Delete SMTP account"""
    smtp_service = SMTPService(db)
    success = await smtp_service.delete_account(account_id, user.id)
    if not success:
        raise HTTPException(status_code=404, detail="Account not found")
    return None


@router.post("/accounts/{account_id}/regenerate-password")
async def regenerate_password(account_id: str, user=Depends(get_current_user), db=Depends(get_db)):
    """Regenerate SMTP account password"""
    smtp_service = SMTPService(db)
    try:
        result = await smtp_service.regenerate_password(account_id, user.id)
        return result
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/accounts/{account_id}/usage")
async def get_account_usage(account_id: str, user=Depends(get_current_user), db=Depends(get_db)):
    """Get SMTP account usage statistics"""
    smtp_service = SMTPService(db)
    try:
        result = await smtp_service.get_account_usage(account_id, user.id)
        return result
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/settings", response_model=SMTPSettingsResponse)
async def get_smtp_settings(user=Depends(get_current_user), db=Depends(get_db)):
    """Get SMTP server settings"""
    smtp_service = SMTPService(db)
    return await smtp_service.get_smtp_settings()
