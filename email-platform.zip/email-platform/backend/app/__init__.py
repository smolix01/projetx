"""
Email Delivery Platform - Backend API
Production-Grade Email SaaS Platform
"""

__version__ = "1.0.0"
__author__ = "Email Platform Team"
