"""
Application Configuration
"""
from pydantic_settings import BaseSettings
from typing import List, Optional
import os


class Settings(BaseSettings):
    """Application settings loaded from environment variables"""
    
    # Application
    APP_NAME: str = "Email Delivery Platform"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    SECRET_KEY: str = "your-super-secret-key-change-in-production"
    
    # Server
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    
    # Database
    DATABASE_URL: str = "postgresql+asyncpg://emailuser:emailpass@localhost:5432/emailplatform"
    DATABASE_POOL_SIZE: int = 20
    DATABASE_MAX_OVERFLOW: int = 10
    
    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_POOL_SIZE: int = 10
    
    # JWT
    JWT_SECRET: str = "jwt-secret-key-change-in-production"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRATION_HOURS: int = 24
    
    # SMTP Server Settings
    SMTP_HOST: str = "localhost"
    SMTP_PORT: int = 587
    SMTP_TLS: bool = True
    SMTP_SSL: bool = False
    SMTP_USERNAME: Optional[str] = None
    SMTP_PASSWORD: Optional[str] = None
    
    # Postfix Settings
    POSTFIX_HOST: str = "localhost"
    POSTFIX_PORT: int = 25
    POSTFIX_USE_TLS: bool = False
    
    # Bounce Processing
    BOUNCE_IMAP_HOST: str = "localhost"
    BOUNCE_IMAP_PORT: int = 993
    BOUNCE_IMAP_USER: str = "bounce@localhost"
    BOUNCE_IMAP_PASSWORD: str = ""
    BOUNCE_CHECK_INTERVAL: int = 300  # 5 minutes
    
    # Tracking
    TRACKING_DOMAIN: str = "track.localhost"
    TRACKING_ENABLED: bool = True
    
    # Rate Limiting
    RATE_LIMIT_PER_MINUTE: int = 60
    RATE_LIMIT_PER_HOUR: int = 1000
    RATE_LIMIT_PER_DAY: int = 10000
    
    # Bulk Email
    BULK_BATCH_SIZE: int = 100
    BULK_WORKER_COUNT: int = 4
    BULK_SEND_INTERVAL: int = 1  # seconds between batches
    
    # File Upload
    MAX_UPLOAD_SIZE: int = 50 * 1024 * 1024  # 50MB
    UPLOAD_DIR: str = "/tmp/uploads"
    
    # Security
    ALLOWED_HOSTS: List[str] = ["*"]
    CORS_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:5173"]
    
    # DKIM/SPF
    DKIM_PRIVATE_KEY_PATH: Optional[str] = None
    DKIM_SELECTOR: str = "default"
    
    class Config:
        env_file = ".env"
        case_sensitive = True


# Global settings instance
settings = Settings()
