"""
Campaign Models
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey, JSON, Index, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.database import Base
import uuid
import enum


def generate_uuid():
    return str(uuid.uuid4())


class CampaignStatus(str, enum.Enum):
    DRAFT = "draft"
    SCHEDULED = "scheduled"
    SENDING = "sending"
    SENT = "sent"
    PAUSED = "paused"
    CANCELLED = "cancelled"


class Campaign(Base):
    __tablename__ = "campaigns"
    
    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Campaign info
    name = Column(String(255), nullable=False)
    subject = Column(String(500), nullable=False)
    
    # Content
    html_content = Column(Text, nullable=True)
    text_content = Column(Text, nullable=True)
    from_name = Column(String(255), nullable=False)
    from_email = Column(String(255), nullable=False)
    reply_to = Column(String(255), nullable=True)
    
    # Status
    status = Column(String(20), default=CampaignStatus.DRAFT)
    
    # Scheduling
    scheduled_at = Column(DateTime(timezone=True), nullable=True)
    started_at = Column(DateTime(timezone=True), nullable=True)
    completed_at = Column(DateTime(timezone=True), nullable=True)
    
    # Targeting
    email_list_id = Column(String(36), ForeignKey("email_lists.id", ondelete="SET NULL"), nullable=True)
    segment_conditions = Column(JSON, nullable=True)  # JSON conditions for segmentation
    
    # Tracking
    track_opens = Column(Boolean, default=True)
    track_clicks = Column(Boolean, default=True)
    
    # Statistics
    total_recipients = Column(Integer, default=0)
    sent_count = Column(Integer, default=0)
    delivered_count = Column(Integer, default=0)
    opened_count = Column(Integer, default=0)
    clicked_count = Column(Integer, default=0)
    bounced_count = Column(Integer, default=0)
    complained_count = Column(Integer, default=0)
    unsubscribed_count = Column(Integer, default=0)
    
    # Unique tracking
    unique_opens = Column(Integer, default=0)
    unique_clicks = Column(Integer, default=0)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    user = relationship("User", back_populates="campaigns")
    email_list = relationship("EmailList")
    recipients = relationship("CampaignRecipient", back_populates="campaign", cascade="all, delete-orphan")
    
    __table_args__ = (
        Index('idx_campaign_user_id', 'user_id'),
        Index('idx_campaign_status', 'status'),
        Index('idx_campaign_user_status', 'user_id', 'status'),
        Index('idx_campaign_scheduled', 'scheduled_at'),
    )


class CampaignRecipient(Base):
    __tablename__ = "campaign_recipients"
    
    id = Column(String(36), primary_key=True, default=generate_uuid)
    campaign_id = Column(String(36), ForeignKey("campaigns.id", ondelete="CASCADE"), nullable=False, index=True)
    contact_id = Column(String(36), ForeignKey("contacts.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Status
    status = Column(String(20), default="pending")  # pending, sent, delivered, opened, clicked, bounced, complained
    
    # Tracking
    sent_at = Column(DateTime(timezone=True), nullable=True)
    delivered_at = Column(DateTime(timezone=True), nullable=True)
    opened_at = Column(DateTime(timezone=True), nullable=True)
    clicked_at = Column(DateTime(timezone=True), nullable=True)
    bounced_at = Column(DateTime(timezone=True), nullable=True)
    
    # Open/Click tracking
    open_count = Column(Integer, default=0)
    click_count = Column(Integer, default=0)
    
    # Tracking IDs
    tracking_pixel_id = Column(String(36), nullable=True)
    
    # Error info
    error_message = Column(Text, nullable=True)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    campaign = relationship("Campaign", back_populates="recipients")
    contact = relationship("Contact")
    
    __table_args__ = (
        Index('idx_recipient_campaign', 'campaign_id'),
        Index('idx_recipient_contact', 'contact_id'),
        Index('idx_recipient_status', 'status'),
        Index('idx_recipient_campaign_status', 'campaign_id', 'status'),
    )
