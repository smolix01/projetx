"""
Email Tracking Models (Opens and Clicks)
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey, JSON, Index
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.database import Base
import uuid


def generate_uuid():
    return str(uuid.uuid4())


class TrackingPixel(Base):
    """Tracking pixels for email opens"""
    __tablename__ = "tracking_pixels"
    
    id = Column(String(36), primary_key=True, default=generate_uuid)
    pixel_id = Column(String(64), unique=True, nullable=False, index=True)
    
    # References
    email_id = Column(String(36), ForeignKey("emails.id", ondelete="CASCADE"), nullable=False, index=True)
    campaign_id = Column(String(36), ForeignKey("campaigns.id", ondelete="SET NULL"), nullable=True)
    contact_id = Column(String(36), ForeignKey("contacts.id", ondelete="SET NULL"), nullable=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Status
    is_opened = Column(Boolean, default=False)
    open_count = Column(Integer, default=0)
    first_opened_at = Column(DateTime(timezone=True), nullable=True)
    last_opened_at = Column(DateTime(timezone=True), nullable=True)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    __table_args__ = (
        Index('idx_pixel_pixel_id', 'pixel_id'),
        Index('idx_pixel_email_id', 'email_id'),
        Index('idx_pixel_campaign_id', 'campaign_id'),
        Index('idx_pixel_contact_id', 'contact_id'),
        Index('idx_pixel_user_id', 'user_id'),
        Index('idx_pixel_opened', 'is_opened'),
    )


class TrackingLink(Base):
    """Tracking links for email clicks"""
    __tablename__ = "tracking_links"
    
    id = Column(String(36), primary_key=True, default=generate_uuid)
    link_id = Column(String(64), unique=True, nullable=False, index=True)
    
    # References
    email_id = Column(String(36), ForeignKey("emails.id", ondelete="CASCADE"), nullable=False, index=True)
    campaign_id = Column(String(36), ForeignKey("campaigns.id", ondelete="SET NULL"), nullable=True)
    contact_id = Column(String(36), ForeignKey("contacts.id", ondelete="SET NULL"), nullable=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Link info
    original_url = Column(Text, nullable=False)
    shortened_url = Column(Text, nullable=True)
    
    # Status
    click_count = Column(Integer, default=0)
    unique_clicks = Column(Integer, default=0)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    events = relationship("TrackingEvent", back_populates="link", cascade="all, delete-orphan")
    
    __table_args__ = (
        Index('idx_link_link_id', 'link_id'),
        Index('idx_link_email_id', 'email_id'),
        Index('idx_link_campaign_id', 'campaign_id'),
        Index('idx_link_contact_id', 'contact_id'),
        Index('idx_link_user_id', 'user_id'),
    )


class TrackingEvent(Base):
    """Individual tracking events (opens and clicks)"""
    __tablename__ = "tracking_events"
    
    id = Column(String(36), primary_key=True, default=generate_uuid)
    
    # Event type
    event_type = Column(String(20), nullable=False)  # open, click
    
    # References
    email_id = Column(String(36), ForeignKey("emails.id", ondelete="CASCADE"), nullable=False, index=True)
    campaign_id = Column(String(36), ForeignKey("campaigns.id", ondelete="SET NULL"), nullable=True)
    contact_id = Column(String(36), ForeignKey("contacts.id", ondelete="SET NULL"), nullable=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    link_id = Column(String(36), ForeignKey("tracking_links.id", ondelete="CASCADE"), nullable=True)
    
    # Client info
    ip_address = Column(String(45), nullable=True)
    user_agent = Column(Text, nullable=True)
    
    # Device info (parsed from user agent)
    device_type = Column(String(50), nullable=True)  # desktop, mobile, tablet
    browser = Column(String(100), nullable=True)
    browser_version = Column(String(50), nullable=True)
    operating_system = Column(String(100), nullable=True)
    os_version = Column(String(50), nullable=True)
    
    # Location info
    country = Column(String(100), nullable=True)
    country_code = Column(String(5), nullable=True)
    region = Column(String(100), nullable=True)
    city = Column(String(100), nullable=True)
    latitude = Column(String(20), nullable=True)
    longitude = Column(String(20), nullable=True)
    
    # For clicks
    clicked_url = Column(Text, nullable=True)
    
    # Timestamp
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    link = relationship("TrackingLink", back_populates="events")
    
    __table_args__ = (
        Index('idx_event_type', 'event_type'),
        Index('idx_event_email_id', 'email_id'),
        Index('idx_event_campaign_id', 'campaign_id'),
        Index('idx_event_contact_id', 'contact_id'),
        Index('idx_event_user_id', 'user_id'),
        Index('idx_event_link_id', 'link_id'),
        Index('idx_event_created', 'created_at'),
        Index('idx_event_user_type', 'user_id', 'event_type'),
        Index('idx_event_campaign_type', 'campaign_id', 'event_type'),
    )
