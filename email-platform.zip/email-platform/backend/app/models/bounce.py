"""
Bounce and Bounce Log Models
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey, JSON, Index
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.database import Base
import uuid


def generate_uuid():
    return str(uuid.uuid4())


class Bounce(Base):
    """Email bounces tracking"""
    __tablename__ = "bounces"
    
    id = Column(String(36), primary_key=True, default=generate_uuid)
    email_id = Column(String(36), ForeignKey("emails.id", ondelete="CASCADE"), nullable=True, index=True)
    contact_id = Column(String(36), ForeignKey("contacts.id", ondelete="SET NULL"), nullable=True, index=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Bounce info
    email_address = Column(String(255), nullable=False, index=True)
    bounce_type = Column(String(20), nullable=False)  # hard, soft
    
    # Bounce reason
    bounce_code = Column(String(10), nullable=True)
    bounce_reason = Column(Text, nullable=True)
    bounce_category = Column(String(50), nullable=True)  # invalid_email, mailbox_full, domain_error, etc.
    
    # Original message info
    original_message_id = Column(String(255), nullable=True)
    original_subject = Column(String(500), nullable=True)
    
    # DSN info
    dsn_message = Column(Text, nullable=True)
    dsn_status = Column(String(20), nullable=True)
    dsn_diagnostic_code = Column(Text, nullable=True)
    
    # Remote MTA info
    remote_mta = Column(String(255), nullable=True)
    reporting_mta = Column(String(255), nullable=True)
    
    # Processing
    is_processed = Column(Boolean, default=False)
    processed_at = Column(DateTime(timezone=True), nullable=True)
    
    # Action taken
    action_taken = Column(String(50), nullable=True)  # removed, suppressed, retry_scheduled
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    bounce_timestamp = Column(DateTime(timezone=True), nullable=True)
    
    # Relationships
    email = relationship("Email")
    contact = relationship("Contact")
    user = relationship("User")
    logs = relationship("BounceLog", back_populates="bounce", cascade="all, delete-orphan")
    
    __table_args__ = (
        Index('idx_bounce_email_id', 'email_id'),
        Index('idx_bounce_contact_id', 'contact_id'),
        Index('idx_bounce_user_id', 'user_id'),
        Index('idx_bounce_type', 'bounce_type'),
        Index('idx_bounce_email_addr', 'email_address'),
        Index('idx_bounce_processed', 'is_processed'),
        Index('idx_bounce_created', 'created_at'),
    )


class BounceLog(Base):
    """Detailed bounce processing logs"""
    __tablename__ = "bounce_logs"
    
    id = Column(String(36), primary_key=True, default=generate_uuid)
    bounce_id = Column(String(36), ForeignKey("bounces.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Log info
    action = Column(String(50), nullable=False)  # detected, classified, processed, contact_updated
    details = Column(JSON, nullable=True)
    
    # Timestamp
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    bounce = relationship("Bounce", back_populates="logs")
    
    __table_args__ = (
        Index('idx_bounce_log_bounce_id', 'bounce_id'),
        Index('idx_bounce_log_action', 'action'),
        Index('idx_bounce_log_created', 'created_at'),
    )


class SuppressedEmail(Base):
    """Globally suppressed emails (complaints, hard bounces)"""
    __tablename__ = "suppressed_emails"
    
    id = Column(String(36), primary_key=True, default=generate_uuid)
    email_address = Column(String(255), nullable=False, unique=True, index=True)
    
    # Suppression reason
    reason = Column(String(50), nullable=False)  # bounce, complaint, unsubscribe, manual
    reason_details = Column(Text, nullable=True)
    
    # Source
    source_type = Column(String(50), nullable=True)  # bounce, campaign, manual
    source_id = Column(String(36), nullable=True)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    __table_args__ = (
        Index('idx_suppressed_email', 'email_address'),
        Index('idx_suppressed_reason', 'reason'),
    )
