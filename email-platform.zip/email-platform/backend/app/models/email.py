"""
Email and Email Log Models
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey, JSON, Index, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.database import Base
import uuid
import enum


def generate_uuid():
    return str(uuid.uuid4())


class EmailStatus(str, enum.Enum):
    QUEUED = "queued"
    SENDING = "sending"
    SENT = "sent"
    DELIVERED = "delivered"
    OPENED = "opened"
    CLICKED = "clicked"
    BOUNCED = "bounced"
    FAILED = "failed"
    RETRYING = "retrying"


class Email(Base):
    """Individual emails sent through the system"""
    __tablename__ = "emails"
    
    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Email info
    message_id = Column(String(255), unique=True, nullable=True, index=True)
    
    # Recipients
    to_email = Column(String(255), nullable=False, index=True)
    to_name = Column(String(255), nullable=True)
    from_email = Column(String(255), nullable=False)
    from_name = Column(String(255), nullable=True)
    reply_to = Column(String(255), nullable=True)
    
    # Content
    subject = Column(String(500), nullable=False)
    html_content = Column(Text, nullable=True)
    text_content = Column(Text, nullable=True)
    
    # Status
    status = Column(String(20), default=EmailStatus.QUEUED)
    
    # Tracking
    track_opens = Column(Boolean, default=True)
    track_clicks = Column(Boolean, default=True)
    
    # Campaign reference (optional)
    campaign_id = Column(String(36), ForeignKey("campaigns.id", ondelete="SET NULL"), nullable=True)
    
    # SMTP info
    smtp_account_id = Column(String(36), ForeignKey("smtp_accounts.id", ondelete="SET NULL"), nullable=True)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    sent_at = Column(DateTime(timezone=True), nullable=True)
    delivered_at = Column(DateTime(timezone=True), nullable=True)
    opened_at = Column(DateTime(timezone=True), nullable=True)
    clicked_at = Column(DateTime(timezone=True), nullable=True)
    bounced_at = Column(DateTime(timezone=True), nullable=True)
    
    # Retry logic
    retry_count = Column(Integer, default=0)
    max_retries = Column(Integer, default=3)
    next_retry_at = Column(DateTime(timezone=True), nullable=True)
    
    # Error info
    error_message = Column(Text, nullable=True)
    
    # Metadata
    headers = Column(JSON, nullable=True)
    tags = Column(JSON, nullable=True)
    
    # Relationships
    user = relationship("User", back_populates="emails")
    campaign = relationship("Campaign")
    smtp_account = relationship("SMTPAccount")
    logs = relationship("EmailLog", back_populates="email", cascade="all, delete-orphan")
    events = relationship("EmailEvent", back_populates="email", cascade="all, delete-orphan")
    
    __table_args__ = (
        Index('idx_email_user_id', 'user_id'),
        Index('idx_email_status', 'status'),
        Index('idx_email_to', 'to_email'),
        Index('idx_email_user_status', 'user_id', 'status'),
        Index('idx_email_campaign', 'campaign_id'),
        Index('idx_email_created', 'created_at'),
    )


class EmailLog(Base):
    """Detailed logs for each email"""
    __tablename__ = "email_logs"
    
    id = Column(String(36), primary_key=True, default=generate_uuid)
    email_id = Column(String(36), ForeignKey("emails.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Log info
    event_type = Column(String(50), nullable=False)  # queued, sent, delivered, opened, clicked, bounced, failed
    event_data = Column(JSON, nullable=True)
    
    # IP and user agent
    ip_address = Column(String(45), nullable=True)
    user_agent = Column(Text, nullable=True)
    
    # Timestamp
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    email = relationship("Email", back_populates="logs")
    
    __table_args__ = (
        Index('idx_log_email_id', 'email_id'),
        Index('idx_log_event_type', 'event_type'),
        Index('idx_log_created', 'created_at'),
    )


class EmailEvent(Base):
    """Aggregated email events for analytics"""
    __tablename__ = "email_events"
    
    id = Column(String(36), primary_key=True, default=generate_uuid)
    email_id = Column(String(36), ForeignKey("emails.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Event info
    event_type = Column(String(50), nullable=False)  # open, click, bounce, complaint, unsubscribe
    event_count = Column(Integer, default=1)
    
    # Event data
    link_url = Column(Text, nullable=True)  # For click events
    bounce_type = Column(String(20), nullable=True)  # For bounce events
    bounce_reason = Column(Text, nullable=True)
    
    # IP and user agent
    ip_address = Column(String(45), nullable=True)
    user_agent = Column(Text, nullable=True)
    country = Column(String(100), nullable=True)
    
    # Timestamp
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    email = relationship("Email", back_populates="events")
    user = relationship("User")
    
    __table_args__ = (
        Index('idx_event_email_id', 'email_id'),
        Index('idx_event_user_id', 'user_id'),
        Index('idx_event_type', 'event_type'),
        Index('idx_event_created', 'created_at'),
        Index('idx_event_user_type', 'user_id', 'event_type'),
    )
