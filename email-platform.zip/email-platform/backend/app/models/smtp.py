"""
SMTP Account and Domain Models
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey, JSON, Index
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.database import Base
import uuid
import secrets


def generate_uuid():
    return str(uuid.uuid4())


def generate_smtp_password():
    return secrets.token_urlsafe(32)


class SMTPDomain(Base):
    """Domains configured for SMTP sending"""
    __tablename__ = "smtp_domains"
    
    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Domain info
    domain = Column(String(255), nullable=False, index=True)
    is_verified = Column(Boolean, default=False)
    
    # DNS Records
    spf_record = Column(String(500), nullable=True)
    dkim_record = Column(Text, nullable=True)
    dmarc_record = Column(String(500), nullable=True)
    mx_record = Column(String(500), nullable=True)
    
    # Verification
    verification_token = Column(String(64), nullable=True)
    verified_at = Column(DateTime(timezone=True), nullable=True)
    
    # DKIM
    dkim_private_key = Column(Text, nullable=True)
    dkim_selector = Column(String(100), default="default")
    
    # Status
    is_active = Column(Boolean, default=True)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    user = relationship("User", back_populates="smtp_domains")
    accounts = relationship("SMTPAccount", back_populates="domain", cascade="all, delete-orphan")
    
    __table_args__ = (
        Index('idx_domain_user_id', 'user_id'),
        Index('idx_domain_name', 'domain'),
        Index('idx_domain_verified', 'is_verified'),
    )


class SMTPAccount(Base):
    """SMTP credentials for users"""
    __tablename__ = "smtp_accounts"
    
    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    domain_id = Column(String(36), ForeignKey("smtp_domains.id", ondelete="CASCADE"), nullable=True, index=True)
    
    # Account info
    username = Column(String(255), nullable=False, unique=True, index=True)
    password_hash = Column(String(255), nullable=False)
    
    # Display name
    name = Column(String(255), nullable=True)
    description = Column(Text, nullable=True)
    
    # Rate limiting
    hourly_limit = Column(Integer, default=100)
    daily_limit = Column(Integer, default=1000)
    monthly_limit = Column(Integer, default=30000)
    
    # Current usage
    emails_sent_hour = Column(Integer, default=0)
    emails_sent_day = Column(Integer, default=0)
    emails_sent_month = Column(Integer, default=0)
    
    # Usage reset timestamps
    hour_reset_at = Column(DateTime(timezone=True), nullable=True)
    day_reset_at = Column(DateTime(timezone=True), nullable=True)
    month_reset_at = Column(DateTime(timezone=True), nullable=True)
    
    # Status
    is_active = Column(Boolean, default=True)
    
    # Security
    allowed_ips = Column(JSON, nullable=True)  # List of allowed IP addresses
    require_tls = Column(Boolean, default=True)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    last_used_at = Column(DateTime(timezone=True), nullable=True)
    
    # Relationships
    user = relationship("User", back_populates="smtp_accounts")
    domain = relationship("SMTPDomain", back_populates="accounts")
    
    __table_args__ = (
        Index('idx_smtp_user_id', 'user_id'),
        Index('idx_smtp_username', 'username'),
        Index('idx_smtp_active', 'is_active'),
    )
