"""
User Model
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Index
from sqlalchemy.sql import func
from app.database import Base
import uuid


def generate_uuid():
    return str(uuid.uuid4())


class User(Base):
    __tablename__ = "users"
    
    id = Column(String(36), primary_key=True, default=generate_uuid)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    first_name = Column(String(100), nullable=True)
    last_name = Column(String(100), nullable=True)
    
    # Role and permissions
    is_admin = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    
    # API Access
    api_key = Column(String(64), unique=True, nullable=True, index=True)
    api_secret = Column(String(255), nullable=True)
    
    # Quota and limits
    daily_email_limit = Column(Integer, default=1000)
    monthly_email_limit = Column(Integer, default=30000)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    last_login = Column(DateTime(timezone=True), nullable=True)
    
    # Metadata
    company_name = Column(String(255), nullable=True)
    timezone = Column(String(50), default="UTC")
    
    __table_args__ = (
        Index('idx_user_email_active', 'email', 'is_active'),
        Index('idx_user_api_key', 'api_key'),
    )
