"""
Email List and Contact Models
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey, JSON, Index, Table
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.database import Base
import uuid


def generate_uuid():
    return str(uuid.uuid4())


class EmailList(Base):
    __tablename__ = "email_lists"
    
    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # List info
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    
    # List settings
    is_public = Column(Boolean, default=False)
    double_opt_in = Column(Boolean, default=True)
    
    # Auto-clean settings
    auto_clean_enabled = Column(Boolean, default=True)
    auto_clean_after_bounces = Column(Integer, default=3)  # Remove after X bounces
    
    # Statistics (cached)
    total_contacts = Column(Integer, default=0)
    active_contacts = Column(Integer, default=0)
    bounced_contacts = Column(Integer, default=0)
    unsubscribed_contacts = Column(Integer, default=0)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    user = relationship("User", back_populates="email_lists")
    contacts = relationship("Contact", back_populates="email_list", cascade="all, delete-orphan")
    
    __table_args__ = (
        Index('idx_list_user_id', 'user_id'),
        Index('idx_list_name_user', 'name', 'user_id'),
    )


class Contact(Base):
    __tablename__ = "contacts"
    
    id = Column(String(36), primary_key=True, default=generate_uuid)
    email_list_id = Column(String(36), ForeignKey("email_lists.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Contact info
    email = Column(String(255), nullable=False, index=True)
    name = Column(String(255), nullable=True)
    
    # Status
    status = Column(String(20), default="active")  # active, bounced, unsubscribed, complained
    
    # Validation
    is_valid = Column(Boolean, default=True)
    validation_message = Column(Text, nullable=True)
    
    # Engagement
    last_sent_at = Column(DateTime(timezone=True), nullable=True)
    last_opened_at = Column(DateTime(timezone=True), nullable=True)
    last_clicked_at = Column(DateTime(timezone=True), nullable=True)
    
    # Statistics
    send_count = Column(Integer, default=0)
    open_count = Column(Integer, default=0)
    click_count = Column(Integer, default=0)
    bounce_count = Column(Integer, default=0)
    
    # Bounce info
    last_bounce_at = Column(DateTime(timezone=True), nullable=True)
    bounce_reason = Column(Text, nullable=True)
    bounce_type = Column(String(20), nullable=True)  # hard, soft
    
    # Unsubscribe
    unsubscribed_at = Column(DateTime(timezone=True), nullable=True)
    unsubscribe_reason = Column(Text, nullable=True)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    email_list = relationship("EmailList", back_populates="contacts")
    user = relationship("User", back_populates="contacts")
    attributes = relationship("ContactAttribute", back_populates="contact", cascade="all, delete-orphan")
    
    __table_args__ = (
        Index('idx_contact_email_list', 'email', 'email_list_id'),
        Index('idx_contact_status', 'status'),
        Index('idx_contact_user_id', 'user_id'),
        Index('idx_contact_list_status', 'email_list_id', 'status'),
    )


class ContactAttribute(Base):
    """Dynamic attributes for contacts (custom fields)"""
    __tablename__ = "contact_attributes"
    
    id = Column(String(36), primary_key=True, default=generate_uuid)
    contact_id = Column(String(36), ForeignKey("contacts.id", ondelete="CASCADE"), nullable=False, index=True)
    
    key = Column(String(100), nullable=False)
    value = Column(Text, nullable=True)
    data_type = Column(String(20), default="string")  # string, number, date, boolean
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    contact = relationship("Contact", back_populates="attributes")
    
    __table_args__ = (
        Index('idx_attr_contact_key', 'contact_id', 'key'),
    )
