"""
Email Service - Core email sending functionality
"""
from datetime import datetime
from typing import Optional, List, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, func
from sqlalchemy.orm import selectinload
import aiosmtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formatdate
import uuid
import logging

from app.config import settings
from app.models.email import Email, EmailStatus, EmailLog
from app.models.smtp import SMTPAccount
from app.services.tracking_service import TrackingService
from app.services.queue_service import QueueService

logger = logging.getLogger(__name__)


class EmailService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.tracking_service = TrackingService(db)
        self.queue_service = QueueService()
    
    async def create_email(self, user_id: str, to_email: str, to_name: Optional[str],
                          from_email: str, from_name: Optional[str], subject: str,
                          html_content: Optional[str], text_content: Optional[str],
                          reply_to: Optional[str] = None, track_opens: bool = True,
                          track_clicks: bool = True, campaign_id: Optional[str] = None,
                          smtp_account_id: Optional[str] = None,
                          tags: Optional[List[str]] = None,
                          headers: Optional[Dict[str, str]] = None) -> Email:
        """Create a new email record"""
        
        email = Email(
            id=str(uuid.uuid4()),
            user_id=user_id,
            to_email=to_email,
            to_name=to_name,
            from_email=from_email,
            from_name=from_name,
            subject=subject,
            html_content=html_content,
            text_content=text_content,
            reply_to=reply_to,
            track_opens=track_opens,
            track_clicks=track_clicks,
            campaign_id=campaign_id,
            smtp_account_id=smtp_account_id,
            status=EmailStatus.QUEUED,
            tags=tags or [],
            headers=headers or {},
        )
        
        self.db.add(email)
        await self.db.commit()
        await self.db.refresh(email)
        
        # Add log entry
        log = EmailLog(
            email_id=email.id,
            event_type="queued",
            event_data={"message": "Email queued for sending"}
        )
        self.db.add(log)
        await self.db.commit()
        
        logger.info(f"Created email {email.id} for {to_email}")
        return email
    
    async def send_email(self, email_id: str) -> bool:
        """Send a single email via SMTP"""
        
        result = await self.db.execute(
            select(Email).where(Email.id == email_id)
        )
        email = result.scalar_one_or_none()
        
        if not email:
            logger.error(f"Email {email_id} not found")
            return False
        
        try:
            # Update status to sending
            email.status = EmailStatus.SENDING
            await self.db.commit()
            
            # Get SMTP account
            smtp_account = None
            if email.smtp_account_id:
                result = await self.db.execute(
                    select(SMTPAccount).where(SMTPAccount.id == email.smtp_account_id)
                )
                smtp_account = result.scalar_one_or_none()
            
            # Prepare email content with tracking
            html_content = email.html_content
            text_content = email.text_content
            
            if email.track_opens:
                # Add tracking pixel
                tracking_pixel = await self.tracking_service.create_tracking_pixel(
                    email_id=email.id,
                    user_id=email.user_id,
                    campaign_id=email.campaign_id
                )
                pixel_url = f"https://{settings.TRACKING_DOMAIN}/track/pixel/{tracking_pixel.pixel_id}"
                pixel_img = f'<img src="{pixel_url}" width="1" height="1" alt="" />'
                if html_content:
                    html_content = html_content + pixel_img
            
            if email.track_clicks and html_content:
                # Replace links with tracking links
                html_content = await self.tracking_service.replace_links(
                    html_content=html_content,
                    email_id=email.id,
                    user_id=email.user_id,
                    campaign_id=email.campaign_id
                )
            
            # Build MIME message
            msg = MIMEMultipart('alternative')
            msg['Subject'] = email.subject
            msg['From'] = f"{email.from_name or email.from_email} <{email.from_email}>"
            msg['To'] = f"{email.to_name or email.to_email} <{email.to_email}>"
            msg['Date'] = formatdate(localtime=True)
            msg['Message-ID'] = f"<{email.id}@{settings.TRACKING_DOMAIN}>"
            
            if email.reply_to:
                msg['Reply-To'] = email.reply_to
            
            # Add custom headers
            for key, value in (email.headers or {}).items():
                msg[key] = value
            
            # Attach content
            if text_content:
                msg.attach(MIMEText(text_content, 'plain', 'utf-8'))
            if html_content:
                msg.attach(MIMEText(html_content, 'html', 'utf-8'))
            
            # Send via SMTP
            smtp_host = smtp_account.domain.domain if smtp_account and smtp_account.domain else settings.SMTP_HOST
            smtp_port = settings.SMTP_PORT
            
            await aiosmtplib.send(
                msg,
                hostname=smtp_host,
                port=smtp_port,
                use_tls=settings.SMTP_TLS,
                username=settings.SMTP_USERNAME,
                password=settings.SMTP_PASSWORD,
            )
            
            # Update email status
            email.status = EmailStatus.SENT
            email.sent_at = datetime.utcnow()
            email.message_id = msg['Message-ID']
            await self.db.commit()
            
            # Add log entry
            log = EmailLog(
                email_id=email.id,
                event_type="sent",
                event_data={"smtp_host": smtp_host, "smtp_port": smtp_port}
            )
            self.db.add(log)
            await self.db.commit()
            
            logger.info(f"Successfully sent email {email.id} to {email.to_email}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to send email {email.id}: {str(e)}")
            
            # Update status to failed or retrying
            email.retry_count += 1
            if email.retry_count >= email.max_retries:
                email.status = EmailStatus.FAILED
                email.error_message = str(e)
            else:
                email.status = EmailStatus.RETRYING
                email.next_retry_at = datetime.utcnow() + timedelta(minutes=5 * email.retry_count)
            
            await self.db.commit()
            
            # Add log entry
            log = EmailLog(
                email_id=email.id,
                event_type="failed",
                event_data={"error": str(e), "retry_count": email.retry_count}
            )
            self.db.add(log)
            await self.db.commit()
            
            return False
    
    async def queue_email(self, email_id: str) -> bool:
        """Add email to sending queue"""
        try:
            await self.queue_service.enqueue('send_email', {'email_id': email_id})
            logger.info(f"Queued email {email_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to queue email {email_id}: {str(e)}")
            return False
    
    async def get_email(self, email_id: str) -> Optional[Email]:
        """Get email by ID"""
        result = await self.db.execute(
            select(Email).where(Email.id == email_id)
        )
        return result.scalar_one_or_none()
    
    async def get_emails(self, user_id: str, status: Optional[str] = None,
                        campaign_id: Optional[str] = None,
                        page: int = 1, per_page: int = 50) -> Dict[str, Any]:
        """Get emails with filtering"""
        
        query = select(Email).where(Email.user_id == user_id)
        
        if status:
            query = query.where(Email.status == status)
        if campaign_id:
            query = query.where(Email.campaign_id == campaign_id)
        
        # Get total count
        count_result = await self.db.execute(
            select(func.count()).select_from(query.subquery())
        )
        total = count_result.scalar()
        
        # Get paginated results
        query = query.order_by(Email.created_at.desc())
        query = query.offset((page - 1) * per_page).limit(per_page)
        
        result = await self.db.execute(query)
        emails = result.scalars().all()
        
        return {
            "items": emails,
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page
        }
    
    async def get_email_stats(self, user_id: str) -> Dict[str, Any]:
        """Get email statistics for user"""
        
        # Total counts by status
        result = await self.db.execute(
            select(Email.status, func.count())
            .where(Email.user_id == user_id)
            .group_by(Email.status)
        )
        status_counts = {status: count for status, count in result.all()}
        
        total = sum(status_counts.values())
        sent = status_counts.get(EmailStatus.SENT, 0) + status_counts.get(EmailStatus.DELIVERED, 0)
        delivered = status_counts.get(EmailStatus.DELIVERED, 0)
        opened = status_counts.get(EmailStatus.OPENED, 0)
        clicked = status_counts.get(EmailStatus.CLICKED, 0)
        bounced = status_counts.get(EmailStatus.BOUNCED, 0)
        failed = status_counts.get(EmailStatus.FAILED, 0)
        
        return {
            "total_emails": total,
            "queued": status_counts.get(EmailStatus.QUEUED, 0),
            "sending": status_counts.get(EmailStatus.SENDING, 0),
            "sent": sent,
            "delivered": delivered,
            "opened": opened,
            "clicked": clicked,
            "bounced": bounced,
            "failed": failed,
            "retrying": status_counts.get(EmailStatus.RETRYING, 0),
            "delivery_rate": (delivered / sent * 100) if sent > 0 else 0,
            "open_rate": (opened / delivered * 100) if delivered > 0 else 0,
            "click_rate": (clicked / delivered * 100) if delivered > 0 else 0,
            "bounce_rate": (bounced / sent * 100) if sent > 0 else 0,
        }
    
    async def send_bulk_emails(self, user_id: str, emails_data: List[Dict[str, Any]],
                               batch_size: int = 100) -> Dict[str, Any]:
        """Send bulk emails"""
        
        created_emails = []
        errors = []
        
        for idx, data in enumerate(emails_data):
            try:
                email = await self.create_email(
                    user_id=user_id,
                    to_email=data['to'],
                    to_name=data.get('to_name'),
                    from_email=data.get('from_email', settings.SMTP_USERNAME),
                    from_name=data.get('from_name'),
                    subject=data['subject'],
                    html_content=data.get('html'),
                    text_content=data.get('text'),
                    reply_to=data.get('reply_to'),
                    track_opens=data.get('track_opens', True),
                    track_clicks=data.get('track_clicks', True),
                    tags=data.get('tags'),
                    headers=data.get('headers'),
                )
                created_emails.append(email)
                
                # Queue for sending
                await self.queue_email(email.id)
                
            except Exception as e:
                errors.append({"index": idx, "error": str(e)})
        
        return {
            "batch_id": str(uuid.uuid4()),
            "total": len(emails_data),
            "queued": len(created_emails),
            "failed": len(errors),
            "errors": errors
        }
