"""
Campaign Service - Email campaign management
"""
from datetime import datetime
from typing import Optional, List, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, func
from sqlalchemy.orm import selectinload
import uuid
import logging

from app.models.campaign import Campaign, CampaignRecipient, CampaignStatus
from app.models.email_list import Contact
from app.models.email import Email
from app.schemas.campaign import CampaignCreate, CampaignUpdate
from app.services.email_service import EmailService
from app.services.queue_service import QueueService

logger = logging.getLogger(__name__)


class CampaignService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.email_service = EmailService(db)
        self.queue_service = QueueService()
    
    async def create_campaign(self, user_id: str, data: CampaignCreate) -> Campaign:
        """Create a new email campaign"""
        campaign = Campaign(
            user_id=user_id,
            name=data.name,
            subject=data.subject,
            from_name=data.from_name,
            from_email=data.from_email,
            reply_to=data.reply_to,
            html_content=data.html_content,
            text_content=data.text_content,
            email_list_id=data.email_list_id,
            segment_conditions=data.segment_conditions,
            track_opens=data.track_opens,
            track_clicks=data.track_clicks,
            scheduled_at=data.scheduled_at,
            status=CampaignStatus.SCHEDULED if data.scheduled_at else CampaignStatus.DRAFT,
        )
        
        self.db.add(campaign)
        await self.db.commit()
        await self.db.refresh(campaign)
        
        logger.info(f"Created campaign {campaign.id} for user {user_id}")
        return campaign
    
    async def get_campaign(self, campaign_id: str,
                          user_id: Optional[str] = None) -> Optional[Campaign]:
        """Get campaign by ID"""
        query = select(Campaign).where(Campaign.id == campaign_id)
        if user_id:
            query = query.where(Campaign.user_id == user_id)
        
        result = await self.db.execute(query)
        return result.scalar_one_or_none()
    
    async def get_campaigns(self, user_id: str, status: Optional[str] = None,
                           page: int = 1, per_page: int = 50) -> Dict[str, Any]:
        """Get campaigns with filtering"""
        query = select(Campaign).where(Campaign.user_id == user_id)
        
        if status:
            query = query.where(Campaign.status == status)
        
        # Get total count
        count_result = await self.db.execute(
            select(func.count()).select_from(query.subquery())
        )
        total = count_result.scalar()
        
        # Get paginated results
        query = query.order_by(Campaign.created_at.desc())
        query = query.offset((page - 1) * per_page).limit(per_page)
        
        result = await self.db.execute(query)
        campaigns = result.scalars().all()
        
        return {
            "items": campaigns,
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page
        }
    
    async def update_campaign(self, campaign_id: str, user_id: str,
                             data: CampaignUpdate) -> Optional[Campaign]:
        """Update campaign"""
        campaign = await self.get_campaign(campaign_id, user_id)
        if not campaign:
            return None
        
        # Only allow updates for draft or scheduled campaigns
        if campaign.status not in [CampaignStatus.DRAFT, CampaignStatus.SCHEDULED]:
            raise ValueError("Cannot update campaign that is already sending or sent")
        
        update_data = data.dict(exclude_unset=True)
        for key, value in update_data.items():
            if hasattr(campaign, key) and key != 'id':
                setattr(campaign, key, value)
        
        # Update status if scheduled
        if data.scheduled_at and campaign.status == CampaignStatus.DRAFT:
            campaign.status = CampaignStatus.SCHEDULED
        
        campaign.updated_at = datetime.utcnow()
        await self.db.commit()
        await self.db.refresh(campaign)
        
        return campaign
    
    async def delete_campaign(self, campaign_id: str, user_id: str) -> bool:
        """Delete campaign"""
        campaign = await self.get_campaign(campaign_id, user_id)
        if not campaign:
            return False
        
        # Only allow deletion for draft campaigns
        if campaign.status != CampaignStatus.DRAFT:
            raise ValueError("Can only delete draft campaigns")
        
        await self.db.delete(campaign)
        await self.db.commit()
        
        logger.info(f"Deleted campaign {campaign_id}")
        return True
    
    async def prepare_recipients(self, campaign_id: str) -> int:
        """Prepare recipients for a campaign"""
        campaign = await self.get_campaign(campaign_id)
        if not campaign:
            raise ValueError("Campaign not found")
        
        if not campaign.email_list_id:
            raise ValueError("Campaign has no email list")
        
        # Get active contacts from the list
        query = select(Contact).where(
            Contact.email_list_id == campaign.email_list_id,
            Contact.status == "active",
            Contact.is_valid == True
        )
        
        result = await self.db.execute(query)
        contacts = result.scalars().all()
        
        # Create campaign recipients
        recipient_count = 0
        for contact in contacts:
            recipient = CampaignRecipient(
                campaign_id=campaign_id,
                contact_id=contact.id,
                status="pending"
            )
            self.db.add(recipient)
            recipient_count += 1
        
        campaign.total_recipients = recipient_count
        await self.db.commit()
        
        logger.info(f"Prepared {recipient_count} recipients for campaign {campaign_id}")
        return recipient_count
    
    async def send_campaign(self, campaign_id: str, user_id: str,
                           test_mode: bool = False,
                           test_emails: Optional[List[str]] = None) -> Dict[str, Any]:
        """Start sending a campaign"""
        campaign = await self.get_campaign(campaign_id, user_id)
        if not campaign:
            raise ValueError("Campaign not found")
        
        if campaign.status not in [CampaignStatus.DRAFT, CampaignStatus.SCHEDULED]:
            raise ValueError("Campaign is already being sent or has been sent")
        
        if test_mode:
            # Send test emails
            if not test_emails:
                raise ValueError("Test emails required for test mode")
            
            for test_email in test_emails:
                await self.email_service.create_email(
                    user_id=user_id,
                    to_email=test_email,
                    to_name=None,
                    from_email=campaign.from_email,
                    from_name=campaign.from_name,
                    subject=f"[TEST] {campaign.subject}",
                    html_content=campaign.html_content,
                    text_content=campaign.text_content,
                    reply_to=campaign.reply_to,
                    track_opens=campaign.track_opens,
                    track_clicks=campaign.track_clicks,
                    campaign_id=campaign_id,
                )
            
            return {
                "campaign_id": campaign_id,
                "status": "test_sent",
                "test_emails_sent": len(test_emails)
            }
        
        # Prepare recipients
        recipient_count = await self.prepare_recipients(campaign_id)
        
        if recipient_count == 0:
            raise ValueError("No valid recipients found for this campaign")
        
        # Update campaign status
        campaign.status = CampaignStatus.SENDING
        campaign.started_at = datetime.utcnow()
        await self.db.commit()
        
        # Queue campaign for sending
        await self.queue_service.enqueue('send_campaign', {
            'campaign_id': campaign_id,
            'user_id': user_id
        })
        
        logger.info(f"Started sending campaign {campaign_id}")
        
        return {
            "campaign_id": campaign_id,
            "status": "sending",
            "total_recipients": recipient_count
        }
    
    async def process_campaign_batch(self, campaign_id: str, batch_size: int = 100) -> Dict[str, Any]:
        """Process a batch of campaign recipients"""
        campaign = await self.get_campaign(campaign_id)
        if not campaign:
            raise ValueError("Campaign not found")
        
        # Get pending recipients
        result = await self.db.execute(
            select(CampaignRecipient)
            .where(
                CampaignRecipient.campaign_id == campaign_id,
                CampaignRecipient.status == "pending"
            )
            .limit(batch_size)
        )
        recipients = result.scalars().all()
        
        if not recipients:
            # No more pending recipients, mark campaign as sent
            campaign.status = CampaignStatus.SENT
            campaign.completed_at = datetime.utcnow()
            await self.db.commit()
            
            return {
                "campaign_id": campaign_id,
                "status": "completed",
                "processed": 0
            }
        
        sent_count = 0
        failed_count = 0
        
        for recipient in recipients:
            try:
                # Get contact details
                contact_result = await self.db.execute(
                    select(Contact).where(Contact.id == recipient.contact_id)
                )
                contact = contact_result.scalar_one_or_none()
                
                if not contact:
                    recipient.status = "failed"
                    recipient.error_message = "Contact not found"
                    failed_count += 1
                    continue
                
                # Create and send email
                email = await self.email_service.create_email(
                    user_id=campaign.user_id,
                    to_email=contact.email,
                    to_name=contact.name,
                    from_email=campaign.from_email,
                    from_name=campaign.from_name,
                    subject=campaign.subject,
                    html_content=campaign.html_content,
                    text_content=campaign.text_content,
                    reply_to=campaign.reply_to,
                    track_opens=campaign.track_opens,
                    track_clicks=campaign.track_clicks,
                    campaign_id=campaign_id,
                )
                
                # Queue for sending
                await self.email_service.queue_email(email.id)
                
                # Update recipient
                recipient.status = "sent"
                recipient.sent_at = datetime.utcnow()
                recipient.tracking_pixel_id = email.id
                sent_count += 1
                
                # Update campaign stats
                campaign.sent_count += 1
                
            except Exception as e:
                recipient.status = "failed"
                recipient.error_message = str(e)
                failed_count += 1
                logger.error(f"Failed to send to recipient {recipient.id}: {str(e)}")
        
        await self.db.commit()
        
        return {
            "campaign_id": campaign_id,
            "status": "processing",
            "sent": sent_count,
            "failed": failed_count,
            "remaining": campaign.total_recipients - campaign.sent_count
        }
    
    async def get_campaign_stats(self, campaign_id: str, user_id: str) -> Dict[str, Any]:
        """Get detailed campaign statistics"""
        campaign = await self.get_campaign(campaign_id, user_id)
        if not campaign:
            raise ValueError("Campaign not found")
        
        # Calculate rates
        sent = campaign.sent_count
        delivered = campaign.delivered_count
        opened = campaign.opened_count
        clicked = campaign.clicked_count
        bounced = campaign.bounced_count
        
        return {
            "campaign_id": campaign_id,
            "name": campaign.name,
            "status": campaign.status,
            "total_recipients": campaign.total_recipients,
            "sent": sent,
            "delivered": delivered,
            "opened": opened,
            "clicked": clicked,
            "bounced": bounced,
            "complained": campaign.complained_count,
            "unsubscribed": campaign.unsubscribed_count,
            "unique_opens": campaign.unique_opens,
            "unique_clicks": campaign.unique_clicks,
            "delivery_rate": (delivered / sent * 100) if sent > 0 else 0,
            "open_rate": (opened / delivered * 100) if delivered > 0 else 0,
            "click_rate": (clicked / delivered * 100) if delivered > 0 else 0,
            "bounce_rate": (bounced / sent * 100) if sent > 0 else 0,
            "click_to_open_rate": (clicked / opened * 100) if opened > 0 else 0,
            "started_at": campaign.started_at,
            "completed_at": campaign.completed_at,
        }
    
    async def pause_campaign(self, campaign_id: str, user_id: str) -> Campaign:
        """Pause a sending campaign"""
        campaign = await self.get_campaign(campaign_id, user_id)
        if not campaign:
            raise ValueError("Campaign not found")
        
        if campaign.status != CampaignStatus.SENDING:
            raise ValueError("Can only pause campaigns that are currently sending")
        
        campaign.status = CampaignStatus.PAUSED
        await self.db.commit()
        await self.db.refresh(campaign)
        
        logger.info(f"Paused campaign {campaign_id}")
        return campaign
    
    async def resume_campaign(self, campaign_id: str, user_id: str) -> Campaign:
        """Resume a paused campaign"""
        campaign = await self.get_campaign(campaign_id, user_id)
        if not campaign:
            raise ValueError("Campaign not found")
        
        if campaign.status != CampaignStatus.PAUSED:
            raise ValueError("Can only resume paused campaigns")
        
        campaign.status = CampaignStatus.SENDING
        await self.db.commit()
        await self.db.refresh(campaign)
        
        # Re-queue campaign
        await self.queue_service.enqueue('send_campaign', {
            'campaign_id': campaign_id,
            'user_id': user_id
        })
        
        logger.info(f"Resumed campaign {campaign_id}")
        return campaign
    
    async def cancel_campaign(self, campaign_id: str, user_id: str) -> Campaign:
        """Cancel a campaign"""
        campaign = await self.get_campaign(campaign_id, user_id)
        if not campaign:
            raise ValueError("Campaign not found")
        
        if campaign.status not in [CampaignStatus.DRAFT, CampaignStatus.SCHEDULED, CampaignStatus.PAUSED]:
            raise ValueError("Cannot cancel campaign that is already sending or sent")
        
        campaign.status = CampaignStatus.CANCELLED
        await self.db.commit()
        await self.db.refresh(campaign)
        
        logger.info(f"Cancelled campaign {campaign_id}")
        return campaign
