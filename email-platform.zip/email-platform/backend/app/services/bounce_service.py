"""
Bounce Service - Bounce processing and management
"""
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, func
import re
import logging

from app.models.bounce import Bounce, BounceLog, SuppressedEmail
from app.models.contact import Contact
from app.models.email import Email, EmailStatus
from app.config import settings

logger = logging.getLogger(__name__)


class BounceService:
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create_bounce(self, email_address: str, bounce_type: str,
                           user_id: str, **kwargs) -> Bounce:
        """Create a new bounce record"""
        bounce = Bounce(
            email_address=email_address,
            bounce_type=bounce_type,
            user_id=user_id,
            **kwargs
        )
        
        self.db.add(bounce)
        await self.db.commit()
        await self.db.refresh(bounce)
        
        logger.info(f"Created bounce record for {email_address} ({bounce_type})")
        return bounce
    
    async def get_bounce(self, bounce_id: str) -> Optional[Bounce]:
        """Get bounce by ID"""
        result = await self.db.execute(
            select(Bounce).where(Bounce.id == bounce_id)
        )
        return result.scalar_one_or_none()
    
    async def get_bounces(self, user_id: str, bounce_type: Optional[str] = None,
                         is_processed: Optional[bool] = None,
                         page: int = 1, per_page: int = 50) -> Dict[str, Any]:
        """Get bounces with filtering"""
        query = select(Bounce).where(Bounce.user_id == user_id)
        
        if bounce_type:
            query = query.where(Bounce.bounce_type == bounce_type)
        if is_processed is not None:
            query = query.where(Bounce.is_processed == is_processed)
        
        # Get total count
        count_result = await self.db.execute(
            select(func.count()).select_from(query.subquery())
        )
        total = count_result.scalar()
        
        # Get paginated results
        query = query.order_by(Bounce.created_at.desc())
        query = query.offset((page - 1) * per_page).limit(per_page)
        
        result = await self.db.execute(query)
        bounces = result.scalars().all()
        
        return {
            "items": bounces,
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page
        }
    
    async def process_bounce(self, bounce_id: str) -> Dict[str, Any]:
        """Process a bounce record"""
        bounce = await self.get_bounce(bounce_id)
        if not bounce:
            raise ValueError("Bounce not found")
        
        if bounce.is_processed:
            return {"processed": False, "message": "Bounce already processed"}
        
        actions_taken = []
        
        try:
            # Find associated contact
            contact_result = await self.db.execute(
                select(Contact).where(Contact.email == bounce.email_address)
            )
            contact = contact_result.scalar_one_or_none()
            
            if contact:
                # Update contact bounce info
                contact.bounce_count += 1
                contact.last_bounce_at = datetime.utcnow()
                contact.bounce_reason = bounce.bounce_reason
                contact.bounce_type = bounce.bounce_type
                
                # Handle hard bounce
                if bounce.bounce_type == "hard":
                    contact.status = "bounced"
                    contact.is_valid = False
                    actions_taken.append("contact_marked_bounced")
                    
                    # Add to suppression list
                    await self._add_to_suppression_list(
                        bounce.email_address,
                        "bounce",
                        bounce.bounce_reason,
                        bounce.id
                    )
                    actions_taken.append("added_to_suppression_list")
                
                # Handle soft bounce
                elif bounce.bounce_type == "soft":
                    # Only mark as bounced after multiple soft bounces
                    if contact.bounce_count >= 3:
                        contact.status = "bounced"
                        contact.is_valid = False
                        actions_taken.append("contact_marked_bounced_after_retries")
                
                await self.db.commit()
            
            # Update associated email
            if bounce.email_id:
                email_result = await self.db.execute(
                    select(Email).where(Email.id == bounce.email_id)
                )
                email = email_result.scalar_one_or_none()
                if email:
                    email.status = EmailStatus.BOUNCED
                    email.bounced_at = datetime.utcnow()
                    await self.db.commit()
                    actions_taken.append("email_marked_bounced")
            
            # Mark bounce as processed
            bounce.is_processed = True
            bounce.processed_at = datetime.utcnow()
            bounce.action_taken = ",".join(actions_taken)
            await self.db.commit()
            
            # Add log entry
            log = BounceLog(
                bounce_id=bounce.id,
                action="processed",
                details={"actions": actions_taken}
            )
            self.db.add(log)
            await self.db.commit()
            
            logger.info(f"Processed bounce {bounce_id}: {actions_taken}")
            
            return {
                "processed": True,
                "actions": actions_taken
            }
            
        except Exception as e:
            logger.error(f"Error processing bounce {bounce_id}: {str(e)}")
            
            # Add error log
            log = BounceLog(
                bounce_id=bounce.id,
                action="error",
                details={"error": str(e)}
            )
            self.db.add(log)
            await self.db.commit()
            
            raise
    
    async def process_pending_bounces(self, limit: int = 100) -> Dict[str, Any]:
        """Process all pending bounces"""
        result = await self.db.execute(
            select(Bounce)
            .where(Bounce.is_processed == False)
            .limit(limit)
        )
        bounces = result.scalars().all()
        
        processed = 0
        failed = 0
        
        for bounce in bounces:
            try:
                await self.process_bounce(bounce.id)
                processed += 1
            except Exception as e:
                logger.error(f"Failed to process bounce {bounce.id}: {str(e)}")
                failed += 1
        
        return {
            "processed": processed,
            "failed": failed,
            "total": len(bounces)
        }
    
    async def _add_to_suppression_list(self, email_address: str, reason: str,
                                      reason_details: Optional[str] = None,
                                      source_id: Optional[str] = None):
        """Add email to suppression list"""
        # Check if already suppressed
        result = await self.db.execute(
            select(SuppressedEmail).where(SuppressedEmail.email_address == email_address)
        )
        if result.scalar_one_or_none():
            return
        
        suppressed = SuppressedEmail(
            email_address=email_address,
            reason=reason,
            reason_details=reason_details,
            source_type="bounce",
            source_id=source_id
        )
        
        self.db.add(suppressed)
        await self.db.commit()
        
        logger.info(f"Added {email_address} to suppression list")
    
    async def parse_bounce_message(self, raw_message: str) -> Dict[str, Any]:
        """Parse a bounce message and extract relevant information"""
        bounce_data = {
            "email_address": None,
            "bounce_type": None,
            "bounce_code": None,
            "bounce_reason": None,
            "original_message_id": None,
        }
        
        # Extract email address
        email_match = re.search(r'[\w\.-]+@[\w\.-]+', raw_message)
        if email_match:
            bounce_data["email_address"] = email_match.group()
        
        # Determine bounce type
        if any(keyword in raw_message.lower() for keyword in [
            "user unknown", "unknown user", "recipient unknown", "no such user",
            "invalid address", "address rejected", "does not exist"
        ]):
            bounce_data["bounce_type"] = "hard"
            bounce_data["bounce_code"] = "5.1.1"
            bounce_data["bounce_reason"] = "User unknown"
        elif any(keyword in raw_message.lower() for keyword in [
            "mailbox full", "quota exceeded", "over quota", "insufficient space"
        ]):
            bounce_data["bounce_type"] = "soft"
            bounce_data["bounce_code"] = "4.2.2"
            bounce_data["bounce_reason"] = "Mailbox full"
        elif any(keyword in raw_message.lower() for keyword in [
            "domain not found", "bad destination", "no mx record"
        ]):
            bounce_data["bounce_type"] = "hard"
            bounce_data["bounce_code"] = "5.1.2"
            bounce_data["bounce_reason"] = "Domain not found"
        elif any(keyword in raw_message.lower() for keyword in [
            "temporary failure", "try again", "deferred"
        ]):
            bounce_data["bounce_type"] = "soft"
            bounce_data["bounce_code"] = "4.0.0"
            bounce_data["bounce_reason"] = "Temporary failure"
        
        # Extract original message ID
        message_id_match = re.search(r'Message-ID:\s*<([^>]+)>', raw_message)
        if message_id_match:
            bounce_data["original_message_id"] = message_id_match.group(1)
        
        return bounce_data
    
    async def get_bounce_stats(self, user_id: str) -> Dict[str, Any]:
        """Get bounce statistics"""
        # Total bounces
        result = await self.db.execute(
            select(func.count()).where(Bounce.user_id == user_id)
        )
        total = result.scalar()
        
        # Hard bounces
        result = await self.db.execute(
            select(func.count())
            .where(Bounce.user_id == user_id, Bounce.bounce_type == "hard")
        )
        hard = result.scalar()
        
        # Soft bounces
        result = await self.db.execute(
            select(func.count())
            .where(Bounce.user_id == user_id, Bounce.bounce_type == "soft")
        )
        soft = result.scalar()
        
        # Processed
        result = await self.db.execute(
            select(func.count())
            .where(Bounce.user_id == user_id, Bounce.is_processed == True)
        )
        processed = result.scalar()
        
        # By category
        result = await self.db.execute(
            select(Bounce.bounce_category, func.count())
            .where(Bounce.user_id == user_id)
            .group_by(Bounce.bounce_category)
        )
        by_category = {cat or "unknown": count for cat, count in result.all()}
        
        # By date (last 30 days)
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        result = await self.db.execute(
            select(
                func.date(Bounce.created_at),
                func.count()
            )
            .where(Bounce.user_id == user_id, Bounce.created_at >= thirty_days_ago)
            .group_by(func.date(Bounce.created_at))
        )
        by_date = {str(date): count for date, count in result.all()}
        
        return {
            "total_bounces": total,
            "hard_bounces": hard,
            "soft_bounces": soft,
            "processed": processed,
            "pending": total - processed,
            "by_category": by_category,
            "by_date": by_date,
            "bounce_rate": (total / (total + processed) * 100) if (total + processed) > 0 else 0
        }
    
    async def is_suppressed(self, email_address: str) -> bool:
        """Check if email is in suppression list"""
        result = await self.db.execute(
            select(SuppressedEmail).where(SuppressedEmail.email_address == email_address)
        )
        return result.scalar_one_or_none() is not None
    
    async def get_suppression_list(self, user_id: Optional[str] = None,
                                  page: int = 1, per_page: int = 50) -> Dict[str, Any]:
        """Get suppression list"""
        query = select(SuppressedEmail)
        
        # Get total count
        count_result = await self.db.execute(
            select(func.count()).select_from(query.subquery())
        )
        total = count_result.scalar()
        
        # Get paginated results
        query = query.order_by(SuppressedEmail.created_at.desc())
        query = query.offset((page - 1) * per_page).limit(per_page)
        
        result = await self.db.execute(query)
        suppressed = result.scalars().all()
        
        return {
            "items": suppressed,
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page
        }
    
    async def remove_from_suppression(self, email_address: str) -> bool:
        """Remove email from suppression list"""
        result = await self.db.execute(
            select(SuppressedEmail).where(SuppressedEmail.email_address == email_address)
        )
        suppressed = result.scalar_one_or_none()
        
        if not suppressed:
            return False
        
        await self.db.delete(suppressed)
        await self.db.commit()
        
        logger.info(f"Removed {email_address} from suppression list")
        return True
