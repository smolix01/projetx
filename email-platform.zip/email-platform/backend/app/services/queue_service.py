"""
Queue Service - Redis-based job queue
"""
import json
import redis
import logging
from typing import Optional, Dict, Any, List
from datetime import datetime
from app.config import settings

logger = logging.getLogger(__name__)


class QueueService:
    def __init__(self):
        self.redis_client = redis.from_url(
            settings.REDIS_URL,
            decode_responses=True,
            max_connections=settings.REDIS_POOL_SIZE
        )
    
    async def enqueue(self, queue_name: str, job_data: Dict[str, Any],
                     delay: Optional[int] = None) -> str:
        """Add a job to the queue"""
        job = {
            "id": f"{queue_name}_{datetime.utcnow().timestamp()}",
            "queue": queue_name,
            "data": job_data,
            "created_at": datetime.utcnow().isoformat(),
            "attempts": 0
        }
        
        job_json = json.dumps(job)
        
        if delay:
            # Schedule for later
            score = datetime.utcnow().timestamp() + delay
            self.redis_client.zadd(f"delayed:{queue_name}", {job_json: score})
        else:
            # Add to queue immediately
            self.redis_client.lpush(f"queue:{queue_name}", job_json)
        
        logger.info(f"Enqueued job {job['id']} to {queue_name}")
        return job["id"]
    
    async def dequeue(self, queue_name: str, timeout: int = 5) -> Optional[Dict[str, Any]]:
        """Get a job from the queue"""
        result = self.redis_client.brpop(f"queue:{queue_name}", timeout=timeout)
        
        if result:
            _, job_json = result
            job = json.loads(job_json)
            job["attempts"] += 1
            logger.info(f"Dequeued job {job['id']} from {queue_name}")
            return job
        
        return None
    
    async def dequeue_batch(self, queue_name: str, batch_size: int = 100) -> List[Dict[str, Any]]:
        """Get multiple jobs from the queue"""
        jobs = []
        
        for _ in range(batch_size):
            result = self.redis_client.rpop(f"queue:{queue_name}")
            if result:
                job = json.loads(result)
                job["attempts"] += 1
                jobs.append(job)
            else:
                break
        
        if jobs:
            logger.info(f"Dequeued batch of {len(jobs)} jobs from {queue_name}")
        
        return jobs
    
    async def ack(self, queue_name: str, job_id: str):
        """Acknowledge job completion"""
        logger.info(f"Acknowledged job {job_id} from {queue_name}")
    
    async def nack(self, queue_name: str, job: Dict[str, Any],
                   requeue: bool = True, delay: Optional[int] = None):
        """Negative acknowledge - requeue or discard"""
        if requeue and job["attempts"] < 3:
            job_json = json.dumps(job)
            
            if delay:
                score = datetime.utcnow().timestamp() + delay
                self.redis_client.zadd(f"delayed:{queue_name}", {job_json: score})
            else:
                self.redis_client.lpush(f"queue:{queue_name}", job_json)
            
            logger.warning(f"Requeued job {job['id']} to {queue_name} (attempt {job['attempts']})")
        else:
            # Move to dead letter queue
            job["failed_at"] = datetime.utcnow().isoformat()
            self.redis_client.lpush(f"dead_letter:{queue_name}", json.dumps(job))
            logger.error(f"Job {job['id']} moved to dead letter queue")
    
    async def schedule(self, queue_name: str, job_data: Dict[str, Any],
                      run_at: datetime) -> str:
        """Schedule a job for a specific time"""
        job = {
            "id": f"{queue_name}_{datetime.utcnow().timestamp()}",
            "queue": queue_name,
            "data": job_data,
            "created_at": datetime.utcnow().isoformat(),
            "attempts": 0
        }
        
        score = run_at.timestamp()
        self.redis_client.zadd(f"delayed:{queue_name}", {json.dumps(job): score})
        
        logger.info(f"Scheduled job {job['id']} for {run_at}")
        return job["id"]
    
    async def process_delayed(self, queue_name: str) -> int:
        """Move delayed jobs that are ready to the main queue"""
        now = datetime.utcnow().timestamp()
        
        # Get jobs that are ready
        jobs = self.redis_client.zrangebyscore(
            f"delayed:{queue_name}",
            0,
            now
        )
        
        moved = 0
        for job_json in jobs:
            # Remove from delayed queue
            self.redis_client.zrem(f"delayed:{queue_name}", job_json)
            # Add to main queue
            self.redis_client.lpush(f"queue:{queue_name}", job_json)
            moved += 1
        
        if moved > 0:
            logger.info(f"Moved {moved} delayed jobs to {queue_name}")
        
        return moved
    
    async def get_queue_length(self, queue_name: str) -> int:
        """Get the number of jobs in a queue"""
        return self.redis_client.llen(f"queue:{queue_name}")
    
    async def get_delayed_count(self, queue_name: str) -> int:
        """Get the number of delayed jobs"""
        return self.redis_client.zcard(f"delayed:{queue_name}")
    
    async def get_stats(self) -> Dict[str, Any]:
        """Get queue statistics"""
        queues = [
            "send_email",
            "send_campaign",
            "process_bounce",
            "process_tracking"
        ]
        
        stats = {}
        for queue in queues:
            stats[queue] = {
                "pending": await self.get_queue_length(queue),
                "delayed": await self.get_delayed_count(queue)
            }
        
        return stats
    
    async def purge_queue(self, queue_name: str) -> int:
        """Remove all jobs from a queue"""
        count = await self.get_queue_length(queue_name)
        self.redis_client.delete(f"queue:{queue_name}")
        logger.info(f"Purged {count} jobs from {queue_name}")
        return count
    
    async def requeue_failed(self, queue_name: str) -> int:
        """Requeue jobs from dead letter queue"""
        count = 0
        
        while True:
            job_json = self.redis_client.rpop(f"dead_letter:{queue_name}")
            if not job_json:
                break
            
            job = json.loads(job_json)
            job["attempts"] = 0
            job["requeued_at"] = datetime.utcnow().isoformat()
            
            self.redis_client.lpush(f"queue:{queue_name}", json.dumps(job))
            count += 1
        
        if count > 0:
            logger.info(f"Requeued {count} failed jobs to {queue_name}")
        
        return count
    
    def close(self):
        """Close Redis connection"""
        self.redis_client.close()
