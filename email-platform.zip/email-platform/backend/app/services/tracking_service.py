"""
Tracking Service - Email open and click tracking
"""
from datetime import datetime
from typing import Optional, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, func
from urllib.parse import urlparse
import uuid
import re
import logging

from app.models.tracking import TrackingPixel, TrackingLink, TrackingEvent
from app.models.email import Email, EmailStatus
from app.models.campaign import Campaign
from app.config import settings

logger = logging.getLogger(__name__)


class TrackingService:
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create_tracking_pixel(self, email_id: str, user_id: str,
                                    campaign_id: Optional[str] = None,
                                    contact_id: Optional[str] = None) -> TrackingPixel:
        """Create a tracking pixel for email open tracking"""
        pixel = TrackingPixel(
            pixel_id=str(uuid.uuid4()),
            email_id=email_id,
            campaign_id=campaign_id,
            contact_id=contact_id,
            user_id=user_id,
        )
        
        self.db.add(pixel)
        await self.db.commit()
        await self.db.refresh(pixel)
        
        return pixel
    
    async def track_open(self, pixel_id: str, ip_address: Optional[str] = None,
                        user_agent: Optional[str] = None) -> bool:
        """Record an email open"""
        result = await self.db.execute(
            select(TrackingPixel).where(TrackingPixel.pixel_id == pixel_id)
        )
        pixel = result.scalar_one_or_none()
        
        if not pixel:
            logger.warning(f"Tracking pixel not found: {pixel_id}")
            return False
        
        now = datetime.utcnow()
        
        # Update pixel
        if not pixel.is_opened:
            pixel.is_opened = True
            pixel.first_opened_at = now
        
        pixel.open_count += 1
        pixel.last_opened_at = now
        
        # Create tracking event
        event = TrackingEvent(
            event_type="open",
            email_id=pixel.email_id,
            campaign_id=pixel.campaign_id,
            contact_id=pixel.contact_id,
            user_id=pixel.user_id,
            ip_address=ip_address,
            user_agent=user_agent,
        )
        self.db.add(event)
        
        # Update email status
        email_result = await self.db.execute(
            select(Email).where(Email.id == pixel.email_id)
        )
        email = email_result.scalar_one_or_none()
        if email:
            email.status = EmailStatus.OPENED
            email.opened_at = now
        
        # Update campaign stats
        if pixel.campaign_id:
            campaign_result = await self.db.execute(
                select(Campaign).where(Campaign.id == pixel.campaign_id)
            )
            campaign = campaign_result.scalar_one_or_none()
            if campaign:
                campaign.opened_count += 1
                if not pixel.is_opened:
                    campaign.unique_opens += 1
        
        await self.db.commit()
        logger.info(f"Tracked open for pixel {pixel_id}")
        return True
    
    async def create_tracking_link(self, email_id: str, original_url: str,
                                   user_id: str, campaign_id: Optional[str] = None,
                                   contact_id: Optional[str] = None) -> TrackingLink:
        """Create a tracking link for click tracking"""
        link = TrackingLink(
            link_id=str(uuid.uuid4()),
            email_id=email_id,
            campaign_id=campaign_id,
            contact_id=contact_id,
            user_id=user_id,
            original_url=original_url,
        )
        
        self.db.add(link)
        await self.db.commit()
        await self.db.refresh(link)
        
        return link
    
    async def track_click(self, link_id: str, ip_address: Optional[str] = None,
                         user_agent: Optional[str] = None) -> Optional[str]:
        """Record a link click and return the original URL"""
        result = await self.db.execute(
            select(TrackingLink).where(TrackingLink.link_id == link_id)
        )
        link = result.scalar_one_or_none()
        
        if not link:
            logger.warning(f"Tracking link not found: {link_id}")
            return None
        
        now = datetime.utcnow()
        
        # Update link
        link.click_count += 1
        
        # Create tracking event
        event = TrackingEvent(
            event_type="click",
            email_id=link.email_id,
            campaign_id=link.campaign_id,
            contact_id=link.contact_id,
            user_id=link.user_id,
            link_id=link.id,
            ip_address=ip_address,
            user_agent=user_agent,
            clicked_url=link.original_url,
        )
        self.db.add(event)
        
        # Update email status
        email_result = await self.db.execute(
            select(Email).where(Email.id == link.email_id)
        )
        email = email_result.scalar_one_or_none()
        if email:
            email.status = EmailStatus.CLICKED
            email.clicked_at = now
        
        # Update campaign stats
        if link.campaign_id:
            campaign_result = await self.db.execute(
                select(Campaign).where(Campaign.id == link.campaign_id)
            )
            campaign = campaign_result.scalar_one_or_none()
            if campaign:
                campaign.clicked_count += 1
        
        await self.db.commit()
        logger.info(f"Tracked click for link {link_id}")
        return link.original_url
    
    async def replace_links(self, html_content: str, email_id: str,
                           user_id: str, campaign_id: Optional[str] = None,
                           contact_id: Optional[str] = None) -> str:
        """Replace all links in HTML with tracking links"""
        # Find all links in HTML
        link_pattern = r'href=["\'](https?://[^"\']+)["\']'
        links = re.findall(link_pattern, html_content)
        
        for original_url in links:
            # Skip unsubscribe links and mailto links
            if 'unsubscribe' in original_url.lower() or original_url.startswith('mailto:'):
                continue
            
            # Create tracking link
            tracking_link = await self.create_tracking_link(
                email_id=email_id,
                original_url=original_url,
                user_id=user_id,
                campaign_id=campaign_id,
                contact_id=contact_id
            )
            
            # Generate tracking URL
            tracking_url = f"https://{settings.TRACKING_DOMAIN}/track/click/{tracking_link.link_id}"
            
            # Replace in HTML
            html_content = html_content.replace(
                f'href="{original_url}"',
                f'href="{tracking_url}"'
            )
            html_content = html_content.replace(
                f"href='{original_url}'",
                f'href="{tracking_url}"'
            )
        
        return html_content
    
    async def get_tracking_stats(self, user_id: str,
                                 campaign_id: Optional[str] = None,
                                 email_id: Optional[str] = None) -> Dict[str, Any]:
        """Get tracking statistics"""
        # Base query
        query = select(TrackingEvent).where(TrackingEvent.user_id == user_id)
        
        if campaign_id:
            query = query.where(TrackingEvent.campaign_id == campaign_id)
        if email_id:
            query = query.where(TrackingEvent.email_id == email_id)
        
        # Open stats
        open_query = query.where(TrackingEvent.event_type == "open")
        result = await self.db.execute(
            select(func.count()).select_from(open_query.subquery())
        )
        total_opens = result.scalar()
        
        # Click stats
        click_query = query.where(TrackingEvent.event_type == "click")
        result = await self.db.execute(
            select(func.count()).select_from(click_query.subquery())
        )
        total_clicks = result.scalar()
        
        # Unique opens
        result = await self.db.execute(
            select(func.count(func.distinct(TrackingEvent.email_id)))
            .where(TrackingEvent.user_id == user_id)
            .where(TrackingEvent.event_type == "open")
        )
        unique_opens = result.scalar()
        
        # Unique clicks
        result = await self.db.execute(
            select(func.count(func.distinct(TrackingEvent.email_id)))
            .where(TrackingEvent.user_id == user_id)
            .where(TrackingEvent.event_type == "click")
        )
        unique_clicks = result.scalar()
        
        # By device
        result = await self.db.execute(
            select(TrackingEvent.device_type, func.count())
            .where(TrackingEvent.user_id == user_id)
            .group_by(TrackingEvent.device_type)
        )
        by_device = {device or "unknown": count for device, count in result.all()}
        
        # By browser
        result = await self.db.execute(
            select(TrackingEvent.browser, func.count())
            .where(TrackingEvent.user_id == user_id)
            .group_by(TrackingEvent.browser)
        )
        by_browser = {browser or "unknown": count for browser, count in result.all()}
        
        # By OS
        result = await self.db.execute(
            select(TrackingEvent.operating_system, func.count())
            .where(TrackingEvent.user_id == user_id)
            .group_by(TrackingEvent.operating_system)
        )
        by_os = {os or "unknown": count for os, count in result.all()}
        
        # By country
        result = await self.db.execute(
            select(TrackingEvent.country, func.count())
            .where(TrackingEvent.user_id == user_id)
            .group_by(TrackingEvent.country)
        )
        by_country = {country or "unknown": count for country, count in result.all()}
        
        return {
            "total_opens": total_opens,
            "unique_opens": unique_opens,
            "total_clicks": total_clicks,
            "unique_clicks": unique_clicks,
            "open_rate": (unique_opens / (unique_opens + unique_clicks) * 100) if (unique_opens + unique_clicks) > 0 else 0,
            "click_rate": (unique_clicks / (unique_opens + unique_clicks) * 100) if (unique_opens + unique_clicks) > 0 else 0,
            "click_to_open_rate": (unique_clicks / unique_opens * 100) if unique_opens > 0 else 0,
            "by_device": by_device,
            "by_browser": by_browser,
            "by_os": by_os,
            "by_country": by_country,
        }
    
    async def get_link_stats(self, link_id: str) -> Dict[str, Any]:
        """Get statistics for a specific tracking link"""
        result = await self.db.execute(
            select(TrackingLink).where(TrackingLink.link_id == link_id)
        )
        link = result.scalar_one_or_none()
        
        if not link:
            raise ValueError("Link not found")
        
        # Get click events
        result = await self.db.execute(
            select(TrackingEvent)
            .where(TrackingEvent.link_id == link.id)
            .order_by(TrackingEvent.created_at.desc())
        )
        events = result.scalars().all()
        
        return {
            "link_id": link_id,
            "original_url": link.original_url,
            "total_clicks": link.click_count,
            "unique_clicks": len(set(e.contact_id for e in events if e.contact_id)),
            "clicks": [
                {
                    "ip_address": e.ip_address,
                    "user_agent": e.user_agent,
                    "country": e.country,
                    "created_at": e.created_at
                }
                for e in events
            ]
        }
    
    async def get_pixel_image(self) -> bytes:
        """Get the 1x1 transparent tracking pixel image"""
        # 1x1 transparent GIF
        return bytes([
            0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x01, 0x00,
            0x01, 0x00, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00,
            0xff, 0xff, 0xff, 0x21, 0xf9, 0x04, 0x01, 0x00,
            0x00, 0x00, 0x00, 0x2c, 0x00, 0x00, 0x00, 0x00,
            0x01, 0x00, 0x01, 0x00, 0x00, 0x02, 0x02, 0x44,
            0x01, 0x00, 0x3b
        ])
