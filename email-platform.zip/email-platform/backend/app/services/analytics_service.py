"""
Analytics Service - Dashboard and reporting analytics
"""
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_
from sqlalchemy.orm import selectinload

from app.models.email import Email, EmailStatus
from app.models.campaign import Campaign, CampaignStatus
from app.models.contact import Contact
from app.models.tracking import TrackingEvent
from app.models.bounce import Bounce


class AnalyticsService:
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def get_dashboard_stats(self, user_id: str) -> Dict[str, Any]:
        """Get main dashboard statistics"""
        now = datetime.utcnow()
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        week_start = today_start - timedelta(days=7)
        month_start = today_start - timedelta(days=30)
        
        # Today's stats
        today_sent = await self._count_emails(user_id, today_start, now)
        today_opens = await self._count_events(user_id, "open", today_start, now)
        today_clicks = await self._count_events(user_id, "click", today_start, now)
        
        # Week stats
        week_sent = await self._count_emails(user_id, week_start, now)
        week_opens = await self._count_events(user_id, "open", week_start, now)
        week_clicks = await self._count_events(user_id, "click", week_start, now)
        
        # Month stats
        month_sent = await self._count_emails(user_id, month_start, now)
        month_opens = await self._count_events(user_id, "open", month_start, now)
        month_clicks = await self._count_events(user_id, "click", month_start, now)
        
        # Total contacts
        result = await self.db.execute(
            select(func.count()).where(Contact.user_id == user_id)
        )
        total_contacts = result.scalar()
        
        # Active campaigns
        result = await self.db.execute(
            select(func.count())
            .where(Campaign.user_id == user_id)
            .where(Campaign.status.in_([CampaignStatus.SENDING, CampaignStatus.SCHEDULED]))
        )
        active_campaigns = result.scalar()
        
        # Recent bounces
        result = await self.db.execute(
            select(func.count())
            .where(Bounce.user_id == user_id)
            .where(Bounce.created_at >= today_start)
        )
        today_bounces = result.scalar()
        
        return {
            "today": {
                "sent": today_sent,
                "opens": today_opens,
                "clicks": today_clicks,
                "bounces": today_bounces
            },
            "week": {
                "sent": week_sent,
                "opens": week_opens,
                "clicks": week_clicks
            },
            "month": {
                "sent": month_sent,
                "opens": month_opens,
                "clicks": month_clicks
            },
            "totals": {
                "contacts": total_contacts,
                "active_campaigns": active_campaigns
            }
        }
    
    async def _count_emails(self, user_id: str,
                           start_date: datetime,
                           end_date: datetime) -> int:
        """Count emails sent in date range"""
        result = await self.db.execute(
            select(func.count())
            .where(Email.user_id == user_id)
            .where(Email.status.in_([EmailStatus.SENT, EmailStatus.DELIVERED, EmailStatus.OPENED, EmailStatus.CLICKED]))
            .where(Email.sent_at >= start_date)
            .where(Email.sent_at <= end_date)
        )
        return result.scalar()
    
    async def _count_events(self, user_id: str, event_type: str,
                           start_date: datetime,
                           end_date: datetime) -> int:
        """Count tracking events in date range"""
        result = await self.db.execute(
            select(func.count())
            .where(TrackingEvent.user_id == user_id)
            .where(TrackingEvent.event_type == event_type)
            .where(TrackingEvent.created_at >= start_date)
            .where(TrackingEvent.created_at <= end_date)
        )
        return result.scalar()
    
    async def get_email_volume_chart(self, user_id: str,
                                     days: int = 30) -> List[Dict[str, Any]]:
        """Get email volume chart data"""
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=days)
        
        result = await self.db.execute(
            select(
                func.date(Email.sent_at).label('date'),
                func.count().label('count')
            )
            .where(Email.user_id == user_id)
            .where(Email.sent_at >= start_date)
            .where(Email.sent_at <= end_date)
            .group_by(func.date(Email.sent_at))
            .order_by(func.date(Email.sent_at))
        )
        
        return [
            {"date": str(date), "count": count}
            for date, count in result.all()
        ]
    
    async def get_engagement_chart(self, user_id: str,
                                   days: int = 30) -> List[Dict[str, Any]]:
        """Get engagement chart data (opens and clicks)"""
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=days)
        
        # Opens by date
        opens_result = await self.db.execute(
            select(
                func.date(TrackingEvent.created_at).label('date'),
                func.count().label('count')
            )
            .where(TrackingEvent.user_id == user_id)
            .where(TrackingEvent.event_type == "open")
            .where(TrackingEvent.created_at >= start_date)
            .where(TrackingEvent.created_at <= end_date)
            .group_by(func.date(TrackingEvent.created_at))
        )
        opens_by_date = {str(date): count for date, count in opens_result.all()}
        
        # Clicks by date
        clicks_result = await self.db.execute(
            select(
                func.date(TrackingEvent.created_at).label('date'),
                func.count().label('count')
            )
            .where(TrackingEvent.user_id == user_id)
            .where(TrackingEvent.event_type == "click")
            .where(TrackingEvent.created_at >= start_date)
            .where(TrackingEvent.created_at <= end_date)
            .group_by(func.date(TrackingEvent.created_at))
        )
        clicks_by_date = {str(date): count for date, count in clicks_result.all()}
        
        # Combine
        all_dates = set(opens_by_date.keys()) | set(clicks_by_date.keys())
        
        return [
            {
                "date": date,
                "opens": opens_by_date.get(date, 0),
                "clicks": clicks_by_date.get(date, 0)
            }
            for date in sorted(all_dates)
        ]
    
    async def get_top_performing_campaigns(self, user_id: str,
                                          limit: int = 5) -> List[Dict[str, Any]]:
        """Get top performing campaigns"""
        result = await self.db.execute(
            select(Campaign)
            .where(Campaign.user_id == user_id)
            .where(Campaign.status == CampaignStatus.SENT)
            .order_by(Campaign.opened_count.desc())
            .limit(limit)
        )
        campaigns = result.scalars().all()
        
        return [
            {
                "id": c.id,
                "name": c.name,
                "subject": c.subject,
                "sent": c.sent_count,
                "opens": c.opened_count,
                "clicks": c.clicked_count,
                "open_rate": (c.opened_count / c.sent_count * 100) if c.sent_count > 0 else 0,
                "click_rate": (c.clicked_count / c.sent_count * 100) if c.sent_count > 0 else 0,
            }
            for c in campaigns
        ]
    
    async def get_geographic_stats(self, user_id: str) -> List[Dict[str, Any]]:
        """Get geographic distribution of opens/clicks"""
        result = await self.db.execute(
            select(
                TrackingEvent.country,
                func.count().label('count')
            )
            .where(TrackingEvent.user_id == user_id)
            .where(TrackingEvent.country.isnot(None))
            .group_by(TrackingEvent.country)
            .order_by(func.count().desc())
            .limit(10)
        )
        
        return [
            {"country": country or "Unknown", "count": count}
            for country, count in result.all()
        ]
    
    async def get_device_stats(self, user_id: str) -> Dict[str, Any]:
        """Get device and client statistics"""
        # Device types
        device_result = await self.db.execute(
            select(
                TrackingEvent.device_type,
                func.count().label('count')
            )
            .where(TrackingEvent.user_id == user_id)
            .group_by(TrackingEvent.device_type)
        )
        devices = {device or "Unknown": count for device, count in device_result.all()}
        
        # Browsers
        browser_result = await self.db.execute(
            select(
                TrackingEvent.browser,
                func.count().label('count')
            )
            .where(TrackingEvent.user_id == user_id)
            .group_by(TrackingEvent.browser)
            .order_by(func.count().desc())
            .limit(5)
        )
        browsers = {browser or "Unknown": count for browser, count in browser_result.all()}
        
        # Operating systems
        os_result = await self.db.execute(
            select(
                TrackingEvent.operating_system,
                func.count().label('count')
            )
            .where(TrackingEvent.user_id == user_id)
            .group_by(TrackingEvent.operating_system)
            .order_by(func.count().desc())
            .limit(5)
        )
        operating_systems = {os or "Unknown": count for os, count in os_result.all()}
        
        return {
            "devices": devices,
            "browsers": browsers,
            "operating_systems": operating_systems
        }
    
    async def get_hourly_activity(self, user_id: str) -> List[Dict[str, Any]]:
        """Get hourly activity pattern"""
        result = await self.db.execute(
            select(
                func.extract('hour', TrackingEvent.created_at).label('hour'),
                func.count().label('count')
            )
            .where(TrackingEvent.user_id == user_id)
            .group_by(func.extract('hour', TrackingEvent.created_at))
            .order_by(func.extract('hour', TrackingEvent.created_at))
        )
        
        return [
            {"hour": int(hour), "count": count}
            for hour, count in result.all()
        ]
    
    async def get_bounce_analytics(self, user_id: str) -> Dict[str, Any]:
        """Get bounce analytics"""
        # Bounce types
        type_result = await self.db.execute(
            select(
                Bounce.bounce_type,
                func.count().label('count')
            )
            .where(Bounce.user_id == user_id)
            .group_by(Bounce.bounce_type)
        )
        by_type = {bounce_type: count for bounce_type, count in type_result.all()}
        
        # Bounce categories
        category_result = await self.db.execute(
            select(
                Bounce.bounce_category,
                func.count().label('count')
            )
            .where(Bounce.user_id == user_id)
            .group_by(Bounce.bounce_category)
            .order_by(func.count().desc())
            .limit(5)
        )
        by_category = {cat or "Unknown": count for cat, count in category_result.all()}
        
        # Bounce trend (last 30 days)
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        trend_result = await self.db.execute(
            select(
                func.date(Bounce.created_at).label('date'),
                func.count().label('count')
            )
            .where(Bounce.user_id == user_id)
            .where(Bounce.created_at >= thirty_days_ago)
            .group_by(func.date(Bounce.created_at))
            .order_by(func.date(Bounce.created_at))
        )
        trend = [{"date": str(date), "count": count} for date, count in trend_result.all()]
        
        return {
            "by_type": by_type,
            "by_category": by_category,
            "trend": trend,
            "total": sum(by_type.values())
        }
    
    async def generate_report(self, user_id: str,
                             start_date: datetime,
                             end_date: datetime) -> Dict[str, Any]:
        """Generate a comprehensive report"""
        # Email stats
        emails_sent = await self._count_emails(user_id, start_date, end_date)
        opens = await self._count_events(user_id, "open", start_date, end_date)
        clicks = await self._count_events(user_id, "click", start_date, end_date)
        
        # Campaigns sent
        result = await self.db.execute(
            select(func.count())
            .where(Campaign.user_id == user_id)
            .where(Campaign.status == CampaignStatus.SENT)
            .where(Campaign.completed_at >= start_date)
            .where(Campaign.completed_at <= end_date)
        )
        campaigns_sent = result.scalar()
        
        # New contacts
        result = await self.db.execute(
            select(func.count())
            .where(Contact.user_id == user_id)
            .where(Contact.created_at >= start_date)
            .where(Contact.created_at <= end_date)
        )
        new_contacts = result.scalar()
        
        # Bounces
        result = await self.db.execute(
            select(func.count())
            .where(Bounce.user_id == user_id)
            .where(Bounce.created_at >= start_date)
            .where(Bounce.created_at <= end_date)
        )
        bounces = result.scalar()
        
        return {
            "period": {
                "start": start_date.isoformat(),
                "end": end_date.isoformat()
            },
            "summary": {
                "emails_sent": emails_sent,
                "opens": opens,
                "clicks": clicks,
                "campaigns_sent": campaigns_sent,
                "new_contacts": new_contacts,
                "bounces": bounces
            },
            "rates": {
                "open_rate": (opens / emails_sent * 100) if emails_sent > 0 else 0,
                "click_rate": (clicks / emails_sent * 100) if emails_sent > 0 else 0,
                "bounce_rate": (bounces / emails_sent * 100) if emails_sent > 0 else 0,
                "click_to_open_rate": (clicks / opens * 100) if opens > 0 else 0
            },
            "top_campaigns": await self.get_top_performing_campaigns(user_id),
            "geographic_stats": await self.get_geographic_stats(user_id),
            "device_stats": await self.get_device_stats(user_id)
        }
