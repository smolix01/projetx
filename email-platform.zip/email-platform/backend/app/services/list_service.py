"""
Email List Service - Contact and list management
"""
from datetime import datetime
from typing import Optional, List, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, func, or_, and_
from sqlalchemy.orm import selectinload
import csv
import io
import logging

from app.models.email_list import EmailList, Contact, ContactAttribute
from app.models.bounce import SuppressedEmail
from app.schemas.email_list import ContactCreate, EmailListCreate, EmailListUpdate

logger = logging.getLogger(__name__)


class ListService:
    def __init__(self, db: AsyncSession):
        self.db = db
    
    # Email List Methods
    async def create_list(self, user_id: str, data: EmailListCreate) -> EmailList:
        """Create a new email list"""
        email_list = EmailList(
            user_id=user_id,
            name=data.name,
            description=data.description,
            double_opt_in=data.double_opt_in,
            auto_clean_enabled=data.auto_clean_enabled,
            auto_clean_after_bounces=data.auto_clean_after_bounces,
        )
        
        self.db.add(email_list)
        await self.db.commit()
        await self.db.refresh(email_list)
        
        logger.info(f"Created email list {email_list.id} for user {user_id}")
        return email_list
    
    async def get_list(self, list_id: str, user_id: Optional[str] = None) -> Optional[EmailList]:
        """Get email list by ID"""
        query = select(EmailList).where(EmailList.id == list_id)
        if user_id:
            query = query.where(EmailList.user_id == user_id)
        
        result = await self.db.execute(query)
        return result.scalar_one_or_none()
    
    async def get_lists(self, user_id: str, page: int = 1, per_page: int = 50) -> Dict[str, Any]:
        """Get all email lists for user"""
        query = select(EmailList).where(EmailList.user_id == user_id)
        
        # Get total count
        count_result = await self.db.execute(
            select(func.count()).select_from(query.subquery())
        )
        total = count_result.scalar()
        
        # Get paginated results
        query = query.order_by(EmailList.created_at.desc())
        query = query.offset((page - 1) * per_page).limit(per_page)
        
        result = await self.db.execute(query)
        lists = result.scalars().all()
        
        return {
            "items": lists,
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page
        }
    
    async def update_list(self, list_id: str, user_id: str, data: EmailListUpdate) -> Optional[EmailList]:
        """Update email list"""
        email_list = await self.get_list(list_id, user_id)
        if not email_list:
            return None
        
        update_data = data.dict(exclude_unset=True)
        for key, value in update_data.items():
            setattr(email_list, key, value)
        
        email_list.updated_at = datetime.utcnow()
        await self.db.commit()
        await self.db.refresh(email_list)
        
        return email_list
    
    async def delete_list(self, list_id: str, user_id: str) -> bool:
        """Delete email list"""
        email_list = await self.get_list(list_id, user_id)
        if not email_list:
            return False
        
        await self.db.delete(email_list)
        await self.db.commit()
        
        logger.info(f"Deleted email list {list_id}")
        return True
    
    # Contact Methods
    async def add_contact(self, list_id: str, user_id: str, data: ContactCreate) -> Contact:
        """Add a contact to a list"""
        # Check if list exists
        email_list = await self.get_list(list_id, user_id)
        if not email_list:
            raise ValueError("Email list not found")
        
        # Check if email is suppressed
        suppressed = await self.db.execute(
            select(SuppressedEmail).where(SuppressedEmail.email_address == data.email)
        )
        if suppressed.scalar_one_or_none():
            raise ValueError("Email address is suppressed")
        
        # Check if contact already exists in this list
        result = await self.db.execute(
            select(Contact).where(
                Contact.email_list_id == list_id,
                Contact.email == data.email
            )
        )
        existing = result.scalar_one_or_none()
        
        if existing:
            # Update existing contact
            existing.name = data.name or existing.name
            existing.updated_at = datetime.utcnow()
            
            # Update attributes
            if data.attributes:
                for attr_data in data.attributes:
                    attr_result = await self.db.execute(
                        select(ContactAttribute).where(
                            ContactAttribute.contact_id == existing.id,
                            ContactAttribute.key == attr_data.key
                        )
                    )
                    attr = attr_result.scalar_one_or_none()
                    if attr:
                        attr.value = attr_data.value
                        attr.data_type = attr_data.data_type
                    else:
                        new_attr = ContactAttribute(
                            contact_id=existing.id,
                            key=attr_data.key,
                            value=attr_data.value,
                            data_type=attr_data.data_type
                        )
                        self.db.add(new_attr)
            
            await self.db.commit()
            await self.db.refresh(existing)
            
            # Update list stats
            await self._update_list_stats(list_id)
            
            return existing
        
        # Create new contact
        contact = Contact(
            email_list_id=list_id,
            user_id=user_id,
            email=data.email,
            name=data.name,
            status="active",
            is_valid=True,
        )
        
        self.db.add(contact)
        await self.db.flush()  # Flush to get contact ID
        
        # Add attributes
        if data.attributes:
            for attr_data in data.attributes:
                attr = ContactAttribute(
                    contact_id=contact.id,
                    key=attr_data.key,
                    value=attr_data.value,
                    data_type=attr_data.data_type
                )
                self.db.add(attr)
        
        await self.db.commit()
        await self.db.refresh(contact)
        
        # Update list stats
        await self._update_list_stats(list_id)
        
        logger.info(f"Added contact {contact.id} to list {list_id}")
        return contact
    
    async def get_contact(self, contact_id: str, user_id: Optional[str] = None) -> Optional[Contact]:
        """Get contact by ID"""
        query = select(Contact).where(Contact.id == contact_id)
        if user_id:
            query = query.where(Contact.user_id == user_id)
        
        result = await self.db.execute(query)
        return result.scalar_one_or_none()
    
    async def get_contacts(self, list_id: str, user_id: str,
                          status: Optional[str] = None,
                          page: int = 1, per_page: int = 50) -> Dict[str, Any]:
        """Get contacts in a list"""
        # Verify list ownership
        email_list = await self.get_list(list_id, user_id)
        if not email_list:
            raise ValueError("Email list not found")
        
        query = select(Contact).where(Contact.email_list_id == list_id)
        
        if status:
            query = query.where(Contact.status == status)
        
        # Get total count
        count_result = await self.db.execute(
            select(func.count()).select_from(query.subquery())
        )
        total = count_result.scalar()
        
        # Get paginated results with attributes
        query = query.options(selectinload(Contact.attributes))
        query = query.order_by(Contact.created_at.desc())
        query = query.offset((page - 1) * per_page).limit(per_page)
        
        result = await self.db.execute(query)
        contacts = result.scalars().all()
        
        return {
            "items": contacts,
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page
        }
    
    async def update_contact(self, contact_id: str, user_id: str,
                            data: Dict[str, Any]) -> Optional[Contact]:
        """Update contact"""
        contact = await self.get_contact(contact_id, user_id)
        if not contact:
            return None
        
        for key, value in data.items():
            if hasattr(contact, key) and key != 'id':
                setattr(contact, key, value)
        
        contact.updated_at = datetime.utcnow()
        await self.db.commit()
        await self.db.refresh(contact)
        
        return contact
    
    async def delete_contact(self, contact_id: str, user_id: str) -> bool:
        """Delete contact"""
        contact = await self.get_contact(contact_id, user_id)
        if not contact:
            return False
        
        list_id = contact.email_list_id
        await self.db.delete(contact)
        await self.db.commit()
        
        # Update list stats
        await self._update_list_stats(list_id)
        
        return True
    
    async def import_contacts_csv(self, list_id: str, user_id: str,
                                   csv_content: str,
                                   mapping: Dict[str, str]) -> Dict[str, Any]:
        """Import contacts from CSV"""
        # Verify list ownership
        email_list = await self.get_list(list_id, user_id)
        if not email_list:
            raise ValueError("Email list not found")
        
        results = {
            "total": 0,
            "imported": 0,
            "updated": 0,
            "failed": 0,
            "errors": []
        }
        
        try:
            csv_file = io.StringIO(csv_content)
            reader = csv.DictReader(csv_file)
            
            for row in reader:
                results["total"] += 1
                
                try:
                    # Map fields
                    email = row.get(mapping.get('email', 'email'))
                    if not email:
                        raise ValueError("Email is required")
                    
                    name = row.get(mapping.get('name', 'name'))
                    
                    # Build attributes
                    attributes = []
                    for csv_col, field in mapping.items():
                        if field not in ['email', 'name'] and csv_col in row:
                            attributes.append({
                                'key': field,
                                'value': row[csv_col],
                                'data_type': 'string'
                            })
                    
                    # Create contact
                    contact_data = ContactCreate(
                        email=email,
                        name=name,
                        attributes=attributes
                    )
                    
                    contact = await self.add_contact(list_id, user_id, contact_data)
                    
                    if contact.created_at == contact.updated_at:
                        results["imported"] += 1
                    else:
                        results["updated"] += 1
                        
                except Exception as e:
                    results["failed"] += 1
                    results["errors"].append({
                        "row": results["total"],
                        "error": str(e)
                    })
            
            # Update list stats
            await self._update_list_stats(list_id)
            
        except Exception as e:
            logger.error(f"CSV import error: {str(e)}")
            raise
        
        return results
    
    async def _update_list_stats(self, list_id: str):
        """Update cached statistics for email list"""
        result = await self.db.execute(
            select(func.count()).where(Contact.email_list_id == list_id)
        )
        total = result.scalar()
        
        result = await self.db.execute(
            select(func.count()).where(
                Contact.email_list_id == list_id,
                Contact.status == "active"
            )
        )
        active = result.scalar()
        
        result = await self.db.execute(
            select(func.count()).where(
                Contact.email_list_id == list_id,
                Contact.status == "bounced"
            )
        )
        bounced = result.scalar()
        
        result = await self.db.execute(
            select(func.count()).where(
                Contact.email_list_id == list_id,
                Contact.status == "unsubscribed"
            )
        )
        unsubscribed = result.scalar()
        
        await self.db.execute(
            update(EmailList)
            .where(EmailList.id == list_id)
            .values(
                total_contacts=total,
                active_contacts=active,
                bounced_contacts=bounced,
                unsubscribed_contacts=unsubscribed,
                updated_at=datetime.utcnow()
            )
        )
        await self.db.commit()
    
    async def unsubscribe_contact(self, contact_id: str, reason: Optional[str] = None) -> bool:
        """Unsubscribe a contact"""
        contact = await self.get_contact(contact_id)
        if not contact:
            return False
        
        contact.status = "unsubscribed"
        contact.unsubscribed_at = datetime.utcnow()
        contact.unsubscribe_reason = reason
        
        await self.db.commit()
        
        # Update list stats
        await self._update_list_stats(contact.email_list_id)
        
        logger.info(f"Unsubscribed contact {contact_id}")
        return True
    
    async def search_contacts(self, user_id: str, query: str,
                             list_id: Optional[str] = None,
                             page: int = 1, per_page: int = 50) -> Dict[str, Any]:
        """Search contacts"""
        search_query = select(Contact).where(Contact.user_id == user_id)
        
        if list_id:
            search_query = search_query.where(Contact.email_list_id == list_id)
        
        # Search in email and name
        search_filter = or_(
            Contact.email.ilike(f"%{query}%"),
            Contact.name.ilike(f"%{query}%")
        )
        search_query = search_query.where(search_filter)
        
        # Get total count
        count_result = await self.db.execute(
            select(func.count()).select_from(search_query.subquery())
        )
        total = count_result.scalar()
        
        # Get paginated results
        search_query = search_query.order_by(Contact.created_at.desc())
        search_query = search_query.offset((page - 1) * per_page).limit(per_page)
        
        result = await self.db.execute(search_query)
        contacts = result.scalars().all()
        
        return {
            "items": contacts,
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page
        }
