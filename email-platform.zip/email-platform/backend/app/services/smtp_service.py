"""
SMTP Service - SMTP account and domain management
"""
from datetime import datetime
from typing import Optional, List, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, func
import secrets
import logging

from app.models.smtp import SMTPAccount, SMTPDomain
from app.schemas.smtp import SMTPAccountCreate, SMTPAccountUpdate, SMTPDomainCreate, SMTPDomainUpdate
from app.config import settings

logger = logging.getLogger(__name__)


class SMTPService:
    def __init__(self, db: AsyncSession):
        self.db = db
    
    # SMTP Domain Methods
    async def create_domain(self, user_id: str, data: SMTPDomainCreate) -> SMTPDomain:
        """Create a new SMTP domain"""
        # Check if domain already exists
        result = await self.db.execute(
            select(SMTPDomain).where(SMTPDomain.domain == data.domain)
        )
        if result.scalar_one_or_none():
            raise ValueError("Domain already exists")
        
        # Generate verification token
        verification_token = secrets.token_urlsafe(32)
        
        # Generate DNS records
        spf_record = f"v=spf1 include:{settings.TRACKING_DOMAIN} ~all"
        dkim_record = None  # Will be generated after DKIM setup
        dmarc_record = f"v=DMARC1; p=quarantine; rua=mailto:dmarc@{data.domain}"
        mx_record = f"10 {settings.TRACKING_DOMAIN}"
        
        domain = SMTPDomain(
            user_id=user_id,
            domain=data.domain,
            is_verified=False,
            verification_token=verification_token,
            spf_record=spf_record,
            dkim_record=dkim_record,
            dmarc_record=dmarc_record,
            mx_record=mx_record,
            dkim_selector=data.dkim_selector,
        )
        
        self.db.add(domain)
        await self.db.commit()
        await self.db.refresh(domain)
        
        logger.info(f"Created SMTP domain {data.domain} for user {user_id}")
        return domain
    
    async def get_domain(self, domain_id: str,
                        user_id: Optional[str] = None) -> Optional[SMTPDomain]:
        """Get domain by ID"""
        query = select(SMTPDomain).where(SMTPDomain.id == domain_id)
        if user_id:
            query = query.where(SMTPDomain.user_id == user_id)
        
        result = await self.db.execute(query)
        return result.scalar_one_or_none()
    
    async def get_domain_by_name(self, domain: str) -> Optional[SMTPDomain]:
        """Get domain by name"""
        result = await self.db.execute(
            select(SMTPDomain).where(SMTPDomain.domain == domain)
        )
        return result.scalar_one_or_none()
    
    async def get_domains(self, user_id: str, page: int = 1,
                         per_page: int = 50) -> Dict[str, Any]:
        """Get all domains for user"""
        query = select(SMTPDomain).where(SMTPDomain.user_id == user_id)
        
        # Get total count
        count_result = await self.db.execute(
            select(func.count()).select_from(query.subquery())
        )
        total = count_result.scalar()
        
        # Get paginated results
        query = query.order_by(SMTPDomain.created_at.desc())
        query = query.offset((page - 1) * per_page).limit(per_page)
        
        result = await self.db.execute(query)
        domains = result.scalars().all()
        
        return {
            "items": domains,
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page
        }
    
    async def update_domain(self, domain_id: str, user_id: str,
                           data: SMTPDomainUpdate) -> Optional[SMTPDomain]:
        """Update domain"""
        domain = await self.get_domain(domain_id, user_id)
        if not domain:
            return None
        
        update_data = data.dict(exclude_unset=True)
        for key, value in update_data.items():
            setattr(domain, key, value)
        
        domain.updated_at = datetime.utcnow()
        await self.db.commit()
        await self.db.refresh(domain)
        
        return domain
    
    async def delete_domain(self, domain_id: str, user_id: str) -> bool:
        """Delete domain"""
        domain = await self.get_domain(domain_id, user_id)
        if not domain:
            return False
        
        await self.db.delete(domain)
        await self.db.commit()
        
        logger.info(f"Deleted domain {domain_id}")
        return True
    
    async def verify_domain(self, domain_id: str, user_id: str) -> Dict[str, Any]:
        """Verify domain DNS records"""
        domain = await self.get_domain(domain_id, user_id)
        if not domain:
            raise ValueError("Domain not found")
        
        # In production, this would actually check DNS records
        # For now, we'll simulate verification
        spf_verified = True
        dkim_verified = bool(domain.dkim_record)
        dmarc_verified = True
        mx_verified = True
        
        is_verified = spf_verified and dmarc_verified and mx_verified
        
        if is_verified:
            domain.is_verified = True
            domain.verified_at = datetime.utcnow()
            await self.db.commit()
        
        return {
            "domain": domain.domain,
            "is_verified": is_verified,
            "spf_verified": spf_verified,
            "dkim_verified": dkim_verified,
            "dmarc_verified": dmarc_verified,
            "mx_verified": mx_verified,
            "message": "Domain verified successfully" if is_verified else "Some DNS records are missing"
        }
    
    # SMTP Account Methods
    async def create_account(self, user_id: str, data: SMTPAccountCreate) -> SMTPAccount:
        """Create a new SMTP account"""
        # Generate username
        username = f"{user_id}_{secrets.token_hex(8)}"
        
        # Generate password
        password = secrets.token_urlsafe(32)
        
        # Hash password (in production, use proper hashing)
        password_hash = password  # TODO: Implement proper hashing
        
        account = SMTPAccount(
            user_id=user_id,
            domain_id=data.domain_id,
            username=username,
            password_hash=password_hash,
            name=data.name,
            description=data.description,
            hourly_limit=data.hourly_limit,
            daily_limit=data.daily_limit,
            monthly_limit=data.monthly_limit,
            require_tls=data.require_tls,
        )
        
        self.db.add(account)
        await self.db.commit()
        await self.db.refresh(account)
        
        logger.info(f"Created SMTP account {account.id} for user {user_id}")
        return account
    
    async def get_account(self, account_id: str,
                         user_id: Optional[str] = None) -> Optional[SMTPAccount]:
        """Get SMTP account by ID"""
        query = select(SMTPAccount).where(SMTPAccount.id == account_id)
        if user_id:
            query = query.where(SMTPAccount.user_id == user_id)
        
        result = await self.db.execute(query)
        return result.scalar_one_or_none()
    
    async def get_account_by_username(self, username: str) -> Optional[SMTPAccount]:
        """Get SMTP account by username"""
        result = await self.db.execute(
            select(SMTPAccount).where(SMTPAccount.username == username)
        )
        return result.scalar_one_or_none()
    
    async def get_accounts(self, user_id: str, page: int = 1,
                          per_page: int = 50) -> Dict[str, Any]:
        """Get all SMTP accounts for user"""
        query = select(SMTPAccount).where(SMTPAccount.user_id == user_id)
        
        # Get total count
        count_result = await self.db.execute(
            select(func.count()).select_from(query.subquery())
        )
        total = count_result.scalar()
        
        # Get paginated results
        query = query.order_by(SMTPAccount.created_at.desc())
        query = query.offset((page - 1) * per_page).limit(per_page)
        
        result = await self.db.execute(query)
        accounts = result.scalars().all()
        
        return {
            "items": accounts,
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page
        }
    
    async def update_account(self, account_id: str, user_id: str,
                            data: SMTPAccountUpdate) -> Optional[SMTPAccount]:
        """Update SMTP account"""
        account = await self.get_account(account_id, user_id)
        if not account:
            return None
        
        update_data = data.dict(exclude_unset=True)
        for key, value in update_data.items():
            setattr(account, key, value)
        
        account.updated_at = datetime.utcnow()
        await self.db.commit()
        await self.db.refresh(account)
        
        return account
    
    async def delete_account(self, account_id: str, user_id: str) -> bool:
        """Delete SMTP account"""
        account = await self.get_account(account_id, user_id)
        if not account:
            return False
        
        await self.db.delete(account)
        await self.db.commit()
        
        logger.info(f"Deleted SMTP account {account_id}")
        return True
    
    async def regenerate_password(self, account_id: str, user_id: str) -> Dict[str, str]:
        """Regenerate SMTP account password"""
        account = await self.get_account(account_id, user_id)
        if not account:
            raise ValueError("Account not found")
        
        new_password = secrets.token_urlsafe(32)
        account.password_hash = new_password  # TODO: Hash properly
        await self.db.commit()
        
        return {
            "username": account.username,
            "password": new_password,
            "message": "Password regenerated successfully"
        }
    
    async def get_smtp_settings(self) -> Dict[str, Any]:
        """Get SMTP server settings for clients"""
        return {
            "host": settings.SMTP_HOST,
            "ports": {
                "submission": 587,
                "smtps": 465,
                "smtp": 25
            },
            "encryption": ["TLS", "SSL"],
            "authentication": "PLAIN"
        }
    
    async def get_account_usage(self, account_id: str, user_id: str) -> Dict[str, Any]:
        """Get SMTP account usage statistics"""
        account = await self.get_account(account_id, user_id)
        if not account:
            raise ValueError("Account not found")
        
        return {
            "hourly": {
                "used": account.emails_sent_hour,
                "limit": account.hourly_limit,
                "remaining": max(0, account.hourly_limit - account.emails_sent_hour)
            },
            "daily": {
                "used": account.emails_sent_day,
                "limit": account.daily_limit,
                "remaining": max(0, account.daily_limit - account.emails_sent_day)
            },
            "monthly": {
                "used": account.emails_sent_month,
                "limit": account.monthly_limit,
                "remaining": max(0, account.monthly_limit - account.emails_sent_month)
            }
        }
    
    async def check_rate_limit(self, account_id: str) -> bool:
        """Check if account has exceeded rate limits"""
        account = await self.get_account(account_id)
        if not account:
            return False
        
        # Reset counters if needed
        now = datetime.utcnow()
        
        if account.hour_reset_at and (now - account.hour_reset_at).total_seconds() >= 3600:
            account.emails_sent_hour = 0
            account.hour_reset_at = now
        
        if account.day_reset_at and (now - account.day_reset_at).days >= 1:
            account.emails_sent_day = 0
            account.day_reset_at = now
        
        if account.month_reset_at and (now - account.month_reset_at).days >= 30:
            account.emails_sent_month = 0
            account.month_reset_at = now
        
        await self.db.commit()
        
        # Check limits
        if account.emails_sent_hour >= account.hourly_limit:
            return False
        if account.emails_sent_day >= account.daily_limit:
            return False
        if account.emails_sent_month >= account.monthly_limit:
            return False
        
        return True
    
    async def increment_usage(self, account_id: str):
        """Increment email usage for account"""
        account = await self.get_account(account_id)
        if not account:
            return
        
        now = datetime.utcnow()
        
        # Initialize reset times if needed
        if not account.hour_reset_at:
            account.hour_reset_at = now
        if not account.day_reset_at:
            account.day_reset_at = now
        if not account.month_reset_at:
            account.month_reset_at = now
        
        account.emails_sent_hour += 1
        account.emails_sent_day += 1
        account.emails_sent_month += 1
        account.last_used_at = now
        
        await self.db.commit()
