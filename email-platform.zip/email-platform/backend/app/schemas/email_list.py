"""
Email List and Contact Schemas
"""
from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List, Dict, Any
from datetime import datetime


# Contact Attribute Schemas
class ContactAttributeCreate(BaseModel):
    key: str
    value: Optional[str] = None
    data_type: str = "string"


class ContactAttributeResponse(ContactAttributeCreate):
    id: str
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# Contact Schemas
class ContactBase(BaseModel):
    email: EmailStr
    name: Optional[str] = None


class ContactCreate(ContactBase):
    attributes: Optional[List[ContactAttributeCreate]] = []
    tags: Optional[List[str]] = []


class ContactUpdate(BaseModel):
    email: Optional[EmailStr] = None
    name: Optional[str] = None
    status: Optional[str] = None
    attributes: Optional[List[ContactAttributeCreate]] = []


class ContactResponse(ContactBase):
    id: str
    email_list_id: str
    user_id: str
    status: str
    is_valid: bool
    last_sent_at: Optional[datetime] = None
    last_opened_at: Optional[datetime] = None
    last_clicked_at: Optional[datetime] = None
    send_count: int
    open_count: int
    click_count: int
    bounce_count: int
    last_bounce_at: Optional[datetime] = None
    bounce_reason: Optional[str] = None
    bounce_type: Optional[str] = None
    unsubscribed_at: Optional[datetime] = None
    attributes: List[ContactAttributeResponse] = []
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class ContactImport(BaseModel):
    contacts: List[ContactCreate]
    skip_invalid: bool = True
    update_existing: bool = False


class ContactImportResponse(BaseModel):
    total: int
    imported: int
    updated: int
    failed: int
    errors: List[Dict[str, Any]]


class ContactBulkAction(BaseModel):
    contact_ids: List[str]
    action: str  # delete, unsubscribe, activate, deactivate


# Email List Schemas
class EmailListBase(BaseModel):
    name: str
    description: Optional[str] = None


class EmailListCreate(EmailListBase):
    double_opt_in: bool = True
    auto_clean_enabled: bool = True
    auto_clean_after_bounces: int = 3


class EmailListUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    double_opt_in: Optional[bool] = None
    auto_clean_enabled: Optional[bool] = None
    auto_clean_after_bounces: Optional[int] = None


class EmailListResponse(EmailListBase):
    id: str
    user_id: str
    is_public: bool
    double_opt_in: bool
    auto_clean_enabled: bool
    auto_clean_after_bounces: int
    total_contacts: int
    active_contacts: int
    bounced_contacts: int
    unsubscribed_contacts: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class EmailListWithContacts(EmailListResponse):
    contacts: List[ContactResponse] = []


class EmailListStats(BaseModel):
    total_lists: int
    total_contacts: int
    active_contacts: int
    bounced_contacts: int
    unsubscribed_contacts: int
    recent_imports: int
    recent_exports: int


# CSV Import Schemas
class CSVImportRequest(BaseModel):
    list_id: str
    mapping: Dict[str, str]  # column_name -> field_name
    skip_first_row: bool = True
    default_status: str = "active"


class CSVImportPreview(BaseModel):
    total_rows: int
    valid_rows: int
    invalid_rows: int
    sample_data: List[Dict[str, Any]]
    column_mapping: Dict[str, str]


class CSVImportResult(BaseModel):
    import_id: str
    total_processed: int
    imported: int
    updated: int
    failed: int
    errors: List[Dict[str, Any]]
