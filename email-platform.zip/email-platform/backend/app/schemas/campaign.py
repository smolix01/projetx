"""
Campaign Schemas
"""
from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum


class CampaignStatus(str, Enum):
    DRAFT = "draft"
    SCHEDULED = "scheduled"
    SENDING = "sending"
    SENT = "sent"
    PAUSED = "paused"
    CANCELLED = "cancelled"


class CampaignBase(BaseModel):
    name: str
    subject: str
    from_name: str
    from_email: EmailStr
    reply_to: Optional[EmailStr] = None


class CampaignCreate(CampaignBase):
    html_content: Optional[str] = None
    text_content: Optional[str] = None
    email_list_id: Optional[str] = None
    segment_conditions: Optional[Dict[str, Any]] = None
    track_opens: bool = True
    track_clicks: bool = True
    scheduled_at: Optional[datetime] = None


class CampaignUpdate(BaseModel):
    name: Optional[str] = None
    subject: Optional[str] = None
    from_name: Optional[str] = None
    from_email: Optional[EmailStr] = None
    reply_to: Optional[EmailStr] = None
    html_content: Optional[str] = None
    text_content: Optional[str] = None
    email_list_id: Optional[str] = None
    segment_conditions: Optional[Dict[str, Any]] = None
    track_opens: Optional[bool] = None
    track_clicks: Optional[bool] = None
    scheduled_at: Optional[datetime] = None
    status: Optional[CampaignStatus] = None


class CampaignResponse(CampaignBase):
    id: str
    user_id: str
    html_content: Optional[str] = None
    text_content: Optional[str] = None
    status: CampaignStatus
    scheduled_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    email_list_id: Optional[str] = None
    track_opens: bool
    track_clicks: bool
    total_recipients: int
    sent_count: int
    delivered_count: int
    opened_count: int
    clicked_count: int
    bounced_count: int
    complained_count: int
    unsubscribed_count: int
    unique_opens: int
    unique_clicks: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class CampaignRecipientResponse(BaseModel):
    id: str
    campaign_id: str
    contact_id: str
    status: str
    sent_at: Optional[datetime] = None
    delivered_at: Optional[datetime] = None
    opened_at: Optional[datetime] = None
    clicked_at: Optional[datetime] = None
    bounced_at: Optional[datetime] = None
    open_count: int
    click_count: int
    error_message: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
    contact: Optional[Dict[str, Any]] = None

    class Config:
        from_attributes = True


class CampaignStats(BaseModel):
    total_campaigns: int
    draft: int
    scheduled: int
    sending: int
    sent: int
    paused: int
    cancelled: int
    total_recipients: int
    total_sent: int
    total_delivered: int
    total_opened: int
    total_clicked: int
    total_bounced: int
    avg_open_rate: float
    avg_click_rate: float
    avg_bounce_rate: float


class CampaignSendRequest(BaseModel):
    campaign_id: str
    test_mode: bool = False
    test_emails: Optional[List[EmailStr]] = []


class CampaignScheduleRequest(BaseModel):
    scheduled_at: datetime


class CampaignTestRequest(BaseModel):
    test_emails: List[EmailStr]
