"""
Pydantic Schemas for API
"""
from app.schemas.user import UserCreate, UserResponse, UserLogin, Token
from app.schemas.email_list import (
    EmailListCreate, EmailListResponse, EmailListUpdate,
    ContactCreate, ContactResponse, ContactUpdate, ContactImport,
    ContactAttributeCreate, ContactAttributeResponse
)
from app.schemas.campaign import (
    CampaignCreate, CampaignResponse, CampaignUpdate,
    CampaignRecipientResponse, CampaignStats
)
from app.schemas.email import (
    EmailCreate, EmailResponse, EmailUpdate,
    EmailLogResponse, EmailEventResponse, SendEmailRequest,
    BulkEmailRequest, EmailStats
)
from app.schemas.smtp import (
    SMTPAccountCreate, SMTPAccountResponse, SMTPAccountUpdate,
    SMTPDomainCreate, SMTPDomainResponse, SMTPDomainUpdate,
    SMTPCredentials
)
from app.schemas.bounce import (
    BounceResponse, BounceLogResponse, BounceStats,
    SuppressedEmailResponse
)
from app.schemas.tracking import (
    TrackingPixelResponse, TrackingLinkResponse,
    TrackingEventResponse, TrackingStats
)

__all__ = [
    # User
    "UserCreate", "UserResponse", "UserLogin", "Token",
    # Email List
    "EmailListCreate", "EmailListResponse", "EmailListUpdate",
    "ContactCreate", "ContactResponse", "ContactUpdate", "ContactImport",
    "ContactAttributeCreate", "ContactAttributeResponse",
    # Campaign
    "CampaignCreate", "CampaignResponse", "CampaignUpdate",
    "CampaignRecipientResponse", "CampaignStats",
    # Email
    "EmailCreate", "EmailResponse", "EmailUpdate",
    "EmailLogResponse", "EmailEventResponse", "SendEmailRequest",
    "BulkEmailRequest", "EmailStats",
    # SMTP
    "SMTPAccountCreate", "SMTPAccountResponse", "SMTPAccountUpdate",
    "SMTPDomainCreate", "SMTPDomainResponse", "SMTPDomainUpdate",
    "SMTPCredentials",
    # Bounce
    "BounceResponse", "BounceLogResponse", "BounceStats",
    "SuppressedEmailResponse",
    # Tracking
    "TrackingPixelResponse", "TrackingLinkResponse",
    "TrackingEventResponse", "TrackingStats",
]
