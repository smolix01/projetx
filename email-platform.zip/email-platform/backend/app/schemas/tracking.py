"""
Email Tracking Schemas
"""
from pydantic import BaseModel, EmailStr
from typing import Optional, List, Dict, Any
from datetime import datetime


class TrackingPixelResponse(BaseModel):
    id: str
    pixel_id: str
    email_id: str
    campaign_id: Optional[str] = None
    contact_id: Optional[str] = None
    user_id: str
    is_opened: bool
    open_count: int
    first_opened_at: Optional[datetime] = None
    last_opened_at: Optional[datetime] = None
    created_at: datetime

    class Config:
        from_attributes = True


class TrackingLinkResponse(BaseModel):
    id: str
    link_id: str
    email_id: str
    campaign_id: Optional[str] = None
    contact_id: Optional[str] = None
    user_id: str
    original_url: str
    shortened_url: Optional[str] = None
    click_count: int
    unique_clicks: int
    created_at: datetime

    class Config:
        from_attributes = True


class TrackingEventResponse(BaseModel):
    id: str
    event_type: str  # open, click
    email_id: str
    campaign_id: Optional[str] = None
    contact_id: Optional[str] = None
    user_id: str
    link_id: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    device_type: Optional[str] = None
    browser: Optional[str] = None
    browser_version: Optional[str] = None
    operating_system: Optional[str] = None
    os_version: Optional[str] = None
    country: Optional[str] = None
    country_code: Optional[str] = None
    region: Optional[str] = None
    city: Optional[str] = None
    latitude: Optional[str] = None
    longitude: Optional[str] = None
    clicked_url: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class TrackingStats(BaseModel):
    total_opens: int
    unique_opens: int
    total_clicks: int
    unique_clicks: int
    open_rate: float
    click_rate: float
    click_to_open_rate: float
    by_device: Dict[str, int]
    by_browser: Dict[str, int]
    by_os: Dict[str, int]
    by_country: Dict[str, int]
    hourly_opens: Dict[str, int]
    hourly_clicks: Dict[str, int]


class LinkStats(BaseModel):
    link_id: str
    original_url: str
    total_clicks: int
    unique_clicks: int
    clickers: List[Dict[str, Any]]


class TrackingDashboardStats(BaseModel):
    today_opens: int
    today_clicks: int
    week_opens: int
    week_clicks: int
    month_opens: int
    month_clicks: int
    top_links: List[LinkStats]
    top_countries: List[Dict[str, Any]]
    recent_activity: List[TrackingEventResponse]


class TrackingPixelRequest(BaseModel):
    email_id: str
    campaign_id: Optional[str] = None
    contact_id: Optional[str] = None


class TrackingLinkRequest(BaseModel):
    email_id: str
    original_url: str
    campaign_id: Optional[str] = None
    contact_id: Optional[str] = None


class TrackingWebhookPayload(BaseModel):
    event_type: str
    email_id: str
    timestamp: datetime
    data: Dict[str, Any]
