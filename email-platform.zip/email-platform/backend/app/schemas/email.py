"""
Email Schemas
"""
from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum


class EmailStatus(str, Enum):
    QUEUED = "queued"
    SENDING = "sending"
    SENT = "sent"
    DELIVERED = "delivered"
    OPENED = "opened"
    CLICKED = "clicked"
    BOUNCED = "bounced"
    FAILED = "failed"
    RETRYING = "retrying"


class EmailBase(BaseModel):
    to_email: EmailStr
    to_name: Optional[str] = None
    from_email: EmailStr
    from_name: Optional[str] = None
    reply_to: Optional[EmailStr] = None
    subject: str


class EmailCreate(EmailBase):
    html_content: Optional[str] = None
    text_content: Optional[str] = None
    track_opens: bool = True
    track_clicks: bool = True
    campaign_id: Optional[str] = None
    smtp_account_id: Optional[str] = None
    tags: Optional[List[str]] = []
    headers: Optional[Dict[str, str]] = {}


class EmailUpdate(BaseModel):
    status: Optional[EmailStatus] = None
    retry_count: Optional[int] = None
    error_message: Optional[str] = None


class EmailResponse(EmailBase):
    id: str
    user_id: str
    message_id: Optional[str] = None
    html_content: Optional[str] = None
    text_content: Optional[str] = None
    status: EmailStatus
    track_opens: bool
    track_clicks: bool
    campaign_id: Optional[str] = None
    smtp_account_id: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
    sent_at: Optional[datetime] = None
    delivered_at: Optional[datetime] = None
    opened_at: Optional[datetime] = None
    clicked_at: Optional[datetime] = None
    bounced_at: Optional[datetime] = None
    retry_count: int
    max_retries: int
    next_retry_at: Optional[datetime] = None
    error_message: Optional[str] = None
    tags: Optional[List[str]] = []

    class Config:
        from_attributes = True


class EmailLogResponse(BaseModel):
    id: str
    email_id: str
    event_type: str
    event_data: Optional[Dict[str, Any]] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class EmailEventResponse(BaseModel):
    id: str
    email_id: str
    user_id: str
    event_type: str
    event_count: int
    link_url: Optional[str] = None
    bounce_type: Optional[str] = None
    bounce_reason: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    country: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class SendEmailRequest(BaseModel):
    to: EmailStr
    to_name: Optional[str] = None
    from_email: Optional[EmailStr] = None
    from_name: Optional[str] = None
    reply_to: Optional[EmailStr] = None
    subject: str
    html: Optional[str] = None
    text: Optional[str] = None
    track_opens: bool = True
    track_clicks: bool = True
    tags: Optional[List[str]] = []
    headers: Optional[Dict[str, str]] = {}


class BulkEmailRequest(BaseModel):
    recipients: List[SendEmailRequest]
    batch_size: Optional[int] = 100
    delay_between_batches: Optional[int] = 1


class BulkEmailResponse(BaseModel):
    batch_id: str
    total: int
    queued: int
    failed: int
    errors: List[Dict[str, Any]]


class EmailStats(BaseModel):
    total_emails: int
    queued: int
    sending: int
    sent: int
    delivered: int
    opened: int
    clicked: int
    bounced: int
    failed: int
    retrying: int
    delivery_rate: float
    open_rate: float
    click_rate: float
    bounce_rate: float


class EmailQueryParams(BaseModel):
    status: Optional[EmailStatus] = None
    campaign_id: Optional[str] = None
    to_email: Optional[str] = None
    from_date: Optional[datetime] = None
    to_date: Optional[datetime] = None
    tags: Optional[List[str]] = None
    page: int = 1
    per_page: int = 50


class EmailTestRequest(BaseModel):
    test_email: EmailStr
    subject: str
    html_content: Optional[str] = None
    text_content: Optional[str] = None
    from_email: Optional[EmailStr] = None
    from_name: Optional[str] = None
