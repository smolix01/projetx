"""
SMTP Account and Domain Schemas
"""
from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List, Dict, Any
from datetime import datetime


# SMTP Domain Schemas
class SMTPDomainBase(BaseModel):
    domain: str


class SMTPDomainCreate(SMTPDomainBase):
    dkim_selector: str = "default"


class SMTPDomainUpdate(BaseModel):
    is_active: Optional[bool] = None
    dkim_selector: Optional[str] = None


class SMTPDomainResponse(SMTPDomainBase):
    id: str
    user_id: str
    is_verified: bool
    spf_record: Optional[str] = None
    dkim_record: Optional[str] = None
    dmarc_record: Optional[str] = None
    mx_record: Optional[str] = None
    verification_token: Optional[str] = None
    verified_at: Optional[datetime] = None
    dkim_selector: str
    is_active: bool
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class SMTPDomainVerifyResponse(BaseModel):
    domain: str
    is_verified: bool
    spf_verified: bool
    dkim_verified: bool
    dmarc_verified: bool
    mx_verified: bool
    message: str


# SMTP Account Schemas
class SMTPAccountBase(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None


class SMTPAccountCreate(SMTPAccountBase):
    domain_id: Optional[str] = None
    hourly_limit: int = 100
    daily_limit: int = 1000
    monthly_limit: int = 30000
    require_tls: bool = True


class SMTPAccountUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None
    hourly_limit: Optional[int] = None
    daily_limit: Optional[int] = None
    monthly_limit: Optional[int] = None
    require_tls: Optional[bool] = None
    allowed_ips: Optional[List[str]] = None


class SMTPAccountResponse(SMTPAccountBase):
    id: str
    user_id: str
    domain_id: Optional[str] = None
    username: str
    hourly_limit: int
    daily_limit: int
    monthly_limit: int
    emails_sent_hour: int
    emails_sent_day: int
    emails_sent_month: int
    is_active: bool
    require_tls: bool
    allowed_ips: Optional[List[str]] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
    last_used_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class SMTPCredentials(BaseModel):
    host: str
    port: int
    username: str
    password: str
    tls: bool
    ssl: bool


class SMTPAccountWithCredentials(SMTPAccountResponse):
    credentials: SMTPCredentials


class SMTPSettingsResponse(BaseModel):
    host: str
    ports: Dict[str, int]
    encryption: List[str]
    authentication: str


class SMTPUsageStats(BaseModel):
    hourly_used: int
    hourly_limit: int
    hourly_remaining: int
    daily_used: int
    daily_limit: int
    daily_remaining: int
    monthly_used: int
    monthly_limit: int
    monthly_remaining: int
    reset_times: Dict[str, datetime]
