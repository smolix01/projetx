"""
Bounce and Suppression Schemas
"""
from pydantic import BaseModel, EmailStr
from typing import Optional, List, Dict, Any
from datetime import datetime


class BounceBase(BaseModel):
    email_address: EmailStr
    bounce_type: str  # hard, soft


class BounceCreate(BounceBase):
    email_id: Optional[str] = None
    contact_id: Optional[str] = None
    bounce_code: Optional[str] = None
    bounce_reason: Optional[str] = None
    bounce_category: Optional[str] = None
    original_message_id: Optional[str] = None
    original_subject: Optional[str] = None
    dsn_message: Optional[str] = None
    dsn_status: Optional[str] = None
    dsn_diagnostic_code: Optional[str] = None
    remote_mta: Optional[str] = None
    reporting_mta: Optional[str] = None
    bounce_timestamp: Optional[datetime] = None


class BounceResponse(BounceBase):
    id: str
    email_id: Optional[str] = None
    contact_id: Optional[str] = None
    user_id: str
    bounce_code: Optional[str] = None
    bounce_reason: Optional[str] = None
    bounce_category: Optional[str] = None
    original_message_id: Optional[str] = None
    original_subject: Optional[str] = None
    dsn_message: Optional[str] = None
    dsn_status: Optional[str] = None
    dsn_diagnostic_code: Optional[str] = None
    remote_mta: Optional[str] = None
    reporting_mta: Optional[str] = None
    is_processed: bool
    processed_at: Optional[datetime] = None
    action_taken: Optional[str] = None
    created_at: datetime
    bounce_timestamp: Optional[datetime] = None

    class Config:
        from_attributes = True


class BounceLogResponse(BaseModel):
    id: str
    bounce_id: str
    action: str
    details: Optional[Dict[str, Any]] = None
    created_at: datetime

    class Config:
        from_attributes = True


class BounceStats(BaseModel):
    total_bounces: int
    hard_bounces: int
    soft_bounces: int
    processed: int
    pending: int
    by_category: Dict[str, int]
    by_date: Dict[str, int]
    bounce_rate: float


class BounceProcessRequest(BaseModel):
    bounce_ids: Optional[List[str]] = None
    process_all: bool = False


class BounceProcessResponse(BaseModel):
    processed: int
    failed: int
    actions: Dict[str, int]


class SuppressedEmailBase(BaseModel):
    email_address: EmailStr
    reason: str  # bounce, complaint, unsubscribe, manual


class SuppressedEmailCreate(SuppressedEmailBase):
    reason_details: Optional[str] = None
    source_type: Optional[str] = None
    source_id: Optional[str] = None


class SuppressedEmailResponse(SuppressedEmailBase):
    id: str
    reason_details: Optional[str] = None
    source_type: Optional[str] = None
    source_id: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class SuppressionListQuery(BaseModel):
    reason: Optional[str] = None
    source_type: Optional[str] = None
    search: Optional[str] = None
    page: int = 1
    per_page: int = 50


class SuppressionCheckRequest(BaseModel):
    email_addresses: List[EmailStr]


class SuppressionCheckResponse(BaseModel):
    results: Dict[str, bool]  # email -> is_suppressed
