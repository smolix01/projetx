"""
Email Worker - Processes email sending jobs
"""
import asyncio
import logging
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import AsyncSessionLocal
from app.services.email_service import EmailService
from app.services.queue_service import QueueService

logger = logging.getLogger(__name__)


class EmailWorker:
    """Worker for processing email sending jobs"""
    
    def __init__(self):
        self.queue_service = QueueService()
        self.running = False
    
    async def process_job(self, job: dict):
        """Process a single email job"""
        job_data = job.get("data", {})
        email_id = job_data.get("email_id")
        
        if not email_id:
            logger.error("Email job missing email_id")
            return False
        
        async with AsyncSessionLocal() as db:
            try:
                email_service = EmailService(db)
                success = await email_service.send_email(email_id)
                
                if success:
                    logger.info(f"Successfully sent email {email_id}")
                    await self.queue_service.ack("send_email", job["id"])
                else:
                    logger.warning(f"Failed to send email {email_id}")
                    await self.queue_service.nack("send_email", job, requeue=True, delay=300)
                
                return success
                
            except Exception as e:
                logger.error(f"Error processing email job {email_id}: {str(e)}")
                await self.queue_service.nack("send_email", job, requeue=True, delay=300)
                return False
    
    async def run(self):
        """Run the worker loop"""
        self.running = True
        logger.info("Email worker started")
        
        while self.running:
            try:
                # Process delayed jobs first
                await self.queue_service.process_delayed("send_email")
                
                # Get job from queue
                job = await self.queue_service.dequeue("send_email", timeout=5)
                
                if job:
                    await self.process_job(job)
                else:
                    # No job available, wait a bit
                    await asyncio.sleep(1)
                    
            except Exception as e:
                logger.error(f"Error in email worker loop: {str(e)}")
                await asyncio.sleep(5)
        
        logger.info("Email worker stopped")
    
    def stop(self):
        """Stop the worker"""
        self.running = False
        self.queue_service.close()


async def run_email_worker():
    """Run email worker standalone"""
    worker = EmailWorker()
    try:
        await worker.run()
    except KeyboardInterrupt:
        worker.stop()


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    asyncio.run(run_email_worker())
