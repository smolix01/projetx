"""
Bounce Worker - Processes bounce handling jobs
"""
import asyncio
import logging
import imaplib
import email
from email.header import decode_header
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import AsyncSessionLocal
from app.services.bounce_service import BounceService
from app.services.queue_service import QueueService
from app.config import settings

logger = logging.getLogger(__name__)


class BounceWorker:
    """Worker for processing bounce emails via IMAP"""
    
    def __init__(self):
        self.queue_service = QueueService()
        self.running = False
        self.check_interval = settings.BOUNCE_CHECK_INTERVAL
    
    async def process_job(self, job: dict):
        """Process a bounce processing job"""
        job_data = job.get("data", {})
        bounce_id = job_data.get("bounce_id")
        
        if not bounce_id:
            logger.error("Bounce job missing bounce_id")
            return False
        
        async with AsyncSessionLocal() as db:
            try:
                bounce_service = BounceService(db)
                result = await bounce_service.process_bounce(bounce_id)
                
                if result.get("processed"):
                    logger.info(f"Successfully processed bounce {bounce_id}")
                    await self.queue_service.ack("process_bounce", job["id"])
                else:
                    logger.warning(f"Failed to process bounce {bounce_id}")
                    await self.queue_service.nack("process_bounce", job, requeue=False)
                
                return result.get("processed", False)
                
            except Exception as e:
                logger.error(f"Error processing bounce job {bounce_id}: {str(e)}")
                await self.queue_service.nack("process_bounce", job, requeue=True, delay=300)
                return False
    
    async def check_imap_bounces(self):
        """Check IMAP mailbox for bounce messages"""
        if not settings.BOUNCE_IMAP_PASSWORD:
            logger.debug("IMAP not configured, skipping bounce check")
            return
        
        try:
            # Connect to IMAP server
            mail = imaplib.IMAP4_SSL(settings.BOUNCE_IMAP_HOST, settings.BOUNCE_IMAP_PORT)
            mail.login(settings.BOUNCE_IMAP_USER, settings.BOUNCE_IMAP_PASSWORD)
            mail.select("inbox")
            
            # Search for unread messages
            _, search_data = mail.search(None, "UNSEEN")
            
            for num in search_data[0].split():
                try:
                    _, msg_data = mail.fetch(num, "(RFC822)")
                    raw_email = msg_data[0][1]
                    
                    # Parse email
                    msg = email.message_from_bytes(raw_email)
                    
                    # Extract bounce info
                    bounce_data = await self.parse_bounce_email(msg)
                    
                    if bounce_data:
                        # Create bounce record
                        async with AsyncSessionLocal() as db:
                            bounce_service = BounceService(db)
                            bounce = await bounce_service.create_bounce(
                                user_id="system",  # Will be determined from message
                                **bounce_data
                            )
                            
                            # Queue for processing
                            await self.queue_service.enqueue('process_bounce', {
                                'bounce_id': bounce.id
                            })
                            
                            logger.info(f"Created bounce record from IMAP: {bounce.id}")
                    
                    # Mark as read
                    mail.store(num, '+FLAGS', '\\Seen')
                    
                except Exception as e:
                    logger.error(f"Error processing bounce email: {str(e)}")
            
            mail.close()
            mail.logout()
            
        except Exception as e:
            logger.error(f"Error checking IMAP bounces: {str(e)}")
    
    async def parse_bounce_email(self, msg) -> dict:
        """Parse a bounce email and extract relevant information"""
        bounce_data = {
            "email_address": None,
            "bounce_type": "soft",
            "bounce_code": None,
            "bounce_reason": None,
            "original_message_id": None,
            "dsn_message": None,
        }
        
        # Get message body
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                content_type = part.get_content_type()
                if content_type == "text/plain":
                    body = part.get_payload(decode=True).decode('utf-8', errors='ignore')
                    break
        else:
            body = msg.get_payload(decode=True).decode('utf-8', errors='ignore')
        
        bounce_data["dsn_message"] = body
        
        # Parse bounce using bounce service
        async with AsyncSessionLocal() as db:
            bounce_service = BounceService(db)
            parsed = await bounce_service.parse_bounce_message(body)
            bounce_data.update(parsed)
        
        return bounce_data if bounce_data["email_address"] else None
    
    async def run(self):
        """Run the worker loop"""
        self.running = True
        logger.info("Bounce worker started")
        
        last_imap_check = 0
        
        while self.running:
            try:
                # Process delayed jobs
                await self.queue_service.process_delayed("process_bounce")
                
                # Get job from queue
                job = await self.queue_service.dequeue("process_bounce", timeout=5)
                
                if job:
                    await self.process_job(job)
                
                # Check IMAP for new bounces periodically
                current_time = asyncio.get_event_loop().time()
                if current_time - last_imap_check >= self.check_interval:
                    await self.check_imap_bounces()
                    last_imap_check = current_time
                
                if not job:
                    await asyncio.sleep(1)
                    
            except Exception as e:
                logger.error(f"Error in bounce worker loop: {str(e)}")
                await asyncio.sleep(5)
        
        logger.info("Bounce worker stopped")
    
    def stop(self):
        """Stop the worker"""
        self.running = False
        self.queue_service.close()


async def run_bounce_worker():
    """Run bounce worker standalone"""
    worker = BounceWorker()
    try:
        await worker.run()
    except KeyboardInterrupt:
        worker.stop()


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    asyncio.run(run_bounce_worker())
