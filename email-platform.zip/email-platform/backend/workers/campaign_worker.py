"""
Campaign Worker - Processes campaign sending jobs
"""
import asyncio
import logging
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import AsyncSessionLocal
from app.services.campaign_service import CampaignService
from app.services.queue_service import QueueService
from app.config import settings

logger = logging.getLogger(__name__)


class CampaignWorker:
    """Worker for processing campaign sending jobs"""
    
    def __init__(self):
        self.queue_service = QueueService()
        self.running = False
        self.batch_size = settings.BULK_BATCH_SIZE
    
    async def process_job(self, job: dict):
        """Process a single campaign job"""
        job_data = job.get("data", {})
        campaign_id = job_data.get("campaign_id")
        user_id = job_data.get("user_id")
        
        if not campaign_id:
            logger.error("Campaign job missing campaign_id")
            return False
        
        async with AsyncSessionLocal() as db:
            try:
                campaign_service = CampaignService(db)
                
                # Process a batch of recipients
                result = await campaign_service.process_campaign_batch(
                    campaign_id, self.batch_size
                )
                
                status = result.get("status")
                
                if status == "completed":
                    logger.info(f"Campaign {campaign_id} completed")
                    await self.queue_service.ack("send_campaign", job["id"])
                    return True
                elif status == "processing":
                    remaining = result.get("remaining", 0)
                    logger.info(f"Campaign {campaign_id} processed batch, {remaining} remaining")
                    
                    # Re-queue for next batch
                    await self.queue_service.enqueue('send_campaign', {
                        'campaign_id': campaign_id,
                        'user_id': user_id
                    })
                    await self.queue_service.ack("send_campaign", job["id"])
                    return True
                else:
                    logger.warning(f"Unexpected status for campaign {campaign_id}: {status}")
                    await self.queue_service.nack("send_campaign", job, requeue=False)
                    return False
                    
            except Exception as e:
                logger.error(f"Error processing campaign job {campaign_id}: {str(e)}")
                await self.queue_service.nack("send_campaign", job, requeue=True, delay=60)
                return False
    
    async def run(self):
        """Run the worker loop"""
        self.running = True
        logger.info("Campaign worker started")
        
        while self.running:
            try:
                # Process delayed jobs first
                await self.queue_service.process_delayed("send_campaign")
                
                # Get job from queue
                job = await self.queue_service.dequeue("send_campaign", timeout=5)
                
                if job:
                    await self.process_job(job)
                else:
                    # No job available, wait a bit
                    await asyncio.sleep(1)
                    
            except Exception as e:
                logger.error(f"Error in campaign worker loop: {str(e)}")
                await asyncio.sleep(5)
        
        logger.info("Campaign worker stopped")
    
    def stop(self):
        """Stop the worker"""
        self.running = False
        self.queue_service.close()


async def run_campaign_worker():
    """Run campaign worker standalone"""
    worker = CampaignWorker()
    try:
        await worker.run()
    except KeyboardInterrupt:
        worker.stop()


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    asyncio.run(run_campaign_worker())
